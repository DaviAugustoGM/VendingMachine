/////////////////////////////////////////////////////////////
// Created by: Synopsys DC Ultra(TM) in wire load mode
// Version   : X-2025.06-SP2
// Date      : Thu Jul  9 13:24:37 2026
/////////////////////////////////////////////////////////////


module vending_top ( clk, rst, coin_in, sel_item, confirm, cancel, dispense, 
        change_out, error, display, state_out );
  input [1:0] coin_in;
  input [1:0] sel_item;
  output [7:0] change_out;
  output [7:0] display;
  output [2:0] state_out;
  input clk, rst, confirm, cancel;
  output dispense, error;
  wire   mem_write, \u_memory/mem[0][4] , \u_memory/mem[0][3] ,
         \u_memory/mem[0][2] , \u_memory/mem[0][1] , \u_memory/mem[0][0] ,
         \u_memory/mem[1][4] , \u_memory/mem[1][3] , \u_memory/mem[1][2] ,
         \u_memory/mem[1][1] , \u_memory/mem[1][0] , \u_memory/mem[2][4] ,
         \u_memory/mem[2][3] , \u_memory/mem[2][2] , \u_memory/mem[2][1] ,
         \u_memory/mem[2][0] , \u_memory/mem[3][4] , \u_memory/mem[3][3] ,
         \u_memory/mem[3][2] , \u_memory/mem[3][1] , \u_memory/mem[3][0] ,
         \u_control_unit/N22 , \u_control_unit/N21 , \u_control_unit/N20 ,
         \u_control_unit/check_wait , n73, n74, n75, n76, n77, n78, n79, n80,
         n81, n82, n83, n84, n85, n86, n87, n88, n92, n93, n94, n95, n96, n97,
         n98, n99, n100, n101, n102, n103, n107, n108, n109, n110, n111, n115,
         n116, n117, n118, n119, n123, n124, n125, n126, n127, n131, n132,
         n133, n134, n135, n136, \intadd_10/CI , \intadd_10/SUM[4] ,
         \intadd_10/SUM[3] , \intadd_10/SUM[2] , \intadd_10/SUM[1] ,
         \intadd_10/SUM[0] , \intadd_10/n5 , \intadd_10/n4 , \intadd_10/n3 ,
         \intadd_10/n2 , \intadd_10/n1 , n146, n147, n148, n149, n150, n151,
         n152, n153, n154, n155, n156, n157, n158, n159, n160, n161, n162,
         n163, n164, n165, n166, n167, n168, n169, n170, n171, n172, n173,
         n174, n175, n176, n177, n178, n179, n180, n181, n182, n183, n184,
         n185, n186, n187, n188, n189, n190, n191, n192, n193, n194, n195,
         n196, n197, n198, n199, n200, n201, n202, n203, n204, n205, n206,
         n207, n208, n209, n210, n211, n212, n213, n214, n215, n216, n217,
         n218, n219, n220, n221, n222, n223, n224, n225, n226, n227, n228,
         n229, n230, n231, n232, n233, n234, n235, n236, n237, n238, n239,
         n240, n241, n242, n243, n244, n245, n263, n264, n265, n266, n267,
         n268, n269, n270, n271, n272, n273, n274, n275, n276;
  wire   [7:0] price;
  wire   [7:0] stock;
  assign dispense = mem_write;

  DFFX1_RVT \u_memory/mem_reg[3][1]  ( .D(n134), .CLK(clk), .Q(
        \u_memory/mem[3][1] ) );
  DFFX1_RVT \u_memory/mem_reg[3][0]  ( .D(n135), .CLK(clk), .Q(
        \u_memory/mem[3][0] ) );
  DFFX1_RVT \u_memory/mem_reg[3][2]  ( .D(n133), .CLK(clk), .Q(
        \u_memory/mem[3][2] ) );
  DFFX1_RVT \u_memory/mem_reg[3][3]  ( .D(n132), .CLK(clk), .Q(
        \u_memory/mem[3][3] ) );
  DFFX1_RVT \u_memory/mem_reg[3][4]  ( .D(n131), .CLK(clk), .Q(
        \u_memory/mem[3][4] ) );
  DFFX1_RVT \u_memory/mem_reg[2][0]  ( .D(n127), .CLK(clk), .Q(
        \u_memory/mem[2][0] ) );
  DFFX1_RVT \u_memory/mem_reg[2][1]  ( .D(n126), .CLK(clk), .Q(
        \u_memory/mem[2][1] ) );
  DFFX1_RVT \u_memory/mem_reg[2][2]  ( .D(n125), .CLK(clk), .Q(
        \u_memory/mem[2][2] ) );
  DFFX1_RVT \u_memory/mem_reg[2][3]  ( .D(n124), .CLK(clk), .Q(
        \u_memory/mem[2][3] ) );
  DFFX1_RVT \u_memory/mem_reg[2][4]  ( .D(n123), .CLK(clk), .Q(
        \u_memory/mem[2][4] ) );
  DFFX1_RVT \u_memory/mem_reg[1][0]  ( .D(n119), .CLK(clk), .Q(
        \u_memory/mem[1][0] ) );
  DFFX1_RVT \u_memory/mem_reg[1][2]  ( .D(n117), .CLK(clk), .Q(
        \u_memory/mem[1][2] ) );
  DFFX1_RVT \u_memory/mem_reg[1][1]  ( .D(n118), .CLK(clk), .Q(
        \u_memory/mem[1][1] ) );
  DFFX1_RVT \u_memory/mem_reg[1][3]  ( .D(n116), .CLK(clk), .Q(
        \u_memory/mem[1][3] ) );
  DFFX1_RVT \u_memory/mem_reg[1][4]  ( .D(n115), .CLK(clk), .Q(
        \u_memory/mem[1][4] ) );
  DFFX1_RVT \u_memory/mem_reg[0][0]  ( .D(n111), .CLK(clk), .Q(
        \u_memory/mem[0][0] ) );
  DFFX1_RVT \u_memory/mem_reg[0][2]  ( .D(n109), .CLK(clk), .Q(
        \u_memory/mem[0][2] ) );
  DFFX1_RVT \u_memory/mem_reg[0][1]  ( .D(n110), .CLK(clk), .Q(
        \u_memory/mem[0][1] ) );
  DFFX1_RVT \u_memory/mem_reg[0][3]  ( .D(n108), .CLK(clk), .Q(
        \u_memory/mem[0][3] ) );
  DFFX1_RVT \u_memory/mem_reg[0][4]  ( .D(n107), .CLK(clk), .Q(
        \u_memory/mem[0][4] ) );
  DFFX1_RVT \u_credit_reg/credit_reg[1]  ( .D(n88), .CLK(clk), .Q(display[1])
         );
  DFFX1_RVT \u_credit_reg/credit_reg[2]  ( .D(n86), .CLK(clk), .Q(display[2])
         );
  DFFX1_RVT \u_credit_reg/credit_reg[3]  ( .D(n85), .CLK(clk), .Q(display[3])
         );
  DFFX1_RVT \u_credit_reg/credit_reg[4]  ( .D(n84), .CLK(clk), .Q(display[4])
         );
  DFFX1_RVT \u_credit_reg/credit_reg[5]  ( .D(n83), .CLK(clk), .Q(display[5])
         );
  DFFX1_RVT \u_credit_reg/credit_reg[6]  ( .D(n82), .CLK(clk), .Q(display[6])
         );
  DFFX1_RVT \change_out_reg[0]  ( .D(n80), .CLK(clk), .Q(change_out[0]) );
  DFFX1_RVT \change_out_reg[1]  ( .D(n79), .CLK(clk), .Q(change_out[1]) );
  DFFX1_RVT \change_out_reg[2]  ( .D(n78), .CLK(clk), .Q(change_out[2]) );
  DFFX1_RVT \change_out_reg[3]  ( .D(n77), .CLK(clk), .Q(change_out[3]) );
  DFFX1_RVT \change_out_reg[4]  ( .D(n76), .CLK(clk), .Q(change_out[4]) );
  DFFX1_RVT \change_out_reg[5]  ( .D(n75), .CLK(clk), .Q(change_out[5]) );
  DFFX1_RVT \change_out_reg[7]  ( .D(n73), .CLK(clk), .Q(change_out[7]) );
  DFFX1_RVT \u_memory/stock_reg[0]  ( .D(n96), .CLK(clk), .Q(stock[0]) );
  DFFX1_RVT \u_memory/stock_reg[1]  ( .D(n95), .CLK(clk), .Q(stock[1]) );
  DFFX1_RVT \u_memory/stock_reg[2]  ( .D(n94), .CLK(clk), .Q(stock[2]) );
  DFFX1_RVT \u_memory/stock_reg[3]  ( .D(n93), .CLK(clk), .Q(stock[3]) );
  FADDX1_RVT \intadd_10/U6  ( .A(display[2]), .B(n268), .CI(\intadd_10/CI ), 
        .CO(\intadd_10/n5 ), .S(\intadd_10/SUM[0] ) );
  FADDX1_RVT \intadd_10/U5  ( .A(display[3]), .B(n269), .CI(\intadd_10/n5 ), 
        .CO(\intadd_10/n4 ), .S(\intadd_10/SUM[1] ) );
  FADDX1_RVT \intadd_10/U4  ( .A(display[4]), .B(n270), .CI(\intadd_10/n4 ), 
        .CO(\intadd_10/n3 ), .S(\intadd_10/SUM[2] ) );
  FADDX1_RVT \intadd_10/U3  ( .A(display[5]), .B(n271), .CI(\intadd_10/n3 ), 
        .CO(\intadd_10/n2 ), .S(\intadd_10/SUM[3] ) );
  FADDX1_RVT \intadd_10/U2  ( .A(display[6]), .B(n272), .CI(\intadd_10/n2 ), 
        .CO(\intadd_10/n1 ), .S(\intadd_10/SUM[4] ) );
  DFFSSRX1_RVT \u_control_unit/current_state_reg[1]  ( .D(1'b0), .SETB(
        \u_control_unit/N21 ), .RSTB(1'b1), .CLK(clk), .Q(n264), .QN(
        state_out[1]) );
  DFFSSRX1_RVT \u_control_unit/check_wait_reg  ( .D(1'b0), .SETB(1'b0), .RSTB(
        n136), .CLK(clk), .Q(\u_control_unit/check_wait ), .QN(n274) );
  DFFSSRX1_RVT \u_control_unit/current_state_reg[2]  ( .D(1'b0), .SETB(1'b0), 
        .RSTB(\u_control_unit/N22 ), .CLK(clk), .Q(state_out[2]), .QN(n263) );
  DFFSSRX1_RVT \u_control_unit/current_state_reg[0]  ( .D(1'b0), .SETB(1'b0), 
        .RSTB(\u_control_unit/N20 ), .CLK(clk), .Q(state_out[0]), .QN(n273) );
  DFFSSRX1_RVT \u_memory/price_reg[4]  ( .D(1'b0), .SETB(1'b0), .RSTB(n99), 
        .CLK(clk), .Q(price[4]), .QN(n270) );
  DFFSSRX1_RVT \u_memory/price_reg[3]  ( .D(1'b0), .SETB(1'b0), .RSTB(n100), 
        .CLK(clk), .Q(price[3]), .QN(n269) );
  DFFSSRX1_RVT \u_memory/price_reg[0]  ( .D(1'b0), .SETB(1'b0), .RSTB(n103), 
        .CLK(clk), .Q(price[0]), .QN(n276) );
  DFFSSRX1_RVT \u_memory/price_reg[1]  ( .D(1'b0), .SETB(1'b0), .RSTB(n102), 
        .CLK(clk), .Q(price[1]), .QN(n267) );
  DFFSSRX1_RVT \u_memory/price_reg[6]  ( .D(1'b0), .SETB(1'b0), .RSTB(n97), 
        .CLK(clk), .Q(price[6]), .QN(n272) );
  DFFSSRX1_RVT \u_memory/price_reg[2]  ( .D(1'b0), .SETB(1'b0), .RSTB(n101), 
        .CLK(clk), .Q(price[2]), .QN(n268) );
  DFFSSRX1_RVT \u_memory/stock_reg[4]  ( .D(1'b0), .SETB(1'b0), .RSTB(n92), 
        .CLK(clk), .Q(stock[4]), .QN(n265) );
  DFFSSRX1_RVT \u_memory/price_reg[5]  ( .D(1'b0), .SETB(1'b0), .RSTB(n98), 
        .CLK(clk), .Q(price[5]), .QN(n271) );
  DFFSSRX1_RVT \u_credit_reg/credit_reg[0]  ( .D(1'b0), .SETB(1'b0), .RSTB(n87), .CLK(clk), .Q(display[0]), .QN(n266) );
  DFFSSRX1_RVT \u_credit_reg/credit_reg[7]  ( .D(1'b0), .SETB(1'b0), .RSTB(n81), .CLK(clk), .Q(display[7]), .QN(n275) );
  DFFSSRX1_RVT \change_out_reg[6]  ( .D(1'b0), .SETB(n74), .RSTB(1'b1), .CLK(
        clk), .QN(change_out[6]) );
  INVX0_RVT U157 ( .A(n161), .Y(mem_write) );
  INVX0_RVT U158 ( .A(sel_item[0]), .Y(n146) );
  INVX0_RVT U159 ( .A(n146), .Y(n147) );
  AND2X1_RVT U160 ( .A1(n148), .A2(n149), .Y(n232) );
  AND2X1_RVT U161 ( .A1(n209), .A2(n233), .Y(n148) );
  INVX0_RVT U162 ( .A(n245), .Y(n150) );
  NAND2X0_RVT U163 ( .A1(n150), .A2(n273), .Y(n149) );
  AND3X1_RVT U181 ( .A1(state_out[0]), .A2(state_out[2]), .A3(n264), .Y(error)
         );
  NAND3X0_RVT U182 ( .A1(state_out[1]), .A2(state_out[0]), .A3(n263), .Y(n161)
         );
  NOR2X0_RVT U183 ( .A1(rst), .A2(cancel), .Y(n233) );
  NOR3X0_RVT U184 ( .A1(state_out[1]), .A2(confirm), .A3(n273), .Y(n151) );
  INVX0_RVT U185 ( .A(n151), .Y(n154) );
  INVX0_RVT U186 ( .A(error), .Y(n153) );
  AND3X1_RVT U187 ( .A1(state_out[1]), .A2(n273), .A3(n263), .Y(n191) );
  NAND2X0_RVT U188 ( .A1(\u_control_unit/check_wait ), .A2(n191), .Y(n152) );
  NAND3X0_RVT U189 ( .A1(n154), .A2(n153), .A3(n152), .Y(n155) );
  AND3X1_RVT U190 ( .A1(n233), .A2(n264), .A3(n263), .Y(n211) );
  OA21X1_RVT U191 ( .A1(coin_in[0]), .A2(coin_in[1]), .A3(n211), .Y(n230) );
  AO22X1_RVT U192 ( .A1(n233), .A2(n155), .A3(n230), .A4(n273), .Y(
        \u_control_unit/N20 ) );
  NAND2X0_RVT U193 ( .A1(price[0]), .A2(n266), .Y(n235) );
  AO222X1_RVT U194 ( .A1(display[1]), .A2(n267), .A3(display[1]), .A4(n235), 
        .A5(n267), .A6(n235), .Y(\intadd_10/CI ) );
  AND4X1_RVT U195 ( .A1(state_out[0]), .A2(confirm), .A3(n263), .A4(n264), .Y(
        n158) );
  NOR4X1_RVT U196 ( .A1(stock[3]), .A2(stock[2]), .A3(stock[1]), .A4(stock[0]), 
        .Y(n156) );
  INVX0_RVT U197 ( .A(\intadd_10/n1 ), .Y(n240) );
  AO22X1_RVT U198 ( .A1(n156), .A2(n265), .A3(n240), .A4(n275), .Y(n159) );
  NAND2X0_RVT U199 ( .A1(\u_control_unit/check_wait ), .A2(n159), .Y(n157) );
  OA221X1_RVT U200 ( .A1(n158), .A2(n191), .A3(n158), .A4(n157), .A5(n233), 
        .Y(\u_control_unit/N21 ) );
  AND4X1_RVT U201 ( .A1(state_out[1]), .A2(\u_control_unit/check_wait ), .A3(
        n263), .A4(n159), .Y(n160) );
  AO222X1_RVT U202 ( .A1(n233), .A2(mem_write), .A3(n233), .A4(error), .A5(
        n233), .A6(n160), .Y(\u_control_unit/N22 ) );
  NAND2X0_RVT U203 ( .A1(state_out[2]), .A2(n264), .Y(n208) );
  NAND2X0_RVT U204 ( .A1(n161), .A2(n208), .Y(n162) );
  OA221X1_RVT U205 ( .A1(\u_control_unit/check_wait ), .A2(n191), .A3(n274), 
        .A4(n162), .A5(n233), .Y(n136) );
  NAND2X0_RVT U206 ( .A1(sel_item[1]), .A2(sel_item[0]), .Y(n197) );
  INVX0_RVT U207 ( .A(sel_item[1]), .Y(n199) );
  MUX41X1_RVT U208 ( .A1(\u_memory/mem[2][4] ), .A3(\u_memory/mem[0][4] ), 
        .A2(\u_memory/mem[3][4] ), .A4(\u_memory/mem[1][4] ), .S0(n199), .S1(
        n147), .Y(n204) );
  MUX41X1_RVT U209 ( .A1(\u_memory/mem[2][3] ), .A3(\u_memory/mem[0][3] ), 
        .A2(\u_memory/mem[3][3] ), .A4(\u_memory/mem[1][3] ), .S0(n199), .S1(
        sel_item[0]), .Y(n203) );
  MUX41X1_RVT U210 ( .A1(\u_memory/mem[2][2] ), .A3(\u_memory/mem[0][2] ), 
        .A2(\u_memory/mem[3][2] ), .A4(\u_memory/mem[1][2] ), .S0(n199), .S1(
        n147), .Y(n202) );
  MUX41X1_RVT U211 ( .A1(\u_memory/mem[3][0] ), .A3(\u_memory/mem[1][0] ), 
        .A2(\u_memory/mem[2][0] ), .A4(\u_memory/mem[0][0] ), .S0(n199), .S1(
        n146), .Y(n200) );
  MUX41X1_RVT U212 ( .A1(\u_memory/mem[2][1] ), .A3(\u_memory/mem[0][1] ), 
        .A2(\u_memory/mem[3][1] ), .A4(\u_memory/mem[1][1] ), .S0(n199), .S1(
        sel_item[0]), .Y(n201) );
  OR2X1_RVT U213 ( .A1(n200), .A2(n201), .Y(n167) );
  OR2X1_RVT U214 ( .A1(n202), .A2(n167), .Y(n169) );
  OR2X1_RVT U215 ( .A1(n203), .A2(n169), .Y(n171) );
  OR2X1_RVT U216 ( .A1(n204), .A2(n171), .Y(n172) );
  NAND2X0_RVT U217 ( .A1(n172), .A2(mem_write), .Y(n181) );
  INVX0_RVT U218 ( .A(rst), .Y(n234) );
  OA21X1_RVT U219 ( .A1(n197), .A2(n181), .A3(n234), .Y(n174) );
  INVX0_RVT U220 ( .A(n200), .Y(n163) );
  INVX0_RVT U221 ( .A(n174), .Y(n165) );
  AND2X1_RVT U222 ( .A1(n234), .A2(n165), .Y(n173) );
  AO22X1_RVT U223 ( .A1(\u_memory/mem[3][0] ), .A2(n174), .A3(n163), .A4(n173), 
        .Y(n135) );
  INVX0_RVT U224 ( .A(n167), .Y(n164) );
  AO21X1_RVT U225 ( .A1(n200), .A2(n201), .A3(n164), .Y(n184) );
  AO221X1_RVT U226 ( .A1(n184), .A2(n165), .A3(n174), .A4(\u_memory/mem[3][1] ), .A5(rst), .Y(n134) );
  INVX0_RVT U227 ( .A(n169), .Y(n166) );
  AO21X1_RVT U228 ( .A1(n202), .A2(n167), .A3(n166), .Y(n186) );
  AO22X1_RVT U229 ( .A1(\u_memory/mem[3][2] ), .A2(n174), .A3(n173), .A4(n186), 
        .Y(n133) );
  INVX0_RVT U230 ( .A(n171), .Y(n168) );
  AO21X1_RVT U231 ( .A1(n203), .A2(n169), .A3(n168), .Y(n187) );
  AO22X1_RVT U232 ( .A1(\u_memory/mem[3][3] ), .A2(n174), .A3(n173), .A4(n187), 
        .Y(n132) );
  INVX0_RVT U233 ( .A(n172), .Y(n170) );
  AO21X1_RVT U234 ( .A1(n204), .A2(n171), .A3(n170), .Y(n188) );
  AO22X1_RVT U235 ( .A1(\u_memory/mem[3][4] ), .A2(n174), .A3(n173), .A4(n188), 
        .Y(n131) );
  NAND2X0_RVT U236 ( .A1(sel_item[1]), .A2(n146), .Y(n194) );
  OA21X1_RVT U237 ( .A1(n194), .A2(n181), .A3(n234), .Y(n177) );
  INVX0_RVT U238 ( .A(n177), .Y(n175) );
  NAND2X0_RVT U239 ( .A1(n200), .A2(n234), .Y(n183) );
  AO22X1_RVT U240 ( .A1(n177), .A2(\u_memory/mem[2][0] ), .A3(n175), .A4(n183), 
        .Y(n127) );
  AO221X1_RVT U241 ( .A1(n184), .A2(n175), .A3(n177), .A4(\u_memory/mem[2][1] ), .A5(rst), .Y(n126) );
  AND2X1_RVT U242 ( .A1(n234), .A2(n175), .Y(n176) );
  AO22X1_RVT U243 ( .A1(\u_memory/mem[2][2] ), .A2(n177), .A3(n176), .A4(n186), 
        .Y(n125) );
  AO22X1_RVT U244 ( .A1(\u_memory/mem[2][3] ), .A2(n177), .A3(n176), .A4(n187), 
        .Y(n124) );
  AO22X1_RVT U245 ( .A1(\u_memory/mem[2][4] ), .A2(n177), .A3(n176), .A4(n188), 
        .Y(n123) );
  NAND2X0_RVT U246 ( .A1(n147), .A2(n199), .Y(n195) );
  OA21X1_RVT U247 ( .A1(n195), .A2(n181), .A3(n234), .Y(n180) );
  INVX0_RVT U248 ( .A(n180), .Y(n178) );
  AO22X1_RVT U249 ( .A1(n180), .A2(\u_memory/mem[1][0] ), .A3(n178), .A4(n183), 
        .Y(n119) );
  AND2X1_RVT U250 ( .A1(n234), .A2(n178), .Y(n179) );
  AO22X1_RVT U251 ( .A1(\u_memory/mem[1][1] ), .A2(n180), .A3(n179), .A4(n184), 
        .Y(n118) );
  AO221X1_RVT U252 ( .A1(n186), .A2(n178), .A3(n180), .A4(\u_memory/mem[1][2] ), .A5(rst), .Y(n117) );
  AO22X1_RVT U253 ( .A1(\u_memory/mem[1][3] ), .A2(n180), .A3(n179), .A4(n187), 
        .Y(n116) );
  AO22X1_RVT U254 ( .A1(\u_memory/mem[1][4] ), .A2(n180), .A3(n179), .A4(n188), 
        .Y(n115) );
  NAND2X0_RVT U255 ( .A1(n199), .A2(n146), .Y(n182) );
  OA21X1_RVT U256 ( .A1(n182), .A2(n181), .A3(n234), .Y(n190) );
  INVX0_RVT U257 ( .A(n190), .Y(n185) );
  AO22X1_RVT U258 ( .A1(n190), .A2(\u_memory/mem[0][0] ), .A3(n185), .A4(n183), 
        .Y(n111) );
  AND2X1_RVT U259 ( .A1(n234), .A2(n185), .Y(n189) );
  AO22X1_RVT U260 ( .A1(\u_memory/mem[0][1] ), .A2(n190), .A3(n189), .A4(n184), 
        .Y(n110) );
  AO221X1_RVT U261 ( .A1(n186), .A2(n185), .A3(n190), .A4(\u_memory/mem[0][2] ), .A5(rst), .Y(n109) );
  AO22X1_RVT U262 ( .A1(\u_memory/mem[0][3] ), .A2(n190), .A3(n189), .A4(n187), 
        .Y(n108) );
  AO22X1_RVT U263 ( .A1(\u_memory/mem[0][4] ), .A2(n190), .A3(n189), .A4(n188), 
        .Y(n107) );
  NAND2X0_RVT U264 ( .A1(n191), .A2(n274), .Y(n192) );
  NAND2X0_RVT U265 ( .A1(n234), .A2(n192), .Y(n193) );
  INVX0_RVT U266 ( .A(n193), .Y(n206) );
  AND2X1_RVT U267 ( .A1(n234), .A2(n193), .Y(n205) );
  AO22X1_RVT U268 ( .A1(price[0]), .A2(n206), .A3(n205), .A4(n146), .Y(n103)
         );
  NAND2X0_RVT U269 ( .A1(n195), .A2(n194), .Y(n196) );
  AO22X1_RVT U270 ( .A1(n206), .A2(price[1]), .A3(n205), .A4(n196), .Y(n102)
         );
  INVX0_RVT U271 ( .A(n197), .Y(n198) );
  AO22X1_RVT U272 ( .A1(n198), .A2(n205), .A3(n206), .A4(price[2]), .Y(n101)
         );
  AO22X1_RVT U273 ( .A1(price[3]), .A2(n206), .A3(n205), .A4(n146), .Y(n100)
         );
  AO22X1_RVT U274 ( .A1(price[4]), .A2(n206), .A3(n205), .A4(n199), .Y(n99) );
  AO22X1_RVT U275 ( .A1(sel_item[0]), .A2(n205), .A3(n206), .A4(price[5]), .Y(
        n98) );
  AO22X1_RVT U276 ( .A1(sel_item[1]), .A2(n205), .A3(n206), .A4(price[6]), .Y(
        n97) );
  AO22X1_RVT U277 ( .A1(n206), .A2(stock[0]), .A3(n205), .A4(n200), .Y(n96) );
  AO22X1_RVT U278 ( .A1(n206), .A2(stock[1]), .A3(n205), .A4(n201), .Y(n95) );
  AO22X1_RVT U279 ( .A1(n206), .A2(stock[2]), .A3(n205), .A4(n202), .Y(n94) );
  AO22X1_RVT U280 ( .A1(n206), .A2(stock[3]), .A3(n205), .A4(n203), .Y(n93) );
  AO22X1_RVT U281 ( .A1(n206), .A2(stock[4]), .A3(n205), .A4(n204), .Y(n92) );
  OAI21X1_RVT U282 ( .A1(n266), .A2(coin_in[1]), .A3(coin_in[0]), .Y(n207) );
  NAND2X0_RVT U283 ( .A1(display[1]), .A2(n207), .Y(n213) );
  OA21X1_RVT U284 ( .A1(display[1]), .A2(n207), .A3(n213), .Y(n210) );
  AND2X1_RVT U285 ( .A1(n233), .A2(n208), .Y(n245) );
  INVX0_RVT U286 ( .A(n230), .Y(n209) );
  AO22X1_RVT U287 ( .A1(n230), .A2(n210), .A3(display[1]), .A4(n232), .Y(n88)
         );
  INVX0_RVT U288 ( .A(coin_in[1]), .Y(n219) );
  AO21X1_RVT U289 ( .A1(n211), .A2(coin_in[1]), .A3(n232), .Y(n212) );
  OA222X1_RVT U290 ( .A1(display[0]), .A2(n230), .A3(display[0]), .A4(n219), 
        .A5(n266), .A6(n212), .Y(n87) );
  NAND2X0_RVT U291 ( .A1(coin_in[0]), .A2(coin_in[1]), .Y(n222) );
  NAND2X0_RVT U292 ( .A1(n222), .A2(n213), .Y(n214) );
  NAND2X0_RVT U293 ( .A1(display[2]), .A2(n214), .Y(n216) );
  OA21X1_RVT U294 ( .A1(display[2]), .A2(n214), .A3(n216), .Y(n215) );
  AO22X1_RVT U295 ( .A1(n230), .A2(n215), .A3(display[2]), .A4(n232), .Y(n86)
         );
  INVX0_RVT U296 ( .A(n216), .Y(n218) );
  AO22X1_RVT U297 ( .A1(n230), .A2(n217), .A3(n232), .A4(display[3]), .Y(n85)
         );
  FADDX1_RVT U298 ( .A(display[3]), .B(n219), .CI(n218), .CO(n223), .S(n217)
         );
  FADDX1_RVT U299 ( .A(display[4]), .B(n223), .CI(n222), .S(n220) );
  AO22X1_RVT U300 ( .A1(n230), .A2(n220), .A3(n232), .A4(display[4]), .Y(n84)
         );
  AO222X1_RVT U301 ( .A1(display[4]), .A2(n223), .A3(display[4]), .A4(n222), 
        .A5(n223), .A6(n222), .Y(n224) );
  FADDX1_RVT U302 ( .A(coin_in[1]), .B(display[5]), .CI(n224), .S(n221) );
  AO22X1_RVT U303 ( .A1(n230), .A2(n221), .A3(n232), .A4(display[5]), .Y(n83)
         );
  INVX0_RVT U304 ( .A(n222), .Y(n228) );
  OR2X1_RVT U305 ( .A1(display[4]), .A2(n223), .Y(n225) );
  AO222X1_RVT U306 ( .A1(display[5]), .A2(coin_in[1]), .A3(display[5]), .A4(
        n225), .A5(coin_in[1]), .A6(n224), .Y(n227) );
  AO22X1_RVT U307 ( .A1(n230), .A2(n226), .A3(n232), .A4(display[6]), .Y(n82)
         );
  FADDX1_RVT U308 ( .A(display[6]), .B(n228), .CI(n227), .CO(n229), .S(n226)
         );
  HADDX1_RVT U309 ( .A0(display[7]), .B0(n229), .SO(n231) );
  AO22X1_RVT U310 ( .A1(display[7]), .A2(n232), .A3(n231), .A4(n230), .Y(n81)
         );
  AND4X1_RVT U311 ( .A1(state_out[2]), .A2(n233), .A3(n273), .A4(n264), .Y(
        n241) );
  OA21X1_RVT U312 ( .A1(cancel), .A2(error), .A3(n234), .Y(n243) );
  AO21X1_RVT U313 ( .A1(n241), .A2(n276), .A3(n243), .Y(n236) );
  INVX0_RVT U314 ( .A(n235), .Y(n237) );
  AO222X1_RVT U315 ( .A1(n236), .A2(display[0]), .A3(n241), .A4(n237), .A5(
        n245), .A6(change_out[0]), .Y(n80) );
  FADDX1_RVT U316 ( .A(display[1]), .B(price[1]), .CI(n237), .S(n238) );
  AO22X1_RVT U317 ( .A1(n245), .A2(change_out[1]), .A3(n241), .A4(n238), .Y(
        n239) );
  AO21X1_RVT U318 ( .A1(display[1]), .A2(n243), .A3(n239), .Y(n79) );
  AO222X1_RVT U319 ( .A1(display[2]), .A2(n243), .A3(n245), .A4(change_out[2]), 
        .A5(\intadd_10/SUM[0] ), .A6(n241), .Y(n78) );
  AO222X1_RVT U320 ( .A1(n245), .A2(change_out[3]), .A3(n241), .A4(
        \intadd_10/SUM[1] ), .A5(display[3]), .A6(n243), .Y(n77) );
  AO222X1_RVT U321 ( .A1(n245), .A2(change_out[4]), .A3(n243), .A4(display[4]), 
        .A5(\intadd_10/SUM[2] ), .A6(n241), .Y(n76) );
  AO222X1_RVT U322 ( .A1(n245), .A2(change_out[5]), .A3(n243), .A4(display[5]), 
        .A5(\intadd_10/SUM[3] ), .A6(n241), .Y(n75) );
  AO222X1_RVT U323 ( .A1(n245), .A2(change_out[6]), .A3(n241), .A4(
        \intadd_10/SUM[4] ), .A5(display[6]), .A6(n243), .Y(n74) );
  HADDX1_RVT U324 ( .A0(display[7]), .B0(n240), .SO(n242) );
  AO22X1_RVT U325 ( .A1(display[7]), .A2(n243), .A3(n242), .A4(n241), .Y(n244)
         );
  AO21X1_RVT U326 ( .A1(n245), .A2(change_out[7]), .A3(n244), .Y(n73) );
endmodule

