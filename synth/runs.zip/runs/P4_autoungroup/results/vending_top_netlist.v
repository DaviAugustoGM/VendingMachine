/////////////////////////////////////////////////////////////
// Created by: Synopsys DC Ultra(TM) in wire load mode
// Version   : X-2025.06-SP2
// Date      : Thu Jul  9 13:25:02 2026
/////////////////////////////////////////////////////////////


module vending_top ( clk, rst, coin_in, sel_item, confirm, cancel, dispense, 
        change_out, error, display, state_out );
  input [1:0] coin_in;
  input [1:0] sel_item;
  output [7:0] change_out;
  output [7:0] display;
  output [2:0] state_out;
  input clk, rst, confirm, cancel;
  output dispense, error;
  wire   \u_memory/mem[0][2] , \u_memory/mem[0][0] , \u_memory/mem[1][2] ,
         \u_memory/mem[1][0] , \u_memory/mem[2][2] , \u_memory/mem[2][1] ,
         \u_memory/mem[2][0] , \u_memory/mem[3][1] , \u_memory/mem[3][0] ,
         \u_control_unit/N21 , \u_control_unit/N20 ,
         \u_control_unit/check_wait , n73, n74, n75, n76, n77, n78, n79, n80,
         n81, n82, n83, n84, n85, n86, n87, n88, n92, n93, n94, n95, n96, n97,
         n98, n101, n102, n107, n108, n109, n110, n111, n115, n116, n117, n118,
         n119, n123, n124, n125, n126, n127, n131, n132, n133, n134, n135,
         n136, \intadd_18/CI , \intadd_18/SUM[4] , \intadd_18/SUM[3] ,
         \intadd_18/SUM[2] , \intadd_18/SUM[1] , \intadd_18/SUM[0] ,
         \intadd_18/n5 , \intadd_18/n4 , \intadd_18/n3 , \intadd_18/n2 ,
         \intadd_18/n1 , n146, n147, n148, n149, n150, n151, n152, n153, n154,
         n155, n156, n157, n158, n159, n160, n161, n162, n163, n164, n165,
         n166, n167, n168, n169, n170, n171, n172, n173, n174, n175, n176,
         n177, n178, n180, n181, n182, n183, n184, n185, n186, n187, n188,
         n189, n190, n191, n192, n193, n194, n195, n196, n197, n198, n199,
         n200, n201, n202, n203, n204, n205, n206, n207, n208, n209, n210,
         n211, n212, n213, n214, n215, n216, n217, n218, n219, n220, n221,
         n222, n223, n224, n225, n226, n227, n228, n229, n230, n232, n233,
         n234, n235, n236, n237, n238, n239, n240, n241, n242, n243, n244,
         n245, n246, n247, n248, n249, n250, n251, n252, n253, n254, n255,
         n256, n257, n258, n259, n260, n261, n262, n263, n264, n265, n266,
         n267, n268, n269, n270, n271, n272, n273, n274, n275, n276, n277,
         n278, n279, n280, n281, n282, n283, n284, n285, n286, n287, n288,
         n289, n290, n291, n292, n293, n294, n295, n296, n297, n298, n299,
         n300, n301, n302, n303, n304, n305, n306, n307, n308, n309, n310,
         n311, n312, n313, n314, n315, n316, n317, n318, n319, n320, n321,
         n322, n323, n324, n325, n326, n327, n328, n329, n330, n331, n332,
         n333, n334, n335, n336, n337, n338, n339, n340, n341, n342, n343,
         n344, n345, n346, n347, n348, n349, n350, n351, n352, n353, n354,
         n355, n356, n357, n358, n359, n360, n361, n362, n363, n364, n365,
         n366, n367, n368, n369, n370, n371, n372, n373, n374, n375, n376,
         n377, n378, n379, n380, n381, n382, n383, n384, n385, n386, n387,
         n388, n402, n403, n404, n405, n406, n407, n408, n410, n411, n413,
         n415, n416, n417, n418, n419, n420, n421, n422, n423, n424, n425,
         n426, n427, n428, n429, n430, n431, n432, n433, n434, n435, n436,
         n438;
  wire   [7:0] price;
  wire   [7:0] stock;

  DFFX1_RVT \u_memory/mem_reg[3][1]  ( .D(n134), .CLK(clk), .Q(
        \u_memory/mem[3][1] ) );
  DFFX1_RVT \u_memory/mem_reg[2][0]  ( .D(n127), .CLK(clk), .Q(
        \u_memory/mem[2][0] ), .QN(n418) );
  DFFX1_RVT \u_memory/mem_reg[2][1]  ( .D(n126), .CLK(clk), .Q(
        \u_memory/mem[2][1] ), .QN(n422) );
  DFFX1_RVT \u_memory/mem_reg[2][2]  ( .D(n125), .CLK(clk), .Q(
        \u_memory/mem[2][2] ), .QN(n420) );
  DFFX1_RVT \u_memory/mem_reg[1][0]  ( .D(n119), .CLK(clk), .Q(
        \u_memory/mem[1][0] ) );
  DFFX1_RVT \u_memory/mem_reg[1][1]  ( .D(n118), .CLK(clk), .Q(n195) );
  DFFX1_RVT \u_credit_reg/credit_reg[1]  ( .D(n88), .CLK(clk), .Q(display[1])
         );
  DFFX1_RVT \u_credit_reg/credit_reg[0]  ( .D(n87), .CLK(clk), .Q(display[0])
         );
  DFFX1_RVT \u_credit_reg/credit_reg[2]  ( .D(n86), .CLK(clk), .Q(display[2])
         );
  DFFX1_RVT \u_credit_reg/credit_reg[4]  ( .D(n84), .CLK(clk), .Q(display[4])
         );
  DFFX1_RVT \u_credit_reg/credit_reg[5]  ( .D(n83), .CLK(clk), .Q(display[5])
         );
  DFFX1_RVT \change_out_reg[0]  ( .D(n80), .CLK(clk), .Q(change_out[0]) );
  DFFX1_RVT \change_out_reg[1]  ( .D(n79), .CLK(clk), .Q(change_out[1]) );
  DFFX1_RVT \change_out_reg[2]  ( .D(n78), .CLK(clk), .Q(change_out[2]) );
  DFFX1_RVT \change_out_reg[3]  ( .D(n77), .CLK(clk), .Q(change_out[3]) );
  DFFX1_RVT \change_out_reg[4]  ( .D(n76), .CLK(clk), .Q(change_out[4]) );
  DFFX1_RVT \change_out_reg[6]  ( .D(n74), .CLK(clk), .Q(change_out[6]) );
  DFFX1_RVT \change_out_reg[7]  ( .D(n73), .CLK(clk), .Q(change_out[7]) );
  DFFX1_RVT \u_memory/stock_reg[1]  ( .D(n95), .CLK(clk), .Q(stock[1]) );
  DFFX1_RVT \u_memory/stock_reg[2]  ( .D(n94), .CLK(clk), .Q(stock[2]) );
  DFFX1_RVT \u_memory/stock_reg[3]  ( .D(n93), .CLK(clk), .Q(stock[3]) );
  FADDX1_RVT \intadd_18/U6  ( .A(display[2]), .B(n407), .CI(\intadd_18/CI ), 
        .CO(\intadd_18/n5 ), .S(\intadd_18/SUM[0] ) );
  FADDX1_RVT \intadd_18/U5  ( .A(display[3]), .B(n408), .CI(\intadd_18/n5 ), 
        .CO(\intadd_18/n4 ), .S(\intadd_18/SUM[1] ) );
  FADDX1_RVT \intadd_18/U4  ( .A(display[4]), .B(n427), .CI(\intadd_18/n4 ), 
        .CO(\intadd_18/n3 ), .S(\intadd_18/SUM[2] ) );
  FADDX1_RVT \intadd_18/U3  ( .A(display[5]), .B(n428), .CI(\intadd_18/n3 ), 
        .CO(\intadd_18/n2 ), .S(\intadd_18/SUM[3] ) );
  FADDX1_RVT \intadd_18/U2  ( .A(display[6]), .B(n430), .CI(\intadd_18/n2 ), 
        .CO(\intadd_18/n1 ), .S(\intadd_18/SUM[4] ) );
  DFFX2_RVT \u_memory/mem_reg[3][4]  ( .D(n131), .CLK(clk), .Q(n192), .QN(n416) );
  DFFSSRX1_RVT \u_control_unit/current_state_reg[2]  ( .D(n436), .SETB(n435), 
        .RSTB(1'b1), .CLK(clk), .Q(n429), .QN(state_out[2]) );
  DFFARX1_RVT \u_memory/stock_reg[0]  ( .D(n96), .CLK(clk), .RSTB(1'b1), .Q(
        stock[0]), .QN(n432) );
  DFFARX1_RVT \u_memory/stock_reg[4]  ( .D(n92), .CLK(clk), .RSTB(1'b1), .Q(
        stock[4]), .QN(n404) );
  DFFARX1_RVT \u_memory/price_reg[1]  ( .D(n102), .CLK(clk), .RSTB(1'b1), .Q(
        price[1]), .QN(n406) );
  DFFARX1_RVT \u_memory/price_reg[2]  ( .D(n101), .CLK(clk), .RSTB(1'b1), .Q(
        price[2]), .QN(n407) );
  DFFARX1_RVT \u_memory/price_reg[5]  ( .D(n98), .CLK(clk), .RSTB(1'b1), .Q(
        price[5]), .QN(n428) );
  DFFARX1_RVT \u_memory/price_reg[6]  ( .D(n97), .CLK(clk), .RSTB(1'b1), .Q(
        price[6]), .QN(n430) );
  DFFARX1_RVT \u_control_unit/current_state_reg[0]  ( .D(\u_control_unit/N20 ), 
        .CLK(clk), .RSTB(1'b1), .Q(state_out[0]), .QN(n403) );
  DFFARX1_RVT \u_control_unit/check_wait_reg  ( .D(n136), .CLK(clk), .RSTB(
        1'b1), .Q(\u_control_unit/check_wait ), .QN(n431) );
  DFFARX1_RVT \u_control_unit/current_state_reg[1]  ( .D(\u_control_unit/N21 ), 
        .CLK(clk), .RSTB(1'b1), .Q(state_out[1]), .QN(n402) );
  DFFSSRX1_RVT \u_memory/price_reg[4]  ( .D(n204), .SETB(n438), .RSTB(n207), 
        .CLK(clk), .Q(n427) );
  DFFSSRX1_RVT \u_memory/price_reg[3]  ( .D(n199), .SETB(n438), .RSTB(n208), 
        .CLK(clk), .Q(n408) );
  DFFSSRX1_RVT \u_memory/price_reg[0]  ( .D(n199), .SETB(n438), .RSTB(n209), 
        .CLK(clk), .Q(n405) );
  DFFSSRX1_RVT \change_out_reg[5]  ( .D(1'b0), .SETB(n75), .RSTB(1'b1), .CLK(
        clk), .QN(change_out[5]) );
  DFFX1_RVT \u_credit_reg/credit_reg[7]  ( .D(n81), .CLK(clk), .Q(display[7]), 
        .QN(n433) );
  DFFX2_RVT \u_memory/mem_reg[3][0]  ( .D(n135), .CLK(clk), .Q(
        \u_memory/mem[3][0] ) );
  DFFX1_RVT \u_memory/mem_reg[0][3]  ( .D(n108), .CLK(clk), .QN(n423) );
  DFFX1_RVT \u_memory/mem_reg[1][3]  ( .D(n116), .CLK(clk), .Q(n160), .QN(n411) );
  DFFX1_RVT \u_credit_reg/credit_reg[3]  ( .D(n85), .CLK(clk), .Q(display[3])
         );
  DFFX1_RVT \u_credit_reg/credit_reg[6]  ( .D(n82), .CLK(clk), .Q(display[6]), 
        .QN(n434) );
  DFFARX1_RVT \u_memory/mem_reg[0][1]  ( .D(n110), .CLK(clk), .RSTB(1'b1), 
        .QN(n421) );
  DFFX2_RVT \u_memory/mem_reg[1][2]  ( .D(n117), .CLK(clk), .Q(
        \u_memory/mem[1][2] ) );
  DFFX1_RVT \u_memory/mem_reg[3][3]  ( .D(n132), .CLK(clk), .Q(n193), .QN(n413) );
  DFFX2_RVT \u_memory/mem_reg[0][0]  ( .D(n111), .CLK(clk), .Q(
        \u_memory/mem[0][0] ), .QN(n417) );
  DFFX2_RVT \u_memory/mem_reg[0][2]  ( .D(n109), .CLK(clk), .Q(
        \u_memory/mem[0][2] ), .QN(n419) );
  DFFX2_RVT \u_memory/mem_reg[0][4]  ( .D(n107), .CLK(clk), .QN(n425) );
  DFFX2_RVT \u_memory/mem_reg[1][4]  ( .D(n115), .CLK(clk), .Q(n159), .QN(n415) );
  DFFX2_RVT \u_memory/mem_reg[2][4]  ( .D(n123), .CLK(clk), .QN(n426) );
  DFFX2_RVT \u_memory/mem_reg[2][3]  ( .D(n124), .CLK(clk), .QN(n424) );
  DFFX1_RVT \u_memory/mem_reg[3][2]  ( .D(n133), .CLK(clk), .Q(n194), .QN(n410) );
  INVX2_RVT U157 ( .A(n157), .Y(n158) );
  OAI21X1_RVT U158 ( .A1(n343), .A2(n336), .A3(n337), .Y(n323) );
  INVX1_RVT U159 ( .A(rst), .Y(n361) );
  NBUFFX4_RVT U160 ( .A(sel_item[1]), .Y(n204) );
  INVX0_RVT U161 ( .A(n286), .Y(n156) );
  OR2X2_RVT U162 ( .A1(n349), .A2(n232), .Y(n237) );
  OR2X2_RVT U163 ( .A1(rst), .A2(n261), .Y(n287) );
  AOI21X2_RVT U164 ( .A1(n290), .A2(n237), .A3(n236), .Y(n253) );
  OR2X1_RVT U165 ( .A1(n226), .A2(n232), .Y(n235) );
  OR2X1_RVT U166 ( .A1(n262), .A2(n287), .Y(n263) );
  OR3X1_RVT U167 ( .A1(n178), .A2(n146), .A3(n177), .Y(n258) );
  NOR2X0_RVT U168 ( .A1(n417), .A2(n227), .Y(n146) );
  AO21X1_RVT U169 ( .A1(n235), .A2(n230), .A3(rst), .Y(n282) );
  OR2X2_RVT U170 ( .A1(sel_item[0]), .A2(n162), .Y(n373) );
  NOR3X4_RVT U171 ( .A1(n418), .A2(sel_item[0]), .A3(n162), .Y(n178) );
  OR3X1_RVT U172 ( .A1(n258), .A2(n225), .A3(n224), .Y(n151) );
  INVX0_RVT U173 ( .A(n286), .Y(n228) );
  NAND2X0_RVT U174 ( .A1(n147), .A2(n151), .Y(n285) );
  OR2X1_RVT U175 ( .A1(n247), .A2(n352), .Y(n147) );
  OR3X1_RVT U176 ( .A1(n221), .A2(n220), .A3(n176), .Y(n148) );
  NBUFFX2_RVT U177 ( .A(coin_in[1]), .Y(n149) );
  NBUFFX2_RVT U178 ( .A(n341), .Y(n150) );
  NBUFFX2_RVT U179 ( .A(n356), .Y(n152) );
  OR2X2_RVT U180 ( .A1(n226), .A2(n151), .Y(n153) );
  OR3X2_RVT U181 ( .A1(n258), .A2(n148), .A3(n224), .Y(n232) );
  AND2X1_RVT U182 ( .A1(n201), .A2(n237), .Y(n154) );
  AND2X1_RVT U183 ( .A1(n153), .A2(n230), .Y(n155) );
  INVX0_RVT U184 ( .A(rst), .Y(n157) );
  XOR2X1_RVT U185 ( .A1(n316), .A2(n315), .Y(n317) );
  INVX0_RVT U186 ( .A(sel_item[1]), .Y(n162) );
  NOR2X0_RVT U187 ( .A1(n373), .A2(n422), .Y(n220) );
  OR2X1_RVT U188 ( .A1(n349), .A2(n290), .Y(n226) );
  INVX1_RVT U189 ( .A(n204), .Y(n165) );
  NBUFFX2_RVT U190 ( .A(n373), .Y(n161) );
  OR3X1_RVT U191 ( .A1(n219), .A2(n218), .A3(n163), .Y(n290) );
  AO22X1_RVT U192 ( .A1(n175), .A2(n192), .A3(n169), .A4(n165), .Y(n163) );
  OR3X1_RVT U193 ( .A1(n217), .A2(n168), .A3(n164), .Y(n349) );
  AO22X1_RVT U194 ( .A1(n175), .A2(n193), .A3(n166), .A4(n167), .Y(n164) );
  INVX0_RVT U195 ( .A(n185), .Y(n166) );
  INVX1_RVT U196 ( .A(n204), .Y(n167) );
  NOR2X0_RVT U197 ( .A1(n373), .A2(n424), .Y(n168) );
  INVX0_RVT U198 ( .A(n186), .Y(n169) );
  NBUFFX2_RVT U199 ( .A(n175), .Y(n170) );
  NBUFFX2_RVT U200 ( .A(n174), .Y(n171) );
  AND2X1_RVT U201 ( .A1(sel_item[1]), .A2(sel_item[0]), .Y(n175) );
  NAND2X0_RVT U202 ( .A1(\u_memory/mem[3][1] ), .A2(n175), .Y(n187) );
  NAND2X0_RVT U203 ( .A1(n194), .A2(n175), .Y(n222) );
  NAND2X0_RVT U204 ( .A1(n170), .A2(dispense), .Y(n203) );
  AO21X1_RVT U205 ( .A1(n375), .A2(price[2]), .A3(n172), .Y(n101) );
  NOR2X0_RVT U206 ( .A1(n171), .A2(n173), .Y(n172) );
  INVX1_RVT U207 ( .A(n438), .Y(n173) );
  INVX0_RVT U208 ( .A(n170), .Y(n174) );
  INVX1_RVT U209 ( .A(n225), .Y(n354) );
  OR3X1_RVT U210 ( .A1(n221), .A2(n220), .A3(n176), .Y(n225) );
  NAND2X0_RVT U211 ( .A1(n188), .A2(n187), .Y(n176) );
  NAND2X0_RVT U212 ( .A1(n215), .A2(n214), .Y(n177) );
  OR3X1_RVT U213 ( .A1(n246), .A2(n245), .A3(n244), .Y(n224) );
  NAND2X0_RVT U214 ( .A1(n223), .A2(n222), .Y(n244) );
  NOR2X0_RVT U215 ( .A1(n420), .A2(n373), .Y(n245) );
  NOR2X0_RVT U216 ( .A1(n419), .A2(n227), .Y(n246) );
  NOR2X0_RVT U217 ( .A1(n421), .A2(n227), .Y(n221) );
  AND2X1_RVT U218 ( .A1(n199), .A2(n180), .Y(n191) );
  INVX0_RVT U219 ( .A(n204), .Y(n180) );
  AND2X1_RVT U220 ( .A1(n199), .A2(n181), .Y(n189) );
  INVX0_RVT U221 ( .A(n240), .Y(n181) );
  OR2X1_RVT U222 ( .A1(n204), .A2(n182), .Y(n223) );
  NAND2X0_RVT U223 ( .A1(sel_item[0]), .A2(\u_memory/mem[1][2] ), .Y(n182) );
  OR2X1_RVT U224 ( .A1(n204), .A2(n183), .Y(n215) );
  NAND2X0_RVT U225 ( .A1(sel_item[0]), .A2(\u_memory/mem[1][0] ), .Y(n183) );
  OR2X1_RVT U226 ( .A1(n204), .A2(n184), .Y(n188) );
  NAND2X0_RVT U227 ( .A1(sel_item[0]), .A2(n195), .Y(n184) );
  NAND2X0_RVT U228 ( .A1(sel_item[0]), .A2(n160), .Y(n185) );
  NAND2X0_RVT U229 ( .A1(sel_item[0]), .A2(n159), .Y(n186) );
  OR2X2_RVT U230 ( .A1(n158), .A2(n206), .Y(n264) );
  NOR3X0_RVT U231 ( .A1(n206), .A2(n158), .A3(n425), .Y(n241) );
  AND2X1_RVT U232 ( .A1(n190), .A2(n153), .Y(n206) );
  NOR2X0_RVT U233 ( .A1(n426), .A2(n373), .Y(n218) );
  NOR3X0_RVT U234 ( .A1(n246), .A2(n245), .A3(n244), .Y(n352) );
  NOR2X0_RVT U235 ( .A1(n369), .A2(n161), .Y(n230) );
  MUX21X1_RVT U236 ( .A1(n277), .A2(\u_memory/mem[1][0] ), .S0(n286), .Y(n119)
         );
  AO22X1_RVT U237 ( .A1(n375), .A2(price[6]), .A3(n204), .A4(n438), .Y(n97) );
  OR2X1_RVT U238 ( .A1(n369), .A2(n204), .Y(n240) );
  AOI21X2_RVT U239 ( .A1(n189), .A2(n153), .A3(rst), .Y(n286) );
  OR3X1_RVT U240 ( .A1(n359), .A2(n436), .A3(n346), .Y(n308) );
  NOR2X0_RVT U241 ( .A1(n227), .A2(n425), .Y(n219) );
  NOR2X0_RVT U242 ( .A1(n227), .A2(n423), .Y(n217) );
  INVX1_RVT U243 ( .A(n289), .Y(n375) );
  INVX0_RVT U244 ( .A(n294), .Y(n314) );
  INVX0_RVT U245 ( .A(n293), .Y(n319) );
  INVX1_RVT U246 ( .A(n311), .Y(n321) );
  INVX0_RVT U247 ( .A(n200), .Y(n196) );
  INVX1_RVT U248 ( .A(n305), .Y(n298) );
  INVX1_RVT U249 ( .A(coin_in[1]), .Y(n341) );
  NOR2X0_RVT U250 ( .A1(n199), .A2(n240), .Y(n190) );
  INVX0_RVT U251 ( .A(n226), .Y(n197) );
  INVX0_RVT U252 ( .A(dispense), .Y(n369) );
  INVX0_RVT U253 ( .A(n258), .Y(n356) );
  INVX1_RVT U254 ( .A(n381), .Y(n383) );
  INVX1_RVT U255 ( .A(n323), .Y(n334) );
  OR2X1_RVT U256 ( .A1(n205), .A2(n191), .Y(n374) );
  INVX0_RVT U257 ( .A(n161), .Y(n205) );
  INVX0_RVT U258 ( .A(n290), .Y(n291) );
  INVX0_RVT U259 ( .A(n370), .Y(n436) );
  INVX0_RVT U260 ( .A(n349), .Y(n350) );
  OR2X2_RVT U261 ( .A1(sel_item[1]), .A2(sel_item[0]), .Y(n227) );
  OR2X1_RVT U262 ( .A1(n233), .A2(n234), .Y(n124) );
  OR2X1_RVT U263 ( .A1(n238), .A2(n239), .Y(n123) );
  OAI21X2_RVT U264 ( .A1(n264), .A2(n423), .A3(n263), .Y(n108) );
  AND2X1_RVT U265 ( .A1(n195), .A2(n286), .Y(n229) );
  NOR2X0_RVT U266 ( .A1(n158), .A2(n253), .Y(n202) );
  OR3X1_RVT U267 ( .A1(n286), .A2(n158), .A3(n253), .Y(n211) );
  OR2X1_RVT U268 ( .A1(n415), .A2(n156), .Y(n256) );
  INVX0_RVT U269 ( .A(n206), .Y(n262) );
  NOR3X2_RVT U270 ( .A1(n421), .A2(n158), .A3(n206), .Y(n242) );
  NAND2X0_RVT U271 ( .A1(n204), .A2(n196), .Y(n214) );
  AO22X1_RVT U272 ( .A1(n203), .A2(n361), .A3(n198), .A4(n197), .Y(n279) );
  NOR4X1_RVT U273 ( .A1(n258), .A2(n148), .A3(rst), .A4(n224), .Y(n198) );
  INVX0_RVT U274 ( .A(n235), .Y(n236) );
  AND2X2_RVT U275 ( .A1(coin_in[1]), .A2(coin_in[0]), .Y(n305) );
  AND2X1_RVT U276 ( .A1(n346), .A2(n306), .Y(n310) );
  NBUFFX2_RVT U277 ( .A(sel_item[0]), .Y(n199) );
  NAND2X0_RVT U278 ( .A1(\u_memory/mem[3][0] ), .A2(sel_item[0]), .Y(n200) );
  OR2X1_RVT U279 ( .A1(n286), .A2(n287), .Y(n288) );
  NAND2X0_RVT U280 ( .A1(n361), .A2(n155), .Y(n281) );
  AND2X1_RVT U281 ( .A1(n201), .A2(n237), .Y(n261) );
  NAND2X0_RVT U282 ( .A1(n349), .A2(n151), .Y(n201) );
  AO21X1_RVT U283 ( .A1(n202), .A2(n206), .A3(n241), .Y(n107) );
  OR2X2_RVT U284 ( .A1(rst), .A2(n279), .Y(n278) );
  MUX21X1_RVT U285 ( .A1(\u_memory/mem[1][2] ), .A2(n210), .S0(n228), .Y(n117)
         );
  OR2X1_RVT U286 ( .A1(n427), .A2(n289), .Y(n207) );
  OR2X1_RVT U287 ( .A1(n408), .A2(n289), .Y(n208) );
  OR2X1_RVT U288 ( .A1(n405), .A2(n289), .Y(n209) );
  OR2X1_RVT U289 ( .A1(n285), .A2(n158), .Y(n210) );
  AOI21X1_RVT U290 ( .A1(n312), .A2(n314), .A3(n299), .Y(n300) );
  OAI21X1_RVT U291 ( .A1(n330), .A2(n334), .A3(n331), .Y(n328) );
  OR2X1_RVT U292 ( .A1(n310), .A2(n309), .Y(n82) );
  AND3X1_RVT U296 ( .A1(state_out[1]), .A2(n403), .A3(n429), .Y(n372) );
  NAND2X0_RVT U297 ( .A1(n372), .A2(n431), .Y(n212) );
  NAND2X0_RVT U298 ( .A1(n361), .A2(n212), .Y(n289) );
  OR2X1_RVT U309 ( .A1(n402), .A2(state_out[2]), .Y(n213) );
  NOR2X0_RVT U310 ( .A1(n213), .A2(n403), .Y(dispense) );
  AND2X1_RVT U311 ( .A1(n354), .A2(n356), .Y(n247) );
  INVX0_RVT U312 ( .A(n247), .Y(n216) );
  OA21X1_RVT U313 ( .A1(n356), .A2(n354), .A3(n216), .Y(n257) );
  NOR2X0_RVT U314 ( .A1(n158), .A2(n257), .Y(n243) );
  AO21X1_RVT U315 ( .A1(n243), .A2(n228), .A3(n229), .Y(n118) );
  NOR2X0_RVT U316 ( .A1(n424), .A2(n282), .Y(n234) );
  NOR2X0_RVT U317 ( .A1(n154), .A2(n281), .Y(n233) );
  NOR2X0_RVT U318 ( .A1(n426), .A2(n282), .Y(n239) );
  NOR2X0_RVT U319 ( .A1(n253), .A2(n281), .Y(n238) );
  AO21X1_RVT U320 ( .A1(n243), .A2(n264), .A3(n242), .Y(n110) );
  INVX1_RVT U321 ( .A(n279), .Y(n259) );
  NOR2X0_RVT U322 ( .A1(n410), .A2(n259), .Y(n250) );
  INVX0_RVT U323 ( .A(n285), .Y(n248) );
  NOR2X0_RVT U324 ( .A1(n278), .A2(n248), .Y(n249) );
  OR2X1_RVT U325 ( .A1(n250), .A2(n249), .Y(n133) );
  NOR2X0_RVT U326 ( .A1(n413), .A2(n259), .Y(n252) );
  NOR2X0_RVT U327 ( .A1(n278), .A2(n154), .Y(n251) );
  OR2X1_RVT U328 ( .A1(n252), .A2(n251), .Y(n132) );
  NOR2X0_RVT U329 ( .A1(n416), .A2(n259), .Y(n255) );
  NOR2X0_RVT U330 ( .A1(n253), .A2(n278), .Y(n254) );
  OR2X1_RVT U331 ( .A1(n255), .A2(n254), .Y(n131) );
  AND3X1_RVT U332 ( .A1(state_out[0]), .A2(state_out[2]), .A3(n402), .Y(error)
         );
  NOR2X0_RVT U333 ( .A1(rst), .A2(cancel), .Y(n370) );
  AND2X1_RVT U334 ( .A1(n361), .A2(n289), .Y(n438) );
  NAND2X0_RVT U335 ( .A1(n256), .A2(n211), .Y(n115) );
  NAND2X0_RVT U336 ( .A1(n257), .A2(n361), .Y(n260) );
  MUX21X1_RVT U337 ( .A1(\u_memory/mem[2][1] ), .A2(n260), .S0(n282), .Y(n126)
         );
  NAND2X0_RVT U338 ( .A1(n361), .A2(n258), .Y(n277) );
  MUX21X1_RVT U339 ( .A1(\u_memory/mem[2][0] ), .A2(n277), .S0(n282), .Y(n127)
         );
  MUX21X1_RVT U340 ( .A1(\u_memory/mem[3][1] ), .A2(n260), .S0(n259), .Y(n134)
         );
  MUX21X1_RVT U341 ( .A1(\u_memory/mem[0][2] ), .A2(n210), .S0(n264), .Y(n109)
         );
  MUX21X1_RVT U342 ( .A1(\u_memory/mem[0][0] ), .A2(n277), .S0(n264), .Y(n111)
         );
  INVX0_RVT U343 ( .A(\intadd_18/n1 ), .Y(n382) );
  NAND2X0_RVT U344 ( .A1(n432), .A2(n404), .Y(n265) );
  NOR4X1_RVT U345 ( .A1(stock[1]), .A2(stock[3]), .A3(stock[2]), .A4(n265), 
        .Y(n266) );
  AO21X1_RVT U346 ( .A1(n433), .A2(n382), .A3(n266), .Y(n365) );
  AND4X1_RVT U347 ( .A1(state_out[1]), .A2(\u_control_unit/check_wait ), .A3(
        n429), .A4(n365), .Y(n267) );
  OR3X1_RVT U348 ( .A1(dispense), .A2(error), .A3(n267), .Y(n435) );
  NOR3X0_RVT U349 ( .A1(state_out[1]), .A2(confirm), .A3(n403), .Y(n268) );
  INVX0_RVT U350 ( .A(n268), .Y(n271) );
  INVX0_RVT U351 ( .A(error), .Y(n270) );
  NAND2X0_RVT U352 ( .A1(\u_control_unit/check_wait ), .A2(n372), .Y(n269) );
  AND3X1_RVT U353 ( .A1(n271), .A2(n270), .A3(n269), .Y(n272) );
  NOR2X0_RVT U354 ( .A1(n436), .A2(n272), .Y(n276) );
  OR2X1_RVT U355 ( .A1(coin_in[0]), .A2(n149), .Y(n274) );
  AND2X1_RVT U356 ( .A1(n429), .A2(n402), .Y(n273) );
  NAND3X0_RVT U357 ( .A1(n370), .A2(n274), .A3(n273), .Y(n307) );
  NOR2X0_RVT U358 ( .A1(state_out[0]), .A2(n307), .Y(n275) );
  OR2X1_RVT U359 ( .A1(n276), .A2(n275), .Y(\u_control_unit/N20 ) );
  INVX0_RVT U360 ( .A(n278), .Y(n280) );
  AO22X1_RVT U361 ( .A1(n280), .A2(n152), .A3(n279), .A4(\u_memory/mem[3][0] ), 
        .Y(n135) );
  INVX0_RVT U362 ( .A(n281), .Y(n284) );
  INVX0_RVT U363 ( .A(n282), .Y(n283) );
  AO22X1_RVT U364 ( .A1(n285), .A2(n284), .A3(\u_memory/mem[2][2] ), .A4(n283), 
        .Y(n125) );
  OAI21X2_RVT U365 ( .A1(n156), .A2(n411), .A3(n288), .Y(n116) );
  NOR2X0_RVT U366 ( .A1(n173), .A2(n291), .Y(n292) );
  AO21X1_RVT U367 ( .A1(n375), .A2(stock[4]), .A3(n292), .Y(n92) );
  OR2X1_RVT U368 ( .A1(n429), .A2(state_out[1]), .Y(n368) );
  NOR2X0_RVT U369 ( .A1(state_out[0]), .A2(n368), .Y(n359) );
  INVX0_RVT U370 ( .A(n307), .Y(n346) );
  INVX1_RVT U371 ( .A(n308), .Y(n348) );
  NOR2X0_RVT U372 ( .A1(display[4]), .A2(n298), .Y(n293) );
  NOR2X0_RVT U373 ( .A1(display[5]), .A2(n149), .Y(n294) );
  NAND2X0_RVT U374 ( .A1(n319), .A2(n314), .Y(n301) );
  NAND2X0_RVT U375 ( .A1(display[0]), .A2(n341), .Y(n343) );
  INVX0_RVT U376 ( .A(coin_in[0]), .Y(n295) );
  NOR2X0_RVT U377 ( .A1(display[1]), .A2(n295), .Y(n336) );
  NAND2X0_RVT U378 ( .A1(n295), .A2(display[1]), .Y(n337) );
  NOR2X0_RVT U379 ( .A1(display[2]), .A2(n305), .Y(n330) );
  NOR2X0_RVT U380 ( .A1(display[3]), .A2(n341), .Y(n324) );
  NOR2X0_RVT U381 ( .A1(n330), .A2(n324), .Y(n297) );
  NAND2X0_RVT U382 ( .A1(n305), .A2(display[2]), .Y(n331) );
  NAND2X0_RVT U383 ( .A1(n341), .A2(display[3]), .Y(n325) );
  OAI21X1_RVT U384 ( .A1(n331), .A2(n324), .A3(n325), .Y(n296) );
  AOI21X1_RVT U385 ( .A1(n323), .A2(n297), .A3(n296), .Y(n311) );
  NAND2X0_RVT U386 ( .A1(n298), .A2(display[4]), .Y(n318) );
  INVX0_RVT U387 ( .A(n318), .Y(n312) );
  NAND2X0_RVT U388 ( .A1(n149), .A2(display[5]), .Y(n313) );
  INVX0_RVT U389 ( .A(n313), .Y(n299) );
  OAI21X2_RVT U390 ( .A1(n301), .A2(n311), .A3(n300), .Y(n304) );
  XOR2X1_RVT U391 ( .A1(n302), .A2(display[7]), .Y(n303) );
  AO22X1_RVT U392 ( .A1(n348), .A2(display[7]), .A3(n303), .A4(n346), .Y(n81)
         );
  FADDX1_RVT U393 ( .A(display[6]), .B(n305), .CI(n304), .CO(n302), .S(n306)
         );
  NOR2X0_RVT U394 ( .A1(n434), .A2(n308), .Y(n309) );
  AOI21X1_RVT U395 ( .A1(n321), .A2(n319), .A3(n312), .Y(n316) );
  NAND2X0_RVT U396 ( .A1(n314), .A2(n313), .Y(n315) );
  AO22X1_RVT U397 ( .A1(n348), .A2(display[5]), .A3(n317), .A4(n346), .Y(n83)
         );
  NAND2X0_RVT U398 ( .A1(n319), .A2(n318), .Y(n320) );
  XNOR2X1_RVT U399 ( .A1(n321), .A2(n320), .Y(n322) );
  AO22X1_RVT U400 ( .A1(n348), .A2(display[4]), .A3(n322), .A4(n346), .Y(n84)
         );
  INVX0_RVT U401 ( .A(n324), .Y(n326) );
  NAND2X0_RVT U402 ( .A1(n326), .A2(n325), .Y(n327) );
  XNOR2X1_RVT U403 ( .A1(n328), .A2(n327), .Y(n329) );
  AO22X1_RVT U404 ( .A1(n348), .A2(display[3]), .A3(n329), .A4(n346), .Y(n85)
         );
  INVX0_RVT U405 ( .A(n330), .Y(n332) );
  NAND2X0_RVT U406 ( .A1(n332), .A2(n331), .Y(n333) );
  XOR2X1_RVT U407 ( .A1(n334), .A2(n333), .Y(n335) );
  AO22X1_RVT U408 ( .A1(n348), .A2(display[2]), .A3(n335), .A4(n346), .Y(n86)
         );
  INVX0_RVT U409 ( .A(n336), .Y(n338) );
  NAND2X0_RVT U410 ( .A1(n338), .A2(n337), .Y(n339) );
  XOR2X1_RVT U411 ( .A1(n339), .A2(n343), .Y(n340) );
  AO22X1_RVT U412 ( .A1(n348), .A2(display[1]), .A3(n340), .A4(n346), .Y(n88)
         );
  NOR2X0_RVT U413 ( .A1(display[0]), .A2(n150), .Y(n342) );
  INVX0_RVT U414 ( .A(n342), .Y(n344) );
  NAND2X0_RVT U415 ( .A1(n344), .A2(n343), .Y(n345) );
  INVX0_RVT U416 ( .A(n345), .Y(n347) );
  AO22X1_RVT U417 ( .A1(n348), .A2(display[0]), .A3(n347), .A4(n346), .Y(n87)
         );
  NOR2X0_RVT U418 ( .A1(n173), .A2(n350), .Y(n351) );
  AO21X1_RVT U419 ( .A1(n375), .A2(stock[3]), .A3(n351), .Y(n93) );
  NOR2X0_RVT U420 ( .A1(n173), .A2(n352), .Y(n353) );
  AO21X1_RVT U421 ( .A1(n375), .A2(stock[2]), .A3(n353), .Y(n94) );
  NOR2X0_RVT U422 ( .A1(n173), .A2(n354), .Y(n355) );
  AO21X1_RVT U423 ( .A1(n375), .A2(stock[1]), .A3(n355), .Y(n95) );
  NOR2X0_RVT U424 ( .A1(n173), .A2(n152), .Y(n357) );
  AO21X1_RVT U425 ( .A1(n375), .A2(stock[0]), .A3(n357), .Y(n96) );
  OR2X1_RVT U426 ( .A1(n405), .A2(display[0]), .Y(n376) );
  OR2X1_RVT U427 ( .A1(n376), .A2(display[1]), .Y(n358) );
  AO22X1_RVT U428 ( .A1(display[1]), .A2(n376), .A3(n358), .A4(n406), .Y(
        \intadd_18/CI ) );
  INVX0_RVT U429 ( .A(n359), .Y(n360) );
  NOR2X0_RVT U430 ( .A1(n360), .A2(n436), .Y(n386) );
  AND2X1_RVT U431 ( .A1(n370), .A2(n368), .Y(n388) );
  AND2X1_RVT U432 ( .A1(change_out[6]), .A2(n388), .Y(n363) );
  OA21X1_RVT U433 ( .A1(cancel), .A2(error), .A3(n361), .Y(n381) );
  NOR2X0_RVT U434 ( .A1(n434), .A2(n383), .Y(n362) );
  OR2X1_RVT U435 ( .A1(n363), .A2(n362), .Y(n364) );
  AO21X1_RVT U436 ( .A1(n386), .A2(\intadd_18/SUM[4] ), .A3(n364), .Y(n74) );
  AND4X1_RVT U437 ( .A1(state_out[0]), .A2(confirm), .A3(n429), .A4(n402), .Y(
        n367) );
  NAND2X0_RVT U438 ( .A1(\u_control_unit/check_wait ), .A2(n365), .Y(n366) );
  OA221X1_RVT U439 ( .A1(n367), .A2(n372), .A3(n367), .A4(n366), .A5(n370), 
        .Y(\u_control_unit/N21 ) );
  NAND2X0_RVT U440 ( .A1(n369), .A2(n368), .Y(n371) );
  OA221X1_RVT U441 ( .A1(\u_control_unit/check_wait ), .A2(n372), .A3(n431), 
        .A4(n371), .A5(n370), .Y(n136) );
  AO22X1_RVT U442 ( .A1(n375), .A2(price[1]), .A3(n438), .A4(n374), .Y(n102)
         );
  AO22X1_RVT U443 ( .A1(n199), .A2(n438), .A3(n375), .A4(price[5]), .Y(n98) );
  AO21X1_RVT U444 ( .A1(n386), .A2(n405), .A3(n381), .Y(n377) );
  INVX0_RVT U445 ( .A(n376), .Y(n378) );
  AO222X1_RVT U446 ( .A1(n377), .A2(display[0]), .A3(n388), .A4(change_out[0]), 
        .A5(n386), .A6(n378), .Y(n80) );
  FADDX1_RVT U447 ( .A(price[1]), .B(n378), .CI(display[1]), .S(n379) );
  AO22X1_RVT U448 ( .A1(n386), .A2(n379), .A3(n388), .A4(change_out[1]), .Y(
        n380) );
  AO21X1_RVT U449 ( .A1(n381), .A2(display[1]), .A3(n380), .Y(n79) );
  AO222X1_RVT U450 ( .A1(n381), .A2(display[2]), .A3(n388), .A4(change_out[2]), 
        .A5(\intadd_18/SUM[0] ), .A6(n386), .Y(n78) );
  AO222X1_RVT U451 ( .A1(n381), .A2(display[3]), .A3(n388), .A4(change_out[3]), 
        .A5(\intadd_18/SUM[1] ), .A6(n386), .Y(n77) );
  AO222X1_RVT U452 ( .A1(n381), .A2(display[4]), .A3(n388), .A4(change_out[4]), 
        .A5(\intadd_18/SUM[2] ), .A6(n386), .Y(n76) );
  AO222X1_RVT U453 ( .A1(n381), .A2(display[5]), .A3(n388), .A4(change_out[5]), 
        .A5(\intadd_18/SUM[3] ), .A6(n386), .Y(n75) );
  XOR2X1_RVT U454 ( .A1(display[7]), .A2(n382), .Y(n385) );
  NOR2X0_RVT U455 ( .A1(n433), .A2(n383), .Y(n384) );
  AO21X1_RVT U456 ( .A1(n386), .A2(n385), .A3(n384), .Y(n387) );
  AO21X1_RVT U457 ( .A1(n388), .A2(change_out[7]), .A3(n387), .Y(n73) );
endmodule

