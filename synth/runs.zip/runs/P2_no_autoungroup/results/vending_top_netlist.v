/////////////////////////////////////////////////////////////
// Created by: Synopsys DC Ultra(TM) in wire load mode
// Version   : X-2025.06-SP2
// Date      : Thu Jul  9 13:24:35 2026
/////////////////////////////////////////////////////////////


module credit_reg ( clk, rst, cancel, clear, load, coin_value, credit );
  input [7:0] coin_value;
  output [7:0] credit;
  input clk, rst, cancel, clear, load;
  wire   n4, n5, n6, n7, n8, n9, n10, n11, n2, n3, n12, n13, n14, n15, n16,
         n17, n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28, n29, n30,
         n31, n32, n33, n34, n35, n36, n37, n38, n39, n40, n41, n42, n43, n44,
         n45;

  DFFX1_RVT \credit_reg[7]  ( .D(n4), .CLK(clk), .Q(credit[7]), .QN(n45) );
  DFFX1_RVT \credit_reg[6]  ( .D(n5), .CLK(clk), .Q(credit[6]) );
  DFFX1_RVT \credit_reg[5]  ( .D(n6), .CLK(clk), .Q(credit[5]), .QN(n40) );
  DFFX1_RVT \credit_reg[4]  ( .D(n7), .CLK(clk), .Q(credit[4]), .QN(n41) );
  DFFX1_RVT \credit_reg[3]  ( .D(n8), .CLK(clk), .Q(credit[3]), .QN(n42) );
  DFFX1_RVT \credit_reg[2]  ( .D(n9), .CLK(clk), .Q(credit[2]), .QN(n43) );
  DFFX1_RVT \credit_reg[1]  ( .D(n10), .CLK(clk), .Q(credit[1]), .QN(n44) );
  DFFX1_RVT \credit_reg[0]  ( .D(n11), .CLK(clk), .Q(credit[0]) );
  OR2X1_RVT U3 ( .A1(clear), .A2(cancel), .Y(n2) );
  OR3X1_RVT U4 ( .A1(rst), .A2(load), .A3(n2), .Y(n34) );
  NOR3X0_RVT U5 ( .A1(rst), .A2(cancel), .A3(clear), .Y(n3) );
  NAND2X0_RVT U6 ( .A1(load), .A2(n3), .Y(n37) );
  HADDX1_RVT U7 ( .A0(n12), .B0(credit[7]), .SO(n13) );
  INVX0_RVT U8 ( .A(n13), .Y(n14) );
  OAI22X1_RVT U9 ( .A1(n34), .A2(n45), .A3(n37), .A4(n14), .Y(n4) );
  INVX0_RVT U10 ( .A(n34), .Y(n39) );
  FADDX1_RVT U11 ( .A(coin_value[6]), .B(credit[6]), .CI(n15), .CO(n12), .S(
        n16) );
  INVX0_RVT U12 ( .A(n16), .Y(n17) );
  NOR2X0_RVT U13 ( .A1(n37), .A2(n17), .Y(n18) );
  AO21X1_RVT U14 ( .A1(n39), .A2(credit[6]), .A3(n18), .Y(n5) );
  FADDX1_RVT U15 ( .A(coin_value[5]), .B(credit[5]), .CI(n19), .CO(n15), .S(
        n20) );
  INVX0_RVT U16 ( .A(n20), .Y(n21) );
  OAI22X1_RVT U17 ( .A1(n34), .A2(n40), .A3(n37), .A4(n21), .Y(n6) );
  FADDX1_RVT U18 ( .A(coin_value[4]), .B(credit[4]), .CI(n22), .CO(n19), .S(
        n23) );
  INVX0_RVT U19 ( .A(n23), .Y(n24) );
  OAI22X1_RVT U20 ( .A1(n34), .A2(n41), .A3(n37), .A4(n24), .Y(n7) );
  FADDX1_RVT U21 ( .A(coin_value[3]), .B(credit[3]), .CI(n25), .CO(n22), .S(
        n26) );
  INVX0_RVT U22 ( .A(n26), .Y(n27) );
  OAI22X1_RVT U23 ( .A1(n34), .A2(n42), .A3(n37), .A4(n27), .Y(n8) );
  FADDX1_RVT U24 ( .A(coin_value[2]), .B(credit[2]), .CI(n28), .CO(n25), .S(
        n29) );
  INVX0_RVT U25 ( .A(n29), .Y(n30) );
  OAI22X1_RVT U26 ( .A1(n34), .A2(n43), .A3(n37), .A4(n30), .Y(n9) );
  FADDX1_RVT U27 ( .A(coin_value[1]), .B(credit[1]), .CI(n31), .CO(n28), .S(
        n32) );
  INVX0_RVT U28 ( .A(n32), .Y(n33) );
  OAI22X1_RVT U29 ( .A1(n34), .A2(n44), .A3(n37), .A4(n33), .Y(n10) );
  HADDX1_RVT U30 ( .A0(coin_value[0]), .B0(credit[0]), .C1(n31), .SO(n35) );
  INVX0_RVT U31 ( .A(n35), .Y(n36) );
  NOR2X0_RVT U32 ( .A1(n37), .A2(n36), .Y(n38) );
  AO21X1_RVT U33 ( .A1(n39), .A2(credit[0]), .A3(n38), .Y(n11) );
endmodule


module memory ( clk, rst, mem_read, mem_write, addr, price, stock );
  input [1:0] addr;
  output [7:0] price;
  output [7:0] stock;
  input clk, rst, mem_read, mem_write;
  wire   \mem[0][5] , \mem[0][4] , \mem[0][3] , \mem[0][2] , \mem[0][1] ,
         \mem[0][0] , \mem[1][5] , \mem[1][4] , \mem[1][3] , \mem[1][2] ,
         \mem[1][1] , \mem[2][5] , \mem[2][4] , \mem[2][3] , \mem[2][2] ,
         \mem[2][0] , \mem[3][5] , \mem[3][4] , \mem[3][3] , \mem[3][2] ,
         \mem[3][1] , \mem[3][0] , n30, n31, n32, n33, n34, n35, n36, n38, n39,
         n40, n41, n42, n43, n44, n47, n48, n49, n50, n51, n52, n55, n56, n57,
         n58, n59, n60, n63, n64, n65, n66, n67, n68, n71, n72, n73, n74, n75,
         n76, n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15,
         n16, n17, n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28, n29,
         n37, n45, n46, n53, n54, n61, n62, n69, n70, n77, n78, n79, n80, n81,
         n82, n83, n84, n85, n86, n87, n88, n89, n90, n91, n92, n93, n94, n95,
         n96, n97, n98, n99, n100, n101, n102, n103, n104, n105, n106, n107,
         n108, n109, n110, n111, n112, n113, n114, n115, n116, n117, n118,
         n119, n120, n121, n122, n123, n124, n125, n126, n127, n128, n129,
         n130, n131, n132, n133, n134, n135, n136, n137, n138, n139, n140,
         n141, n142, n143, n144, n145, n146, n147, n148, n149, n150, n151,
         n152, n153, n154, n155, n156, n157, n158, n159, n160, n161, n162,
         n163, n164, n165, n166, n167, n168, n169, n170;

  DFFX1_RVT \price_reg[5]  ( .D(n43), .CLK(clk), .Q(price[5]) );
  DFFX1_RVT \price_reg[3]  ( .D(n41), .CLK(clk), .Q(price[3]) );
  DFFX1_RVT \price_reg[2]  ( .D(n40), .CLK(clk), .Q(price[2]) );
  DFFX1_RVT \price_reg[1]  ( .D(n39), .CLK(clk), .Q(price[1]) );
  DFFX1_RVT \price_reg[0]  ( .D(n38), .CLK(clk), .Q(price[0]) );
  DFFX1_RVT \stock_reg[6]  ( .D(n36), .CLK(clk), .Q(stock[6]) );
  DFFX1_RVT \stock_reg[5]  ( .D(n35), .CLK(clk), .Q(stock[5]) );
  DFFX1_RVT \stock_reg[4]  ( .D(n34), .CLK(clk), .Q(stock[4]) );
  DFFX1_RVT \stock_reg[3]  ( .D(n33), .CLK(clk), .Q(stock[3]) );
  DFFX1_RVT \stock_reg[2]  ( .D(n32), .CLK(clk), .Q(stock[2]) );
  DFFX1_RVT \stock_reg[1]  ( .D(n31), .CLK(clk), .Q(stock[1]) );
  DFFX1_RVT \stock_reg[0]  ( .D(n30), .CLK(clk), .Q(stock[0]) );
  DFFX1_RVT \mem_reg[3][0]  ( .D(n76), .CLK(clk), .Q(\mem[3][0] ), .QN(n159)
         );
  DFFX1_RVT \mem_reg[3][2]  ( .D(n74), .CLK(clk), .Q(\mem[3][2] ) );
  DFFX1_RVT \mem_reg[2][4]  ( .D(n64), .CLK(clk), .Q(\mem[2][4] ), .QN(n162)
         );
  DFFX1_RVT \mem_reg[1][2]  ( .D(n58), .CLK(clk), .Q(\mem[1][2] ) );
  DFFX1_RVT \mem_reg[1][4]  ( .D(n56), .CLK(clk), .Q(\mem[1][4] ), .QN(n158)
         );
  DFFX1_RVT \mem_reg[0][0]  ( .D(n52), .CLK(clk), .Q(\mem[0][0] ), .QN(n166)
         );
  DFFX1_RVT \mem_reg[0][1]  ( .D(n51), .CLK(clk), .Q(\mem[0][1] ), .QN(n168)
         );
  DFFX1_RVT \mem_reg[0][4]  ( .D(n48), .CLK(clk), .Q(\mem[0][4] ), .QN(n164)
         );
  DFFX1_RVT \mem_reg[1][1]  ( .D(n59), .CLK(clk), .Q(\mem[1][1] ), .QN(n169)
         );
  DFFX1_RVT \mem_reg[1][5]  ( .D(n55), .CLK(clk), .Q(\mem[1][5] ), .QN(n170)
         );
  DFFX2_RVT \mem_reg[0][2]  ( .D(n50), .CLK(clk), .Q(\mem[0][2] ) );
  DFFX2_RVT \mem_reg[0][5]  ( .D(n47), .CLK(clk), .Q(\mem[0][5] ) );
  DFFX2_RVT \mem_reg[1][0]  ( .D(n60), .CLK(clk), .QN(n160) );
  DFFX2_RVT \mem_reg[2][1]  ( .D(n67), .CLK(clk), .QN(n167) );
  DFFX2_RVT \mem_reg[2][5]  ( .D(n63), .CLK(clk), .Q(\mem[2][5] ) );
  DFFX2_RVT \mem_reg[3][3]  ( .D(n73), .CLK(clk), .Q(\mem[3][3] ), .QN(n155)
         );
  DFFX2_RVT \mem_reg[0][3]  ( .D(n49), .CLK(clk), .Q(\mem[0][3] ), .QN(n163)
         );
  DFFX2_RVT \mem_reg[2][3]  ( .D(n65), .CLK(clk), .Q(\mem[2][3] ), .QN(n161)
         );
  DFFX2_RVT \mem_reg[1][3]  ( .D(n57), .CLK(clk), .Q(\mem[1][3] ), .QN(n157)
         );
  DFFX2_RVT \mem_reg[2][0]  ( .D(n68), .CLK(clk), .Q(\mem[2][0] ), .QN(n165)
         );
  DFFX2_RVT \price_reg[4]  ( .D(n42), .CLK(clk), .Q(price[4]) );
  DFFX2_RVT \price_reg[6]  ( .D(n44), .CLK(clk), .Q(price[6]) );
  DFFX2_RVT \mem_reg[3][4]  ( .D(n72), .CLK(clk), .Q(\mem[3][4] ), .QN(n156)
         );
  DFFX2_RVT \mem_reg[3][5]  ( .D(n71), .CLK(clk), .Q(\mem[3][5] ) );
  DFFX2_RVT \mem_reg[3][1]  ( .D(n75), .CLK(clk), .Q(\mem[3][1] ) );
  DFFX2_RVT \mem_reg[2][2]  ( .D(n66), .CLK(clk), .Q(\mem[2][2] ) );
  OR2X1_RVT U3 ( .A1(n102), .A2(n101), .Y(n145) );
  OR2X1_RVT U4 ( .A1(n78), .A2(n16), .Y(n105) );
  AND2X1_RVT U5 ( .A1(addr[1]), .A2(addr[0]), .Y(n54) );
  OR2X1_RVT U6 ( .A1(n96), .A2(n95), .Y(n146) );
  NBUFFX8_RVT U7 ( .A(rst), .Y(n135) );
  NOR2X0_RVT U8 ( .A1(n122), .A2(n120), .Y(n7) );
  AO22X1_RVT U9 ( .A1(n2), .A2(n1), .A3(n137), .A4(n125), .Y(n67) );
  OR2X2_RVT U10 ( .A1(rst), .A2(n7), .Y(n137) );
  INVX0_RVT U11 ( .A(n167), .Y(n1) );
  INVX0_RVT U12 ( .A(n7), .Y(n2) );
  OR2X2_RVT U13 ( .A1(n129), .A2(n135), .Y(n81) );
  NBUFFX2_RVT U14 ( .A(n86), .Y(n3) );
  AO21X1_RVT U15 ( .A1(n89), .A2(n83), .A3(n82), .Y(n88) );
  INVX0_RVT U16 ( .A(n135), .Y(n4) );
  NAND2X0_RVT U17 ( .A1(n115), .A2(n4), .Y(n91) );
  AO22X1_RVT U18 ( .A1(n142), .A2(\mem[0][3] ), .A3(n5), .A4(n128), .Y(n49) );
  AO22X1_RVT U19 ( .A1(n142), .A2(\mem[0][1] ), .A3(n5), .A4(n126), .Y(n51) );
  AO22X1_RVT U20 ( .A1(n142), .A2(\mem[0][4] ), .A3(n5), .A4(n130), .Y(n48) );
  AO21X1_RVT U21 ( .A1(n143), .A2(n5), .A3(n87), .Y(n52) );
  INVX2_RVT U22 ( .A(n115), .Y(n5) );
  OR2X2_RVT U23 ( .A1(n122), .A2(n109), .Y(n115) );
  NBUFFX2_RVT U24 ( .A(n7), .Y(n6) );
  AO22X1_RVT U25 ( .A1(n134), .A2(\mem[2][2] ), .A3(n6), .A4(n88), .Y(n66) );
  AO22X1_RVT U26 ( .A1(n134), .A2(\mem[2][3] ), .A3(n6), .A4(n128), .Y(n65) );
  AO22X1_RVT U27 ( .A1(n134), .A2(\mem[2][4] ), .A3(n6), .A4(n130), .Y(n64) );
  OR3X1_RVT U28 ( .A1(n135), .A2(n13), .A3(n69), .Y(n127) );
  INVX1_RVT U29 ( .A(n89), .Y(n11) );
  NBUFFX2_RVT U30 ( .A(n90), .Y(n8) );
  AND2X1_RVT U31 ( .A1(n8), .A2(n89), .Y(n13) );
  AO21X1_RVT U32 ( .A1(n8), .A2(n10), .A3(n9), .Y(n118) );
  AOI21X1_RVT U33 ( .A1(n89), .A2(n90), .A3(n147), .Y(n9) );
  NOR2X0_RVT U34 ( .A1(n12), .A2(n11), .Y(n10) );
  INVX1_RVT U35 ( .A(n147), .Y(n12) );
  OR2X2_RVT U36 ( .A1(n107), .A2(n86), .Y(n121) );
  AO21X1_RVT U37 ( .A1(n86), .A2(n20), .A3(n29), .Y(n92) );
  OR2X1_RVT U38 ( .A1(n46), .A2(n3), .Y(n150) );
  INVX0_RVT U39 ( .A(addr[1]), .Y(n14) );
  INVX1_RVT U40 ( .A(n23), .Y(n26) );
  OR2X1_RVT U41 ( .A1(addr[0]), .A2(n16), .Y(n120) );
  INVX1_RVT U42 ( .A(n92), .Y(n85) );
  INVX0_RVT U43 ( .A(n78), .Y(n77) );
  NOR2X0_RVT U44 ( .A1(n135), .A2(n118), .Y(n128) );
  INVX0_RVT U45 ( .A(n112), .Y(n113) );
  NOR2X0_RVT U46 ( .A1(rst), .A2(n108), .Y(n142) );
  NOR2X0_RVT U47 ( .A1(n135), .A2(n119), .Y(n134) );
  NOR2X0_RVT U48 ( .A1(n135), .A2(n98), .Y(n133) );
  INVX0_RVT U49 ( .A(addr[0]), .Y(n78) );
  INVX0_RVT U50 ( .A(addr[0]), .Y(n46) );
  INVX0_RVT U51 ( .A(n132), .Y(n24) );
  NOR2X0_RVT U52 ( .A1(n160), .A2(n140), .Y(n141) );
  OAI22X1_RVT U53 ( .A1(n157), .A2(n46), .A3(n163), .A4(addr[0]), .Y(n15) );
  NAND2X0_RVT U54 ( .A1(n86), .A2(mem_write), .Y(n16) );
  NAND2X0_RVT U55 ( .A1(\mem[3][1] ), .A2(addr[0]), .Y(n17) );
  AND2X1_RVT U56 ( .A1(addr[0]), .A2(\mem[3][2] ), .Y(n18) );
  NAND2X0_RVT U57 ( .A1(\mem[0][5] ), .A2(n46), .Y(n19) );
  OAI22X1_RVT U58 ( .A1(n156), .A2(n78), .A3(n162), .A4(addr[0]), .Y(n20) );
  OAI22X1_RVT U59 ( .A1(n155), .A2(n46), .A3(n161), .A4(addr[0]), .Y(n21) );
  NOR3X0_RVT U60 ( .A1(rst), .A2(n114), .A3(n113), .Y(n22) );
  NOR2X0_RVT U61 ( .A1(n46), .A2(n121), .Y(n23) );
  AO22X1_RVT U62 ( .A1(n24), .A2(\mem[3][1] ), .A3(n93), .A4(n125), .Y(n75) );
  OR2X2_RVT U63 ( .A1(n135), .A2(n132), .Y(n93) );
  AO22X1_RVT U64 ( .A1(n142), .A2(\mem[0][5] ), .A3(n91), .A4(n22), .Y(n47) );
  AO22X1_RVT U65 ( .A1(n134), .A2(\mem[2][5] ), .A3(n137), .A4(n22), .Y(n63)
         );
  NOR2X2_RVT U66 ( .A1(n122), .A2(n105), .Y(n132) );
  AO22X1_RVT U67 ( .A1(n133), .A2(\mem[3][5] ), .A3(n93), .A4(n22), .Y(n71) );
  AOI21X1_RVT U68 ( .A1(n84), .A2(n112), .A3(rst), .Y(n130) );
  NOR3X0_RVT U69 ( .A1(n135), .A2(n89), .A3(n62), .Y(n82) );
  AO22X1_RVT U70 ( .A1(n133), .A2(\mem[3][2] ), .A3(n132), .A4(n88), .Y(n74)
         );
  AO22X1_RVT U71 ( .A1(n115), .A2(\mem[0][2] ), .A3(n91), .A4(n127), .Y(n50)
         );
  AO21X1_RVT U72 ( .A1(n81), .A2(n143), .A3(n141), .Y(n60) );
  AO22X1_RVT U73 ( .A1(n152), .A2(n15), .A3(n86), .A4(n21), .Y(n147) );
  OAI22X1_RVT U74 ( .A1(n167), .A2(n149), .A3(n152), .A4(n17), .Y(n96) );
  AND2X1_RVT U75 ( .A1(n54), .A2(n153), .Y(n117) );
  NBUFFX2_RVT U76 ( .A(n129), .Y(n25) );
  NOR2X0_RVT U77 ( .A1(n122), .A2(n26), .Y(n129) );
  AO22X1_RVT U78 ( .A1(\mem[1][2] ), .A2(n27), .A3(n81), .A4(n127), .Y(n58) );
  INVX0_RVT U79 ( .A(n129), .Y(n27) );
  NOR2X0_RVT U80 ( .A1(n28), .A2(n86), .Y(n110) );
  OA21X1_RVT U81 ( .A1(n170), .A2(n46), .A3(n19), .Y(n28) );
  AND2X1_RVT U82 ( .A1(n86), .A2(n45), .Y(n111) );
  AO21X1_RVT U83 ( .A1(n86), .A2(n37), .A3(n29), .Y(n53) );
  NOR2X0_RVT U84 ( .A1(n103), .A2(addr[1]), .Y(n29) );
  OR2X1_RVT U85 ( .A1(n20), .A2(n45), .Y(n37) );
  AND2X1_RVT U86 ( .A1(\mem[2][5] ), .A2(n46), .Y(n45) );
  NOR3X0_RVT U87 ( .A1(n110), .A2(n61), .A3(n53), .Y(n104) );
  AND2X1_RVT U88 ( .A1(\mem[3][5] ), .A2(n54), .Y(n61) );
  OR3X1_RVT U89 ( .A1(n61), .A2(n111), .A3(n110), .Y(n148) );
  NBUFFX2_RVT U90 ( .A(n90), .Y(n62) );
  NAND4X0_RVT U91 ( .A1(n85), .A2(n12), .A3(n89), .A4(n90), .Y(n112) );
  NOR4X1_RVT U92 ( .A1(n101), .A2(n95), .A3(n102), .A4(n96), .Y(n90) );
  NOR2X0_RVT U93 ( .A1(n62), .A2(n89), .Y(n69) );
  AO21X1_RVT U94 ( .A1(n14), .A2(n70), .A3(n80), .Y(n106) );
  AO22X1_RVT U95 ( .A1(n78), .A2(\mem[0][2] ), .A3(n77), .A4(\mem[1][2] ), .Y(
        n70) );
  NAND2X0_RVT U96 ( .A1(n46), .A2(addr[1]), .Y(n149) );
  AND2X1_RVT U97 ( .A1(addr[1]), .A2(n79), .Y(n80) );
  AO21X1_RVT U98 ( .A1(n78), .A2(\mem[2][2] ), .A3(n18), .Y(n79) );
  INVX0_RVT U99 ( .A(addr[1]), .Y(n152) );
  AO22X1_RVT U100 ( .A1(n139), .A2(\mem[1][5] ), .A3(n81), .A4(n22), .Y(n55)
         );
  NOR2X0_RVT U101 ( .A1(n147), .A2(n106), .Y(n97) );
  AND2X1_RVT U102 ( .A1(n62), .A2(n4), .Y(n83) );
  AO21X1_RVT U103 ( .A1(n62), .A2(n97), .A3(n85), .Y(n84) );
  NBUFFX2_RVT U104 ( .A(addr[1]), .Y(n86) );
  NOR2X4_RVT U105 ( .A1(n100), .A2(addr[1]), .Y(n101) );
  AO22X1_RVT U106 ( .A1(price[6]), .A2(n154), .A3(n3), .A4(n153), .Y(n44) );
  AO21X1_RVT U107 ( .A1(rst), .A2(n143), .A3(n144), .Y(n87) );
  INVX1_RVT U108 ( .A(n106), .Y(n89) );
  AO21X1_RVT U109 ( .A1(n143), .A2(n137), .A3(n138), .Y(n68) );
  AO22X1_RVT U110 ( .A1(stock[4]), .A2(n154), .A3(n153), .A4(n92), .Y(n34) );
  AO22X1_RVT U111 ( .A1(\mem[3][4] ), .A2(n133), .A3(n93), .A4(n130), .Y(n72)
         );
  NOR2X0_RVT U112 ( .A1(addr[1]), .A2(n94), .Y(n95) );
  OA22X1_RVT U113 ( .A1(n169), .A2(n46), .A3(n168), .A4(addr[0]), .Y(n94) );
  OR2X2_RVT U114 ( .A1(n136), .A2(n135), .Y(n143) );
  NOR2X0_RVT U115 ( .A1(n99), .A2(n14), .Y(n102) );
  INVX1_RVT U116 ( .A(n105), .Y(n98) );
  OA22X1_RVT U117 ( .A1(n159), .A2(n78), .A3(n165), .A4(addr[0]), .Y(n99) );
  OA22X1_RVT U118 ( .A1(n160), .A2(n78), .A3(n166), .A4(addr[0]), .Y(n100) );
  OA22X1_RVT U119 ( .A1(n158), .A2(n78), .A3(n164), .A4(addr[0]), .Y(n103) );
  AND3X1_RVT U120 ( .A1(n97), .A2(n104), .A3(n90), .Y(n122) );
  INVX0_RVT U121 ( .A(mem_write), .Y(n107) );
  OR2X2_RVT U122 ( .A1(addr[0]), .A2(n121), .Y(n109) );
  INVX1_RVT U123 ( .A(n109), .Y(n108) );
  INVX0_RVT U124 ( .A(n148), .Y(n114) );
  NOR2X0_RVT U125 ( .A1(mem_read), .A2(n135), .Y(n154) );
  INVX0_RVT U126 ( .A(mem_read), .Y(n116) );
  NOR2X0_RVT U127 ( .A1(n116), .A2(n135), .Y(n153) );
  AO21X1_RVT U128 ( .A1(price[2]), .A2(n154), .A3(n117), .Y(n40) );
  AO22X1_RVT U129 ( .A1(\mem[3][3] ), .A2(n133), .A3(n132), .A4(n128), .Y(n73)
         );
  INVX0_RVT U130 ( .A(n120), .Y(n119) );
  AOI21X1_RVT U131 ( .A1(n145), .A2(n146), .A3(n62), .Y(n123) );
  NAND2X0_RVT U132 ( .A1(n123), .A2(n4), .Y(n125) );
  NOR2X2_RVT U133 ( .A1(n23), .A2(rst), .Y(n139) );
  INVX0_RVT U134 ( .A(n123), .Y(n124) );
  AND2X1_RVT U135 ( .A1(n4), .A2(n124), .Y(n126) );
  AO22X1_RVT U136 ( .A1(\mem[1][1] ), .A2(n139), .A3(n25), .A4(n126), .Y(n59)
         );
  AO22X1_RVT U137 ( .A1(\mem[1][3] ), .A2(n139), .A3(n128), .A4(n25), .Y(n57)
         );
  AO22X1_RVT U138 ( .A1(\mem[1][4] ), .A2(n139), .A3(n130), .A4(n25), .Y(n56)
         );
  NOR2X0_RVT U139 ( .A1(n135), .A2(n145), .Y(n131) );
  AO22X1_RVT U140 ( .A1(\mem[3][0] ), .A2(n133), .A3(n132), .A4(n131), .Y(n76)
         );
  AND2X1_RVT U141 ( .A1(n134), .A2(\mem[2][0] ), .Y(n138) );
  INVX1_RVT U142 ( .A(n145), .Y(n136) );
  INVX1_RVT U143 ( .A(n139), .Y(n140) );
  AND2X1_RVT U144 ( .A1(n142), .A2(\mem[0][0] ), .Y(n144) );
  AO22X1_RVT U145 ( .A1(stock[0]), .A2(n154), .A3(n145), .A4(n153), .Y(n30) );
  AO22X1_RVT U146 ( .A1(stock[1]), .A2(n154), .A3(n146), .A4(n153), .Y(n31) );
  AO22X1_RVT U147 ( .A1(stock[2]), .A2(n154), .A3(n106), .A4(n153), .Y(n32) );
  AO22X1_RVT U148 ( .A1(stock[3]), .A2(n154), .A3(n147), .A4(n153), .Y(n33) );
  AO22X1_RVT U149 ( .A1(stock[5]), .A2(n154), .A3(n148), .A4(n153), .Y(n35) );
  AND2X1_RVT U150 ( .A1(n154), .A2(stock[6]), .Y(n36) );
  NAND2X0_RVT U151 ( .A1(n150), .A2(n149), .Y(n151) );
  AO22X1_RVT U152 ( .A1(n154), .A2(price[1]), .A3(n151), .A4(n153), .Y(n39) );
  AO22X1_RVT U153 ( .A1(n154), .A2(price[4]), .A3(n153), .A4(n152), .Y(n42) );
  AO22X1_RVT U154 ( .A1(addr[0]), .A2(n153), .A3(n154), .A4(price[5]), .Y(n43)
         );
  AO22X1_RVT U155 ( .A1(price[3]), .A2(n154), .A3(n153), .A4(n46), .Y(n41) );
  AO22X1_RVT U156 ( .A1(price[0]), .A2(n154), .A3(n153), .A4(n78), .Y(n38) );
endmodule


module comparator ( credit, price, stock, can_sell );
  input [7:0] credit;
  input [7:0] price;
  input [7:0] stock;
  output can_sell;
  wire   n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15, n16,
         n17, n18, n19;

  INVX0_RVT U2 ( .A(credit[0]), .Y(n1) );
  INVX0_RVT U3 ( .A(price[1]), .Y(n3) );
  NAND2X0_RVT U4 ( .A1(price[0]), .A2(n1), .Y(n2) );
  AO222X1_RVT U5 ( .A1(credit[1]), .A2(n3), .A3(credit[1]), .A4(n2), .A5(n3), 
        .A6(n2), .Y(n5) );
  INVX0_RVT U6 ( .A(price[2]), .Y(n4) );
  AO222X1_RVT U7 ( .A1(credit[2]), .A2(n5), .A3(credit[2]), .A4(n4), .A5(n5), 
        .A6(n4), .Y(n7) );
  INVX0_RVT U8 ( .A(price[3]), .Y(n6) );
  AO222X1_RVT U9 ( .A1(credit[3]), .A2(n7), .A3(credit[3]), .A4(n6), .A5(n7), 
        .A6(n6), .Y(n9) );
  INVX0_RVT U10 ( .A(price[4]), .Y(n8) );
  AO222X1_RVT U11 ( .A1(credit[4]), .A2(n9), .A3(credit[4]), .A4(n8), .A5(n9), 
        .A6(n8), .Y(n11) );
  INVX0_RVT U12 ( .A(price[5]), .Y(n10) );
  AO222X1_RVT U13 ( .A1(credit[5]), .A2(n11), .A3(credit[5]), .A4(n10), .A5(
        n11), .A6(n10), .Y(n13) );
  INVX0_RVT U14 ( .A(price[6]), .Y(n12) );
  AO222X1_RVT U15 ( .A1(credit[6]), .A2(n13), .A3(credit[6]), .A4(n12), .A5(
        n13), .A6(n12), .Y(n19) );
  INVX0_RVT U16 ( .A(stock[5]), .Y(n16) );
  INVX0_RVT U17 ( .A(stock[6]), .Y(n15) );
  INVX0_RVT U18 ( .A(stock[4]), .Y(n14) );
  NAND3X0_RVT U19 ( .A1(n16), .A2(n15), .A3(n14), .Y(n18) );
  OR4X1_RVT U20 ( .A1(stock[3]), .A2(stock[2]), .A3(stock[1]), .A4(stock[0]), 
        .Y(n17) );
  OA22X1_RVT U21 ( .A1(credit[7]), .A2(n19), .A3(n18), .A4(n17), .Y(can_sell)
         );
endmodule


module subtractor ( credit, price, change );
  input [7:0] credit;
  input [7:0] price;
  output [7:0] change;
  wire   \intadd_9/B[5] , \intadd_9/B[4] , \intadd_9/B[3] , \intadd_9/B[2] ,
         \intadd_9/B[1] , \intadd_9/B[0] , \intadd_9/CI , \intadd_9/SUM[5] ,
         \intadd_9/SUM[4] , \intadd_9/SUM[3] , \intadd_9/SUM[2] ,
         \intadd_9/SUM[1] , \intadd_9/SUM[0] , \intadd_9/n6 , \intadd_9/n5 ,
         \intadd_9/n4 , \intadd_9/n3 , \intadd_9/n2 , \intadd_9/n1 , n1;

  FADDX1_RVT \intadd_9/U7  ( .A(\intadd_9/B[0] ), .B(price[1]), .CI(
        \intadd_9/CI ), .CO(\intadd_9/n6 ), .S(\intadd_9/SUM[0] ) );
  FADDX1_RVT \intadd_9/U6  ( .A(\intadd_9/B[1] ), .B(price[2]), .CI(
        \intadd_9/n6 ), .CO(\intadd_9/n5 ), .S(\intadd_9/SUM[1] ) );
  FADDX1_RVT \intadd_9/U5  ( .A(\intadd_9/B[2] ), .B(price[3]), .CI(
        \intadd_9/n5 ), .CO(\intadd_9/n4 ), .S(\intadd_9/SUM[2] ) );
  FADDX1_RVT \intadd_9/U4  ( .A(\intadd_9/B[3] ), .B(price[4]), .CI(
        \intadd_9/n4 ), .CO(\intadd_9/n3 ), .S(\intadd_9/SUM[3] ) );
  FADDX1_RVT \intadd_9/U3  ( .A(\intadd_9/B[4] ), .B(price[5]), .CI(
        \intadd_9/n3 ), .CO(\intadd_9/n2 ), .S(\intadd_9/SUM[4] ) );
  FADDX1_RVT \intadd_9/U2  ( .A(\intadd_9/B[5] ), .B(price[6]), .CI(
        \intadd_9/n2 ), .CO(\intadd_9/n1 ), .S(\intadd_9/SUM[5] ) );
  INVX0_RVT U1 ( .A(credit[4]), .Y(\intadd_9/B[3] ) );
  INVX0_RVT U2 ( .A(credit[1]), .Y(\intadd_9/B[0] ) );
  INVX0_RVT U3 ( .A(credit[5]), .Y(\intadd_9/B[4] ) );
  INVX0_RVT U4 ( .A(credit[2]), .Y(\intadd_9/B[1] ) );
  INVX0_RVT U5 ( .A(credit[6]), .Y(\intadd_9/B[5] ) );
  INVX0_RVT U6 ( .A(\intadd_9/SUM[0] ), .Y(change[1]) );
  INVX0_RVT U7 ( .A(\intadd_9/SUM[1] ), .Y(change[2]) );
  INVX0_RVT U8 ( .A(\intadd_9/SUM[2] ), .Y(change[3]) );
  INVX0_RVT U9 ( .A(\intadd_9/SUM[3] ), .Y(change[4]) );
  INVX0_RVT U10 ( .A(\intadd_9/SUM[4] ), .Y(change[5]) );
  INVX0_RVT U11 ( .A(\intadd_9/SUM[5] ), .Y(change[6]) );
  XOR2X1_RVT U12 ( .A1(\intadd_9/n1 ), .A2(credit[7]), .Y(change[7]) );
  INVX0_RVT U13 ( .A(price[0]), .Y(n1) );
  NOR2X0_RVT U14 ( .A1(n1), .A2(credit[0]), .Y(\intadd_9/CI ) );
  INVX0_RVT U15 ( .A(credit[3]), .Y(\intadd_9/B[2] ) );
  AO21X1_RVT U16 ( .A1(credit[0]), .A2(n1), .A3(\intadd_9/CI ), .Y(change[0])
         );
endmodule


module control_unit ( clk, rst, cancel, coin_in, confirm, can_sell, state, 
        credit_load, credit_clear, mem_read, mem_write, dispense, error, 
        change_load );
  input [1:0] coin_in;
  output [2:0] state;
  input clk, rst, cancel, confirm, can_sell;
  output credit_load, credit_clear, mem_read, mem_write, dispense, error,
         change_load;
  wire   dispense, check_wait, N20, N21, N22, n16, n1, n2, n3, n4, n5, n6, n7,
         n8, n9, n10, n11, n12, n13, n14, n15, n17, n18, n19, n20, n21, n22,
         n23, n24, n25, n26, n27;
  assign mem_write = dispense;

  DFFX1_RVT \current_state_reg[0]  ( .D(N20), .CLK(clk), .Q(state[0]), .QN(n25) );
  DFFX1_RVT check_wait_reg ( .D(n16), .CLK(clk), .Q(check_wait), .QN(n27) );
  DFFX1_RVT \current_state_reg[1]  ( .D(N21), .CLK(clk), .Q(state[1]), .QN(n26) );
  DFFX1_RVT \current_state_reg[2]  ( .D(N22), .CLK(clk), .Q(state[2]) );
  INVX0_RVT U3 ( .A(change_load), .Y(n23) );
  OR2X1_RVT U4 ( .A1(n26), .A2(state[2]), .Y(n19) );
  NOR3X0_RVT U5 ( .A1(state[0]), .A2(check_wait), .A3(n19), .Y(mem_read) );
  AND2X1_RVT U6 ( .A1(state[2]), .A2(n26), .Y(change_load) );
  NOR2X0_RVT U7 ( .A1(n23), .A2(n25), .Y(error) );
  NOR2X0_RVT U8 ( .A1(n19), .A2(n25), .Y(dispense) );
  INVX0_RVT U9 ( .A(mem_read), .Y(n3) );
  OR2X1_RVT U10 ( .A1(dispense), .A2(change_load), .Y(n1) );
  NAND2X0_RVT U11 ( .A1(check_wait), .A2(n1), .Y(n2) );
  OR2X1_RVT U12 ( .A1(cancel), .A2(rst), .Y(n20) );
  AOI21X1_RVT U13 ( .A1(n3), .A2(n2), .A3(n20), .Y(n16) );
  NAND2X0_RVT U14 ( .A1(confirm), .A2(state[0]), .Y(n11) );
  NAND2X0_RVT U15 ( .A1(can_sell), .A2(n25), .Y(n4) );
  MUX21X1_RVT U16 ( .A1(n11), .A2(n4), .S0(state[1]), .Y(n5) );
  NOR2X0_RVT U17 ( .A1(state[2]), .A2(n5), .Y(n6) );
  NOR2X0_RVT U18 ( .A1(n6), .A2(mem_read), .Y(n7) );
  NOR2X0_RVT U19 ( .A1(n20), .A2(n7), .Y(N21) );
  INVX0_RVT U20 ( .A(coin_in[1]), .Y(n9) );
  INVX0_RVT U21 ( .A(coin_in[0]), .Y(n8) );
  AO21X1_RVT U22 ( .A1(n9), .A2(n8), .A3(state[2]), .Y(n24) );
  OR2X1_RVT U23 ( .A1(n27), .A2(state[0]), .Y(n10) );
  AO22X1_RVT U24 ( .A1(n24), .A2(n19), .A3(state[1]), .A4(n10), .Y(n15) );
  OR2X1_RVT U25 ( .A1(n25), .A2(state[1]), .Y(n14) );
  NOR2X0_RVT U26 ( .A1(state[2]), .A2(n11), .Y(n12) );
  OR2X1_RVT U27 ( .A1(n12), .A2(n20), .Y(n13) );
  AOI21X1_RVT U28 ( .A1(n15), .A2(n14), .A3(n13), .Y(N20) );
  INVX0_RVT U29 ( .A(dispense), .Y(n18) );
  INVX0_RVT U30 ( .A(error), .Y(n17) );
  AND2X1_RVT U31 ( .A1(n18), .A2(n17), .Y(n22) );
  OR3X1_RVT U32 ( .A1(n19), .A2(n27), .A3(can_sell), .Y(n21) );
  AOI21X1_RVT U33 ( .A1(n22), .A2(n21), .A3(n20), .Y(N22) );
  NOR2X0_RVT U34 ( .A1(state[0]), .A2(n23), .Y(credit_clear) );
  NOR2X0_RVT U35 ( .A1(state[1]), .A2(n24), .Y(credit_load) );
endmodule


module vending_top ( clk, rst, coin_in, sel_item, confirm, cancel, dispense, 
        change_out, error, display, state_out );
  input [1:0] coin_in;
  input [1:0] sel_item;
  output [7:0] change_out;
  output [7:0] display;
  output [2:0] state_out;
  input clk, rst, confirm, cancel;
  output dispense, error;
  wire   credit_clear, credit_load, mem_read, mem_write, can_sell, change_load,
         n10, n11, n12, n13, n14, n15, n16, n17, n18, n19, n20, n21, n22, n23,
         n24, n25, n26, n27, n28, n29, net24397, net24398, net24399, net24400;
  wire   [6:0] coin_value;
  wire   [7:0] price;
  wire   [7:0] stock;
  wire   [7:0] change;
  wire   SYNOPSYS_UNCONNECTED__0, SYNOPSYS_UNCONNECTED__1;

  credit_reg u_credit_reg ( .clk(clk), .rst(rst), .cancel(cancel), .clear(
        credit_clear), .load(credit_load), .coin_value({net24400, 
        coin_value[6], coin_in[1], n18, coin_value[3], coin_value[6], 
        coin_value[1], coin_value[3]}), .credit(display) );
  memory u_memory ( .clk(clk), .rst(rst), .mem_read(mem_read), .mem_write(
        mem_write), .addr(sel_item), .price({SYNOPSYS_UNCONNECTED__0, 
        price[6:0]}), .stock({SYNOPSYS_UNCONNECTED__1, stock[6:0]}) );
  comparator u_comparator ( .credit(display), .price({net24398, price[6:0]}), 
        .stock({net24399, stock[6:0]}), .can_sell(can_sell) );
  subtractor u_subtractor ( .credit(display), .price({net24397, price[6:0]}), 
        .change(change) );
  control_unit u_control_unit ( .clk(clk), .rst(rst), .cancel(cancel), 
        .coin_in(coin_in), .confirm(confirm), .can_sell(can_sell), .state(
        state_out), .credit_load(credit_load), .credit_clear(credit_clear), 
        .mem_read(mem_read), .mem_write(mem_write), .dispense(dispense), 
        .error(error), .change_load(change_load) );
  DFFX1_RVT \change_out_reg[7]  ( .D(n17), .CLK(clk), .Q(change_out[7]) );
  DFFX1_RVT \change_out_reg[6]  ( .D(n16), .CLK(clk), .Q(change_out[6]) );
  DFFX1_RVT \change_out_reg[5]  ( .D(n15), .CLK(clk), .Q(change_out[5]) );
  DFFX1_RVT \change_out_reg[4]  ( .D(n14), .CLK(clk), .Q(change_out[4]) );
  DFFX1_RVT \change_out_reg[3]  ( .D(n13), .CLK(clk), .Q(change_out[3]) );
  DFFX1_RVT \change_out_reg[2]  ( .D(n12), .CLK(clk), .Q(change_out[2]) );
  DFFX1_RVT \change_out_reg[1]  ( .D(n11), .CLK(clk), .Q(change_out[1]) );
  DFFX1_RVT \change_out_reg[0]  ( .D(n10), .CLK(clk), .Q(change_out[0]) );
  INVX0_RVT U25 ( .A(coin_in[1]), .Y(n19) );
  NOR2X0_RVT U26 ( .A1(n19), .A2(coin_in[0]), .Y(coin_value[1]) );
  AND2X1_RVT U27 ( .A1(coin_in[0]), .A2(n19), .Y(coin_value[3]) );
  OR2X1_RVT U28 ( .A1(coin_value[1]), .A2(coin_value[3]), .Y(n18) );
  AND2X1_RVT U29 ( .A1(coin_in[0]), .A2(coin_in[1]), .Y(coin_value[6]) );
  INVX0_RVT U30 ( .A(change_load), .Y(n22) );
  INVX0_RVT U31 ( .A(state_out[1]), .Y(n20) );
  NAND3X0_RVT U32 ( .A1(state_out[0]), .A2(state_out[2]), .A3(n20), .Y(n24) );
  INVX0_RVT U33 ( .A(cancel), .Y(n21) );
  OA21X1_RVT U34 ( .A1(n22), .A2(n24), .A3(n21), .Y(n23) );
  NOR2X0_RVT U35 ( .A1(n23), .A2(rst), .Y(n29) );
  OR2X1_RVT U36 ( .A1(cancel), .A2(rst), .Y(n25) );
  NOR2X0_RVT U37 ( .A1(n25), .A2(change_load), .Y(n27) );
  NAND2X0_RVT U38 ( .A1(n24), .A2(change_load), .Y(n26) );
  NOR2X0_RVT U39 ( .A1(n26), .A2(n25), .Y(n28) );
  AO222X1_RVT U40 ( .A1(n29), .A2(display[0]), .A3(n27), .A4(change_out[0]), 
        .A5(n28), .A6(change[0]), .Y(n10) );
  AO222X1_RVT U41 ( .A1(n29), .A2(display[1]), .A3(n28), .A4(change[1]), .A5(
        change_out[1]), .A6(n27), .Y(n11) );
  AO222X1_RVT U42 ( .A1(n29), .A2(display[2]), .A3(n28), .A4(change[2]), .A5(
        change_out[2]), .A6(n27), .Y(n12) );
  AO222X1_RVT U43 ( .A1(n29), .A2(display[3]), .A3(n28), .A4(change[3]), .A5(
        change_out[3]), .A6(n27), .Y(n13) );
  AO222X1_RVT U44 ( .A1(n29), .A2(display[4]), .A3(n28), .A4(change[4]), .A5(
        change_out[4]), .A6(n27), .Y(n14) );
  AO222X1_RVT U45 ( .A1(n29), .A2(display[5]), .A3(n28), .A4(change[5]), .A5(
        change_out[5]), .A6(n27), .Y(n15) );
  AO222X1_RVT U46 ( .A1(n29), .A2(display[6]), .A3(n28), .A4(change[6]), .A5(
        change_out[6]), .A6(n27), .Y(n16) );
  AO222X1_RVT U47 ( .A1(n29), .A2(display[7]), .A3(n28), .A4(change[7]), .A5(
        change_out[7]), .A6(n27), .Y(n17) );
endmodule

