/////////////////////////////////////////////////////////////
// Created by: Synopsys DC Ultra(TM) in wire load mode
// Version   : X-2025.06-SP2
// Date      : Thu Jul  9 13:24:28 2026
/////////////////////////////////////////////////////////////


module credit_reg ( clk, rst, cancel, clear, load, coin_value, credit );
  input [7:0] coin_value;
  output [7:0] credit;
  input clk, rst, cancel, clear, load;
  wire   n4, n5, n6, n7, n8, n9, n10, n2, n3, n11, n12, n13, n14, n15, n16,
         n17, n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28, n29, n30,
         n31, n32, n33, n34, n35, n36, n37, n38, n39, n40, n41, n42, n43, n44,
         n45, n46, n47, n48, n49, n50, n51, n52, n53, n54, n55, n56, n57, n58,
         n59, n60, n61, n62, n63, n64, n65, n66, n67, n68, n69, n70, n71, n72,
         n73, n74, n75, n76, n77, n78, n79, n83, n84, n85, n86, n87, n88, n89,
         n90, n91;

  DFFX1_RVT \credit_reg[6]  ( .D(n5), .CLK(clk), .Q(credit[6]), .QN(n85) );
  DFFX1_RVT \credit_reg[5]  ( .D(n6), .CLK(clk), .Q(credit[5]), .QN(n86) );
  DFFX1_RVT \credit_reg[3]  ( .D(n8), .CLK(clk), .Q(credit[3]), .QN(n88) );
  DFFARX1_RVT \credit_reg[2]  ( .D(n9), .CLK(clk), .RSTB(1'b1), .Q(credit[2]), 
        .QN(n89) );
  DFFARX1_RVT \credit_reg[1]  ( .D(n10), .CLK(clk), .RSTB(1'b1), .Q(credit[1]), 
        .QN(n90) );
  DFFARX1_RVT \credit_reg[0]  ( .D(n83), .CLK(clk), .RSTB(1'b1), .Q(credit[0]), 
        .QN(n84) );
  DFFX1_RVT \credit_reg[7]  ( .D(n4), .CLK(clk), .Q(credit[7]), .QN(n91) );
  DFFX1_RVT \credit_reg[4]  ( .D(n7), .CLK(clk), .Q(credit[4]), .QN(n87) );
  OR2X1_RVT U3 ( .A1(credit[5]), .A2(coin_value[5]), .Y(n36) );
  XOR2X1_RVT U4 ( .A1(n49), .A2(n39), .Y(n38) );
  AO21X1_RVT U5 ( .A1(n23), .A2(n2), .A3(n24), .Y(n59) );
  INVX0_RVT U6 ( .A(n75), .Y(n2) );
  NAND2X0_RVT U7 ( .A1(coin_value[0]), .A2(credit[0]), .Y(n75) );
  INVX0_RVT U8 ( .A(n57), .Y(n16) );
  AO22X1_RVT U9 ( .A1(n21), .A2(n22), .A3(n13), .A4(n3), .Y(n5) );
  OA21X1_RVT U10 ( .A1(n12), .A2(n34), .A3(n11), .Y(n3) );
  INVX0_RVT U11 ( .A(n18), .Y(n12) );
  AND2X1_RVT U12 ( .A1(n15), .A2(n14), .Y(n13) );
  INVX0_RVT U13 ( .A(n19), .Y(n14) );
  OR2X1_RVT U14 ( .A1(n17), .A2(n16), .Y(n11) );
  NAND2X0_RVT U15 ( .A1(n31), .A2(n29), .Y(n17) );
  NOR2X0_RVT U16 ( .A1(n31), .A2(n29), .Y(n18) );
  AO21X1_RVT U17 ( .A1(n34), .A2(n29), .A3(n78), .Y(n19) );
  OR2X1_RVT U18 ( .A1(n57), .A2(n20), .Y(n15) );
  OR2X1_RVT U19 ( .A1(n29), .A2(n34), .Y(n20) );
  INVX0_RVT U20 ( .A(n85), .Y(n21) );
  INVX0_RVT U21 ( .A(n79), .Y(n22) );
  OR2X1_RVT U22 ( .A1(credit[1]), .A2(coin_value[1]), .Y(n23) );
  AND2X1_RVT U23 ( .A1(credit[1]), .A2(coin_value[1]), .Y(n24) );
  INVX0_RVT U24 ( .A(n24), .Y(n74) );
  OR2X1_RVT U25 ( .A1(n27), .A2(n26), .Y(n49) );
  AO22X1_RVT U26 ( .A1(coin_value[6]), .A2(credit[6]), .A3(n34), .A4(n28), .Y(
        n26) );
  AND2X1_RVT U27 ( .A1(n25), .A2(n57), .Y(n27) );
  AND2X1_RVT U28 ( .A1(n31), .A2(n28), .Y(n25) );
  INVX0_RVT U29 ( .A(n30), .Y(n28) );
  XNOR2X1_RVT U30 ( .A1(coin_value[6]), .A2(n85), .Y(n29) );
  NOR2X0_RVT U31 ( .A1(credit[6]), .A2(coin_value[6]), .Y(n30) );
  INVX0_RVT U32 ( .A(n91), .Y(n39) );
  NOR2X0_RVT U33 ( .A1(n45), .A2(n32), .Y(n31) );
  INVX1_RVT U34 ( .A(n36), .Y(n32) );
  AO21X1_RVT U35 ( .A1(n47), .A2(n59), .A3(n46), .Y(n33) );
  NOR2X0_RVT U36 ( .A1(credit[0]), .A2(coin_value[0]), .Y(n40) );
  NOR2X0_RVT U37 ( .A1(credit[3]), .A2(coin_value[3]), .Y(n60) );
  OR3X1_RVT U38 ( .A1(clear), .A2(rst), .A3(cancel), .Y(n43) );
  INVX1_RVT U39 ( .A(n59), .Y(n71) );
  NOR2X0_RVT U40 ( .A1(n60), .A2(n67), .Y(n47) );
  INVX0_RVT U41 ( .A(load), .Y(n42) );
  AO21X1_RVT U42 ( .A1(n50), .A2(n36), .A3(n48), .Y(n34) );
  XNOR2X2_RVT U43 ( .A1(n53), .A2(n52), .Y(n35) );
  NOR2X0_RVT U44 ( .A1(credit[4]), .A2(coin_value[4]), .Y(n45) );
  AO22X1_RVT U45 ( .A1(n22), .A2(n39), .A3(n38), .A4(n37), .Y(n4) );
  INVX0_RVT U46 ( .A(n78), .Y(n37) );
  AO21X1_RVT U47 ( .A1(n47), .A2(n59), .A3(n46), .Y(n57) );
  OAI22X1_RVT U48 ( .A1(n79), .A2(n89), .A3(n78), .A4(n73), .Y(n9) );
  INVX0_RVT U52 ( .A(n40), .Y(n41) );
  NAND2X0_RVT U53 ( .A1(n41), .A2(n75), .Y(n44) );
  OR2X1_RVT U54 ( .A1(n42), .A2(n43), .Y(n78) );
  OR2X1_RVT U55 ( .A1(load), .A2(n43), .Y(n79) );
  OAI22X1_RVT U56 ( .A1(n44), .A2(n78), .A3(n84), .A4(n79), .Y(n83) );
  INVX0_RVT U57 ( .A(n45), .Y(n55) );
  NOR2X0_RVT U58 ( .A1(credit[2]), .A2(coin_value[2]), .Y(n67) );
  NAND2X0_RVT U59 ( .A1(coin_value[2]), .A2(credit[2]), .Y(n68) );
  NAND2X0_RVT U60 ( .A1(coin_value[3]), .A2(credit[3]), .Y(n61) );
  OAI21X1_RVT U61 ( .A1(n68), .A2(n60), .A3(n61), .Y(n46) );
  NAND2X0_RVT U62 ( .A1(coin_value[4]), .A2(credit[4]), .Y(n54) );
  INVX0_RVT U63 ( .A(n54), .Y(n50) );
  NAND2X0_RVT U64 ( .A1(coin_value[5]), .A2(credit[5]), .Y(n51) );
  INVX0_RVT U65 ( .A(n51), .Y(n48) );
  AOI21X1_RVT U66 ( .A1(n33), .A2(n55), .A3(n50), .Y(n53) );
  NAND2X0_RVT U67 ( .A1(n36), .A2(n51), .Y(n52) );
  OAI22X1_RVT U68 ( .A1(n79), .A2(n86), .A3(n78), .A4(n35), .Y(n6) );
  NAND2X0_RVT U69 ( .A1(n55), .A2(n54), .Y(n56) );
  XOR2X1_RVT U70 ( .A1(n33), .A2(n56), .Y(n58) );
  OAI22X1_RVT U71 ( .A1(n79), .A2(n87), .A3(n78), .A4(n58), .Y(n7) );
  OAI21X2_RVT U72 ( .A1(n67), .A2(n71), .A3(n68), .Y(n64) );
  INVX0_RVT U73 ( .A(n60), .Y(n62) );
  NAND2X0_RVT U74 ( .A1(n62), .A2(n61), .Y(n63) );
  XNOR2X1_RVT U75 ( .A1(n64), .A2(n63), .Y(n65) );
  INVX0_RVT U76 ( .A(n65), .Y(n66) );
  OAI22X1_RVT U77 ( .A1(n79), .A2(n88), .A3(n78), .A4(n66), .Y(n8) );
  INVX0_RVT U78 ( .A(n67), .Y(n69) );
  NAND2X0_RVT U79 ( .A1(n69), .A2(n68), .Y(n70) );
  XOR2X1_RVT U80 ( .A1(n71), .A2(n70), .Y(n72) );
  INVX0_RVT U81 ( .A(n72), .Y(n73) );
  NAND2X0_RVT U82 ( .A1(n23), .A2(n74), .Y(n76) );
  XNOR2X1_RVT U83 ( .A1(n76), .A2(n75), .Y(n77) );
  OAI22X1_RVT U84 ( .A1(n79), .A2(n90), .A3(n78), .A4(n77), .Y(n10) );
endmodule


module memory ( clk, rst, mem_read, mem_write, addr, price, stock );
  input [1:0] addr;
  output [7:0] price;
  output [7:0] stock;
  input clk, rst, mem_read, mem_write;
  wire   \mem[0][2] , \mem[0][1] , \mem[0][0] , \mem[1][4] , \mem[1][2] ,
         \mem[1][0] , \mem[2][4] , \mem[2][3] , \mem[2][2] , \mem[2][1] ,
         \mem[2][0] , \mem[3][4] , \mem[3][1] , \mem[3][0] , n30, n31, n32,
         n33, n34, n38, n39, n40, n41, n42, n43, n44, n48, n49, n50, n51, n52,
         n56, n57, n58, n59, n60, n64, n65, n66, n67, n68, n72, n73, n74, n75,
         n76, n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n14, n15, n16,
         n17, n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28, n29, n35,
         n36, n37, n45, n46, n47, n53, n54, n55, n61, n62, n63, n69, n70, n71,
         n77, n78, n79, n80, n81, n82, n83, n84, n85, n86, n87, n88, n89, n90,
         n91, n92, n93, n94, n95, n96, n97, n98, n99, n100, n101, n102, n103,
         n104, n105, n106, n107, n108, n109, n110, n111, n112, n113, n114,
         n115, n116, n117, n118, n119, n120, n121, n122, n123, n124, n125,
         n126, n127, n128, n129, n130, n131, n132, n133, n134, n135, n136,
         n137, n138, n140, n141, n142, n143, n144, n145, n146, n147, n148,
         n149, n150, n151, n152, n153, n154, n155, n156, n157, n158, n159,
         n160, n161, n162, n163, n164, n165, n168, n169, n170, n171, n172,
         n173, n174, n175, n176, n177, n178, n179, n180, n181, n182, n183,
         n184, n187;
  assign stock[5] = 1'b0;

  DFFX1_RVT \mem_reg[3][0]  ( .D(n76), .CLK(clk), .Q(\mem[3][0] ), .QN(n178)
         );
  DFFX1_RVT \mem_reg[3][1]  ( .D(n75), .CLK(clk), .Q(\mem[3][1] ), .QN(n177)
         );
  DFFX1_RVT \mem_reg[1][3]  ( .D(n57), .CLK(clk), .QN(n175) );
  DFFX1_RVT \price_reg[6]  ( .D(n44), .CLK(clk), .Q(price[6]) );
  DFFX1_RVT \price_reg[5]  ( .D(n43), .CLK(clk), .Q(price[5]) );
  DFFX1_RVT \price_reg[3]  ( .D(n41), .CLK(clk), .Q(price[3]) );
  DFFX1_RVT \price_reg[2]  ( .D(n40), .CLK(clk), .Q(price[2]) );
  DFFX1_RVT \price_reg[1]  ( .D(n39), .CLK(clk), .Q(price[1]) );
  DFFX1_RVT \price_reg[0]  ( .D(n38), .CLK(clk), .Q(price[0]) );
  DFFX1_RVT \stock_reg[4]  ( .D(n34), .CLK(clk), .Q(stock[4]) );
  DFFX1_RVT \stock_reg[3]  ( .D(n33), .CLK(clk), .Q(stock[3]) );
  DFFX1_RVT \stock_reg[2]  ( .D(n32), .CLK(clk), .Q(stock[2]) );
  DFFX1_RVT \stock_reg[1]  ( .D(n31), .CLK(clk), .Q(stock[1]) );
  DFFX1_RVT \stock_reg[0]  ( .D(n30), .CLK(clk), .Q(stock[0]) );
  DFFX2_RVT \mem_reg[0][3]  ( .D(n49), .CLK(clk), .Q(n170), .QN(n181) );
  DFFSSRX1_RVT \price_reg[4]  ( .D(1'b0), .SETB(n42), .RSTB(1'b1), .CLK(clk), 
        .QN(price[4]) );
  DFFX1_RVT \mem_reg[2][2]  ( .D(n66), .CLK(clk), .Q(\mem[2][2] ), .QN(n46) );
  DFFX1_RVT \mem_reg[1][0]  ( .D(n60), .CLK(clk), .Q(\mem[1][0] ), .QN(n173)
         );
  DFFX1_RVT \mem_reg[2][3]  ( .D(n65), .CLK(clk), .Q(\mem[2][3] ), .QN(n187)
         );
  DFFX1_RVT \mem_reg[3][3]  ( .D(n73), .CLK(clk), .QN(n183) );
  DFFX2_RVT \mem_reg[1][1]  ( .D(n59), .CLK(clk), .QN(n172) );
  DFFX2_RVT \mem_reg[3][2]  ( .D(n74), .CLK(clk), .QN(n180) );
  DFFX1_RVT \mem_reg[1][2]  ( .D(n58), .CLK(clk), .Q(\mem[1][2] ), .QN(n174)
         );
  DFFX1_RVT \mem_reg[3][4]  ( .D(n72), .CLK(clk), .Q(\mem[3][4] ), .QN(n184)
         );
  DFFX1_RVT \mem_reg[2][4]  ( .D(n64), .CLK(clk), .Q(\mem[2][4] ), .QN(n47) );
  DFFX2_RVT \mem_reg[2][1]  ( .D(n67), .CLK(clk), .Q(\mem[2][1] ), .QN(n171)
         );
  DFFX2_RVT \mem_reg[0][1]  ( .D(n51), .CLK(clk), .Q(\mem[0][1] ) );
  DFFX2_RVT \mem_reg[0][0]  ( .D(n52), .CLK(clk), .Q(\mem[0][0] ) );
  DFFX2_RVT \mem_reg[2][0]  ( .D(n68), .CLK(clk), .Q(\mem[2][0] ), .QN(n168)
         );
  DFFX1_RVT \mem_reg[0][4]  ( .D(n48), .CLK(clk), .Q(n169), .QN(n182) );
  DFFX1_RVT \mem_reg[0][2]  ( .D(n50), .CLK(clk), .Q(\mem[0][2] ), .QN(n179)
         );
  DFFX1_RVT \mem_reg[1][4]  ( .D(n56), .CLK(clk), .Q(\mem[1][4] ), .QN(n176)
         );
  NOR2X0_RVT U3 ( .A1(rst), .A2(mem_read), .Y(n165) );
  INVX0_RVT U4 ( .A(n149), .Y(n1) );
  INVX0_RVT U5 ( .A(n163), .Y(n6) );
  OR3X1_RVT U6 ( .A1(n162), .A2(n63), .A3(n61), .Y(n128) );
  NAND2X1_RVT U7 ( .A1(n16), .A2(n35), .Y(n143) );
  AO21X1_RVT U8 ( .A1(n2), .A2(n1), .A3(n138), .Y(n74) );
  INVX1_RVT U9 ( .A(n141), .Y(n2) );
  OR3X1_RVT U10 ( .A1(n109), .A2(n110), .A3(n111), .Y(n61) );
  OR3X1_RVT U11 ( .A1(n5), .A2(n4), .A3(n3), .Y(n145) );
  AND2X1_RVT U12 ( .A1(n6), .A2(n63), .Y(n3) );
  AO21X1_RVT U13 ( .A1(n29), .A2(n6), .A3(rst), .Y(n4) );
  NOR2X0_RVT U14 ( .A1(n134), .A2(n6), .Y(n5) );
  OR2X1_RVT U15 ( .A1(n63), .A2(n29), .Y(n134) );
  NBUFFX2_RVT U16 ( .A(n106), .Y(n7) );
  OR2X2_RVT U22 ( .A1(n63), .A2(n61), .Y(n26) );
  AO21X1_RVT U23 ( .A1(n16), .A2(n11), .A3(n8), .Y(n149) );
  NOR3X0_RVT U24 ( .A1(n63), .A2(n61), .A3(n9), .Y(n8) );
  OR2X1_RVT U25 ( .A1(n10), .A2(n162), .Y(n9) );
  INVX0_RVT U26 ( .A(n16), .Y(n10) );
  INVX0_RVT U27 ( .A(n123), .Y(n11) );
  NOR2X0_RVT U28 ( .A1(n173), .A2(n28), .Y(n84) );
  NOR2X0_RVT U29 ( .A1(n172), .A2(n28), .Y(n81) );
  NOR2X0_RVT U30 ( .A1(n12), .A2(n105), .Y(n79) );
  AND2X1_RVT U31 ( .A1(n173), .A2(n172), .Y(n12) );
  AO22X1_RVT U32 ( .A1(n150), .A2(\mem[2][3] ), .A3(n146), .A4(n18), .Y(n65)
         );
  AO22X1_RVT U33 ( .A1(n150), .A2(\mem[2][2] ), .A3(n146), .A4(n144), .Y(n66)
         );
  OR3X2_RVT U34 ( .A1(n80), .A2(n79), .A3(n78), .Y(n63) );
  INVX0_RVT U35 ( .A(n114), .Y(n24) );
  OR3X1_RVT U36 ( .A1(n63), .A2(n163), .A3(n29), .Y(n114) );
  INVX1_RVT U37 ( .A(n69), .Y(n14) );
  INVX0_RVT U38 ( .A(n145), .Y(n15) );
  MUX21X1_RVT U39 ( .A1(n170), .A2(n15), .S0(n14), .Y(n49) );
  INVX0_RVT U40 ( .A(rst), .Y(n16) );
  OR2X1_RVT U41 ( .A1(n62), .A2(n135), .Y(n17) );
  NAND2X0_RVT U42 ( .A1(n17), .A2(n16), .Y(n141) );
  OR2X1_RVT U43 ( .A1(n10), .A2(n17), .Y(n140) );
  OR2X1_RVT U44 ( .A1(n145), .A2(n27), .Y(n122) );
  INVX0_RVT U45 ( .A(n145), .Y(n18) );
  AO21X1_RVT U46 ( .A1(n16), .A2(n19), .A3(n20), .Y(n25) );
  INVX0_RVT U47 ( .A(n26), .Y(n19) );
  AND2X1_RVT U48 ( .A1(n21), .A2(n114), .Y(n20) );
  AND2X1_RVT U49 ( .A1(n112), .A2(n16), .Y(n21) );
  AO21X1_RVT U50 ( .A1(n26), .A2(n24), .A3(n22), .Y(n86) );
  AO21X1_RVT U51 ( .A1(n23), .A2(n26), .A3(rst), .Y(n22) );
  INVX1_RVT U52 ( .A(n112), .Y(n23) );
  MUX21X1_RVT U53 ( .A1(\mem[1][4] ), .A2(n25), .S0(n121), .Y(n56) );
  AOI21X2_RVT U54 ( .A1(n45), .A2(n128), .A3(n10), .Y(n27) );
  NOR2X4_RVT U55 ( .A1(n7), .A2(1'b1), .Y(n93) );
  AO21X1_RVT U56 ( .A1(n83), .A2(\mem[0][1] ), .A3(n81), .Y(n77) );
  NOR2X0_RVT U57 ( .A1(n127), .A2(n46), .Y(n97) );
  NOR2X0_RVT U58 ( .A1(n127), .A2(n47), .Y(n94) );
  INVX0_RVT U59 ( .A(n115), .Y(n28) );
  OR3X1_RVT U60 ( .A1(n98), .A2(n99), .A3(n97), .Y(n29) );
  NBUFFX2_RVT U61 ( .A(n127), .Y(n35) );
  NAND2X0_RVT U62 ( .A1(n143), .A2(n142), .Y(n150) );
  NOR2X0_RVT U63 ( .A1(n168), .A2(n35), .Y(n85) );
  NOR2X0_RVT U64 ( .A1(n171), .A2(n35), .Y(n82) );
  NOR2X0_RVT U65 ( .A1(n178), .A2(n106), .Y(n104) );
  NOR2X0_RVT U66 ( .A1(n183), .A2(n106), .Y(n102) );
  NOR2X0_RVT U67 ( .A1(n184), .A2(n106), .Y(n95) );
  INVX1_RVT U68 ( .A(n105), .Y(n115) );
  INVX0_RVT U69 ( .A(mem_write), .Y(n55) );
  INVX0_RVT U70 ( .A(n164), .Y(n154) );
  INVX1_RVT U71 ( .A(n108), .Y(n83) );
  NOR2X0_RVT U72 ( .A1(n180), .A2(n106), .Y(n99) );
  INVX1_RVT U73 ( .A(n63), .Y(n118) );
  OR3X1_RVT U74 ( .A1(n93), .A2(n92), .A3(n91), .Y(n162) );
  INVX0_RVT U75 ( .A(n7), .Y(n159) );
  INVX0_RVT U76 ( .A(n157), .Y(n161) );
  INVX1_RVT U77 ( .A(n117), .Y(n151) );
  OR2X1_RVT U78 ( .A1(n145), .A2(n149), .Y(n125) );
  INVX0_RVT U79 ( .A(n116), .Y(n153) );
  NOR2X0_RVT U80 ( .A1(n55), .A2(n108), .Y(n36) );
  NOR2X0_RVT U81 ( .A1(\mem[0][1] ), .A2(\mem[0][0] ), .Y(n37) );
  AND2X1_RVT U82 ( .A1(mem_write), .A2(n115), .Y(n45) );
  NAND2X0_RVT U83 ( .A1(n128), .A2(n123), .Y(n53) );
  AOI21X2_RVT U84 ( .A1(n128), .A2(n36), .A3(rst), .Y(n69) );
  NAND2X4_RVT U85 ( .A1(addr[0]), .A2(addr[1]), .Y(n106) );
  OR3X1_RVT U86 ( .A1(n102), .A2(n101), .A3(n103), .Y(n109) );
  NOR2X0_RVT U87 ( .A1(n54), .A2(n127), .Y(n80) );
  AND2X1_RVT U88 ( .A1(n171), .A2(n168), .Y(n54) );
  OR2X2_RVT U89 ( .A1(addr[0]), .A2(addr[1]), .Y(n108) );
  NOR2X0_RVT U90 ( .A1(n149), .A2(n86), .Y(n147) );
  OAI22X1_RVT U91 ( .A1(n176), .A2(n105), .A3(n182), .A4(n108), .Y(n96) );
  NOR2X0_RVT U92 ( .A1(n127), .A2(n187), .Y(n101) );
  OAI22X1_RVT U93 ( .A1(n174), .A2(n105), .A3(n179), .A4(n108), .Y(n98) );
  NOR2X0_RVT U94 ( .A1(n177), .A2(n106), .Y(n107) );
  OAI22X1_RVT U95 ( .A1(n175), .A2(n105), .A3(n181), .A4(n108), .Y(n103) );
  AO21X1_RVT U96 ( .A1(n45), .A2(n128), .A3(n10), .Y(n121) );
  AND2X1_RVT U97 ( .A1(n29), .A2(n63), .Y(n62) );
  INVX0_RVT U98 ( .A(n86), .Y(n148) );
  OR3X1_RVT U99 ( .A1(n70), .A2(n107), .A3(n104), .Y(n78) );
  NOR2X0_RVT U100 ( .A1(n37), .A2(n108), .Y(n70) );
  OR3X1_RVT U101 ( .A1(n104), .A2(n85), .A3(n71), .Y(n117) );
  AO21X1_RVT U102 ( .A1(n83), .A2(\mem[0][0] ), .A3(n84), .Y(n71) );
  OR3X1_RVT U103 ( .A1(n107), .A2(n82), .A3(n77), .Y(n116) );
  OR2X1_RVT U104 ( .A1(n121), .A2(n175), .Y(n87) );
  AO21X1_RVT U105 ( .A1(1'b0), .A2(n115), .A3(n90), .Y(n91) );
  AOI21X1_RVT U106 ( .A1(n116), .A2(n117), .A3(n118), .Y(n132) );
  AO21X1_RVT U107 ( .A1(\mem[3][4] ), .A2(n149), .A3(n147), .Y(n72) );
  INVX0_RVT U110 ( .A(addr[1]), .Y(n88) );
  OR2X2_RVT U111 ( .A1(addr[0]), .A2(n88), .Y(n127) );
  INVX0_RVT U112 ( .A(n35), .Y(n100) );
  AND2X1_RVT U113 ( .A1(n100), .A2(1'b0), .Y(n92) );
  INVX0_RVT U114 ( .A(addr[0]), .Y(n89) );
  OR2X2_RVT U115 ( .A1(addr[1]), .A2(n89), .Y(n105) );
  NOR2X0_RVT U116 ( .A1(n108), .A2(1'b1), .Y(n90) );
  OR3X1_RVT U117 ( .A1(n96), .A2(n95), .A3(n94), .Y(n111) );
  OR3X1_RVT U118 ( .A1(n99), .A2(n98), .A3(n97), .Y(n110) );
  NBUFFX2_RVT U119 ( .A(n109), .Y(n163) );
  NBUFFX2_RVT U120 ( .A(n111), .Y(n112) );
  NOR2X0_RVT U121 ( .A1(n69), .A2(n86), .Y(n113) );
  AO21X1_RVT U122 ( .A1(n169), .A2(n69), .A3(n113), .Y(n48) );
  OR2X1_RVT U123 ( .A1(n172), .A2(n121), .Y(n120) );
  OR2X2_RVT U124 ( .A1(rst), .A2(n132), .Y(n130) );
  OR2X1_RVT U125 ( .A1(n130), .A2(n27), .Y(n119) );
  NAND2X0_RVT U126 ( .A1(n120), .A2(n119), .Y(n59) );
  NAND2X0_RVT U127 ( .A1(n122), .A2(n87), .Y(n57) );
  AND2X1_RVT U128 ( .A1(mem_write), .A2(n159), .Y(n123) );
  NAND2X0_RVT U129 ( .A1(n16), .A2(n53), .Y(n137) );
  OR2X1_RVT U130 ( .A1(n137), .A2(n183), .Y(n124) );
  NAND2X0_RVT U131 ( .A1(n125), .A2(n124), .Y(n73) );
  OR2X1_RVT U132 ( .A1(rst), .A2(n151), .Y(n129) );
  INVX1_RVT U133 ( .A(n69), .Y(n136) );
  MUX21X1_RVT U134 ( .A1(\mem[0][0] ), .A2(n129), .S0(n136), .Y(n52) );
  AND2X1_RVT U135 ( .A1(n151), .A2(n16), .Y(n126) );
  MUX21X1_RVT U136 ( .A1(n126), .A2(\mem[3][0] ), .S0(n149), .Y(n76) );
  MUX21X1_RVT U137 ( .A1(n129), .A2(\mem[1][0] ), .S0(n27), .Y(n60) );
  AO21X1_RVT U138 ( .A1(n128), .A2(mem_write), .A3(rst), .Y(n142) );
  AND2X1_RVT U139 ( .A1(n143), .A2(n142), .Y(n146) );
  MUX21X1_RVT U140 ( .A1(\mem[2][0] ), .A2(n129), .S0(n146), .Y(n68) );
  INVX0_RVT U141 ( .A(n130), .Y(n131) );
  MUX21X1_RVT U142 ( .A1(\mem[0][1] ), .A2(n131), .S0(n14), .Y(n51) );
  NAND2X0_RVT U143 ( .A1(n132), .A2(n16), .Y(n133) );
  MUX21X1_RVT U144 ( .A1(n133), .A2(\mem[3][1] ), .S0(n149), .Y(n75) );
  MUX21X1_RVT U145 ( .A1(\mem[2][1] ), .A2(n133), .S0(n146), .Y(n67) );
  INVX0_RVT U146 ( .A(n134), .Y(n135) );
  MUX21X1_RVT U147 ( .A1(\mem[0][2] ), .A2(n140), .S0(n136), .Y(n50) );
  NOR2X0_RVT U148 ( .A1(n137), .A2(n180), .Y(n138) );
  MUX21X1_RVT U149 ( .A1(n140), .A2(\mem[1][2] ), .S0(n27), .Y(n58) );
  INVX0_RVT U150 ( .A(n141), .Y(n144) );
  MUX21X1_RVT U151 ( .A1(n148), .A2(\mem[2][4] ), .S0(n150), .Y(n64) );
  AND2X1_RVT U152 ( .A1(mem_read), .A2(n16), .Y(n164) );
  NOR2X0_RVT U153 ( .A1(n154), .A2(n151), .Y(n152) );
  AO21X1_RVT U154 ( .A1(n165), .A2(stock[0]), .A3(n152), .Y(n30) );
  NOR2X0_RVT U155 ( .A1(n154), .A2(n153), .Y(n155) );
  AO21X1_RVT U156 ( .A1(n165), .A2(stock[1]), .A3(n155), .Y(n31) );
  NBUFFX2_RVT U157 ( .A(addr[1]), .Y(n156) );
  AO22X1_RVT U158 ( .A1(n156), .A2(n164), .A3(n165), .A4(price[6]), .Y(n44) );
  NBUFFX2_RVT U159 ( .A(addr[0]), .Y(n157) );
  AO22X1_RVT U160 ( .A1(n157), .A2(n164), .A3(n165), .A4(price[5]), .Y(n43) );
  INVX0_RVT U161 ( .A(n156), .Y(n158) );
  AO22X1_RVT U162 ( .A1(price[4]), .A2(n165), .A3(n164), .A4(n158), .Y(n42) );
  AO22X1_RVT U163 ( .A1(price[3]), .A2(n165), .A3(n164), .A4(n161), .Y(n41) );
  AO22X1_RVT U164 ( .A1(n159), .A2(n164), .A3(n165), .A4(price[2]), .Y(n40) );
  NAND2X0_RVT U165 ( .A1(n28), .A2(n35), .Y(n160) );
  AO22X1_RVT U166 ( .A1(n164), .A2(n160), .A3(n165), .A4(price[1]), .Y(n39) );
  AO22X1_RVT U167 ( .A1(price[0]), .A2(n165), .A3(n164), .A4(n161), .Y(n38) );
  AO22X1_RVT U168 ( .A1(stock[4]), .A2(n165), .A3(n112), .A4(n164), .Y(n34) );
  AO22X1_RVT U169 ( .A1(stock[3]), .A2(n165), .A3(n163), .A4(n164), .Y(n33) );
  AO22X1_RVT U170 ( .A1(stock[2]), .A2(n165), .A3(n29), .A4(n164), .Y(n32) );
endmodule


module comparator ( credit, price, stock, can_sell );
  input [7:0] credit;
  input [7:0] price;
  input [7:0] stock;
  output can_sell;
  wire   n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15, n16,
         n17, n18;

  NAND2X0_RVT U2 ( .A1(n15), .A2(n14), .Y(n17) );
  INVX0_RVT U3 ( .A(price[1]), .Y(n3) );
  INVX0_RVT U4 ( .A(credit[0]), .Y(n1) );
  NAND2X0_RVT U5 ( .A1(price[0]), .A2(n1), .Y(n2) );
  AO222X1_RVT U6 ( .A1(credit[1]), .A2(n3), .A3(credit[1]), .A4(n2), .A5(n3), 
        .A6(n2), .Y(n5) );
  INVX0_RVT U7 ( .A(price[2]), .Y(n4) );
  AO222X1_RVT U8 ( .A1(credit[2]), .A2(n5), .A3(credit[2]), .A4(n4), .A5(n5), 
        .A6(n4), .Y(n7) );
  INVX0_RVT U9 ( .A(price[3]), .Y(n6) );
  AO222X1_RVT U10 ( .A1(credit[3]), .A2(n7), .A3(credit[3]), .A4(n6), .A5(n7), 
        .A6(n6), .Y(n9) );
  INVX0_RVT U11 ( .A(price[4]), .Y(n8) );
  AO222X1_RVT U12 ( .A1(credit[4]), .A2(n9), .A3(credit[4]), .A4(n8), .A5(n9), 
        .A6(n8), .Y(n11) );
  INVX0_RVT U13 ( .A(price[5]), .Y(n10) );
  AO222X1_RVT U14 ( .A1(credit[5]), .A2(n11), .A3(credit[5]), .A4(n10), .A5(
        n11), .A6(n10), .Y(n13) );
  INVX0_RVT U15 ( .A(price[6]), .Y(n12) );
  AO222X1_RVT U16 ( .A1(credit[6]), .A2(n13), .A3(credit[6]), .A4(n12), .A5(
        n13), .A6(n12), .Y(n18) );
  INVX0_RVT U17 ( .A(stock[5]), .Y(n15) );
  INVX0_RVT U18 ( .A(stock[4]), .Y(n14) );
  OR4X1_RVT U19 ( .A1(stock[3]), .A2(stock[2]), .A3(stock[1]), .A4(stock[0]), 
        .Y(n16) );
  OA22X1_RVT U20 ( .A1(credit[7]), .A2(n18), .A3(n17), .A4(n16), .Y(can_sell)
         );
endmodule


module subtractor ( credit, price, change );
  input [7:0] credit;
  input [7:0] price;
  output [7:0] change;
  wire   \intadd_8/B[5] , \intadd_8/B[4] , \intadd_8/B[3] , \intadd_8/B[2] ,
         \intadd_8/B[1] , \intadd_8/B[0] , \intadd_8/CI , \intadd_8/SUM[5] ,
         \intadd_8/SUM[4] , \intadd_8/SUM[3] , \intadd_8/SUM[2] ,
         \intadd_8/SUM[1] , \intadd_8/SUM[0] , \intadd_8/n6 , \intadd_8/n5 ,
         \intadd_8/n4 , \intadd_8/n3 , \intadd_8/n2 , \intadd_8/n1 , n1;

  FADDX1_RVT \intadd_8/U7  ( .A(\intadd_8/B[0] ), .B(price[1]), .CI(
        \intadd_8/CI ), .CO(\intadd_8/n6 ), .S(\intadd_8/SUM[0] ) );
  FADDX1_RVT \intadd_8/U6  ( .A(\intadd_8/B[1] ), .B(price[2]), .CI(
        \intadd_8/n6 ), .CO(\intadd_8/n5 ), .S(\intadd_8/SUM[1] ) );
  FADDX1_RVT \intadd_8/U5  ( .A(\intadd_8/B[2] ), .B(price[3]), .CI(
        \intadd_8/n5 ), .CO(\intadd_8/n4 ), .S(\intadd_8/SUM[2] ) );
  FADDX1_RVT \intadd_8/U4  ( .A(\intadd_8/B[3] ), .B(price[4]), .CI(
        \intadd_8/n4 ), .CO(\intadd_8/n3 ), .S(\intadd_8/SUM[3] ) );
  FADDX1_RVT \intadd_8/U3  ( .A(\intadd_8/B[4] ), .B(price[5]), .CI(
        \intadd_8/n3 ), .CO(\intadd_8/n2 ), .S(\intadd_8/SUM[4] ) );
  FADDX1_RVT \intadd_8/U2  ( .A(\intadd_8/B[5] ), .B(price[6]), .CI(
        \intadd_8/n2 ), .CO(\intadd_8/n1 ), .S(\intadd_8/SUM[5] ) );
  XOR2X1_RVT U1 ( .A1(\intadd_8/n1 ), .A2(credit[7]), .Y(change[7]) );
  INVX0_RVT U2 ( .A(\intadd_8/SUM[3] ), .Y(change[4]) );
  INVX0_RVT U3 ( .A(\intadd_8/SUM[2] ), .Y(change[3]) );
  INVX0_RVT U4 ( .A(\intadd_8/SUM[5] ), .Y(change[6]) );
  INVX0_RVT U5 ( .A(\intadd_8/SUM[4] ), .Y(change[5]) );
  INVX0_RVT U6 ( .A(\intadd_8/SUM[0] ), .Y(change[1]) );
  INVX0_RVT U7 ( .A(\intadd_8/SUM[1] ), .Y(change[2]) );
  INVX0_RVT U8 ( .A(price[0]), .Y(n1) );
  NOR2X0_RVT U9 ( .A1(n1), .A2(credit[0]), .Y(\intadd_8/CI ) );
  INVX0_RVT U10 ( .A(credit[6]), .Y(\intadd_8/B[5] ) );
  INVX0_RVT U11 ( .A(credit[3]), .Y(\intadd_8/B[2] ) );
  INVX0_RVT U12 ( .A(credit[4]), .Y(\intadd_8/B[3] ) );
  INVX0_RVT U13 ( .A(credit[5]), .Y(\intadd_8/B[4] ) );
  INVX0_RVT U14 ( .A(credit[1]), .Y(\intadd_8/B[0] ) );
  INVX0_RVT U15 ( .A(credit[2]), .Y(\intadd_8/B[1] ) );
  AO21X1_RVT U16 ( .A1(credit[0]), .A2(n1), .A3(\intadd_8/CI ), .Y(change[0])
         );
endmodule


module control_unit ( clk, rst, cancel, coin_in, confirm, can_sell, state, 
        credit_load, credit_clear, mem_read, mem_write, dispense, error, 
        change_load );
  input [1:0] coin_in;
  output [2:0] state;
  input clk, rst, cancel, confirm, can_sell;
  output credit_load, credit_clear, mem_read, mem_write, dispense, error,
         change_load;
  wire   mem_write, check_wait, N20, N21, N22, n1, n2, n3, n4, n5, n6, n7, n8,
         n9, n10, n11, n12, n13, n14, n19, n20, n21, n22, n23, n24;
  assign dispense = mem_write;

  DFFSSRX1_RVT check_wait_reg ( .D(n24), .SETB(1'b1), .RSTB(n23), .CLK(clk), 
        .Q(check_wait), .QN(n21) );
  DFFARX1_RVT \current_state_reg[0]  ( .D(N20), .CLK(clk), .RSTB(1'b1), .Q(
        state[0]), .QN(n20) );
  DFFARX1_RVT \current_state_reg[2]  ( .D(N22), .CLK(clk), .RSTB(1'b1), .Q(
        state[2]), .QN(n19) );
  DFFARX1_RVT \current_state_reg[1]  ( .D(N21), .CLK(clk), .RSTB(1'b1), .Q(
        state[1]), .QN(n22) );
  NOR2X0_RVT U3 ( .A1(rst), .A2(cancel), .Y(n24) );
  INVX0_RVT U4 ( .A(n13), .Y(n4) );
  INVX0_RVT U5 ( .A(n11), .Y(n12) );
  AND2X1_RVT U6 ( .A1(n1), .A2(n2), .Y(N21) );
  AND2X1_RVT U7 ( .A1(n24), .A2(n19), .Y(n1) );
  INVX0_RVT U8 ( .A(mem_read), .Y(n3) );
  NAND2X0_RVT U9 ( .A1(n3), .A2(n4), .Y(n2) );
  AO222X1_RVT U14 ( .A1(n19), .A2(state[1]), .A3(n19), .A4(coin_in[1]), .A5(
        n19), .A6(coin_in[0]), .Y(n5) );
  OA222X1_RVT U15 ( .A1(n22), .A2(check_wait), .A3(n22), .A4(n20), .A5(
        state[0]), .A6(n5), .Y(n6) );
  AND2X1_RVT U16 ( .A1(n6), .A2(n24), .Y(n8) );
  NAND2X0_RVT U17 ( .A1(state[0]), .A2(confirm), .Y(n11) );
  OR2X1_RVT U18 ( .A1(n11), .A2(state[2]), .Y(n7) );
  AND2X1_RVT U19 ( .A1(n8), .A2(n7), .Y(N20) );
  AND2X1_RVT U20 ( .A1(n19), .A2(n22), .Y(n10) );
  OR2X1_RVT U21 ( .A1(coin_in[0]), .A2(coin_in[1]), .Y(n9) );
  AND2X1_RVT U22 ( .A1(n10), .A2(n9), .Y(credit_load) );
  AND2X1_RVT U23 ( .A1(state[2]), .A2(n22), .Y(change_load) );
  AND2X1_RVT U24 ( .A1(change_load), .A2(n20), .Y(credit_clear) );
  AND4X1_RVT U25 ( .A1(state[1]), .A2(n20), .A3(n19), .A4(n21), .Y(mem_read)
         );
  OA222X1_RVT U26 ( .A1(n22), .A2(can_sell), .A3(n22), .A4(n20), .A5(state[1]), 
        .A6(n12), .Y(n13) );
  AND2X1_RVT U27 ( .A1(state[0]), .A2(change_load), .Y(error) );
  AND3X1_RVT U28 ( .A1(state[1]), .A2(state[0]), .A3(n19), .Y(mem_write) );
  NOR4X1_RVT U29 ( .A1(state[2]), .A2(can_sell), .A3(n22), .A4(n21), .Y(n14)
         );
  AO222X1_RVT U30 ( .A1(n24), .A2(n14), .A3(n24), .A4(mem_write), .A5(n24), 
        .A6(error), .Y(N22) );
  AO221X1_RVT U31 ( .A1(check_wait), .A2(change_load), .A3(check_wait), .A4(
        mem_write), .A5(mem_read), .Y(n23) );
endmodule


module vending_top ( clk, rst, coin_in, sel_item, confirm, cancel, dispense, 
        change_out, error, display, state_out );
  input [1:0] coin_in;
  input [1:0] sel_item;
  output [7:0] change_out;
  output [7:0] display;
  output [2:0] state_out;
  input clk, rst, confirm, cancel;
  output dispense, error;
  wire   credit_clear, credit_load, mem_read, mem_write, can_sell, change_load,
         n10, n11, n12, n13, n14, n15, n16, n17, n19, n20, n21, n22, n23, n24,
         n25, n26, n27, n28, n29, n30, n31, net18698, net18699, net18700,
         net18701, net18702;
  wire   [6:0] coin_value;
  wire   [7:0] price;
  wire   [7:0] stock;
  wire   [7:0] change;
  wire   SYNOPSYS_UNCONNECTED__0, SYNOPSYS_UNCONNECTED__1, 
        SYNOPSYS_UNCONNECTED__2;

  credit_reg u_credit_reg ( .clk(clk), .rst(rst), .cancel(cancel), .clear(
        credit_clear), .load(credit_load), .coin_value({net18702, 
        coin_value[6], n20, n21, n19, coin_value[6], coin_value[1], 
        coin_value[3]}), .credit(display) );
  memory u_memory ( .clk(clk), .rst(rst), .mem_read(mem_read), .mem_write(
        mem_write), .addr(sel_item), .price({SYNOPSYS_UNCONNECTED__0, 
        price[6:0]}), .stock({SYNOPSYS_UNCONNECTED__1, SYNOPSYS_UNCONNECTED__2, 
        stock[5:0]}) );
  comparator u_comparator ( .credit(display), .price({net18699, price[6:0]}), 
        .stock({net18700, net18701, stock[5:0]}), .can_sell(can_sell) );
  subtractor u_subtractor ( .credit(display), .price({net18698, price[6:0]}), 
        .change(change) );
  control_unit u_control_unit ( .clk(clk), .rst(rst), .cancel(cancel), 
        .coin_in({n20, coin_in[0]}), .confirm(confirm), .can_sell(can_sell), 
        .state(state_out), .credit_load(credit_load), .credit_clear(
        credit_clear), .mem_read(mem_read), .mem_write(mem_write), .dispense(
        dispense), .error(error), .change_load(change_load) );
  DFFX1_RVT \change_out_reg[7]  ( .D(n17), .CLK(clk), .Q(change_out[7]) );
  DFFX1_RVT \change_out_reg[6]  ( .D(n16), .CLK(clk), .Q(change_out[6]) );
  DFFX1_RVT \change_out_reg[5]  ( .D(n15), .CLK(clk), .Q(change_out[5]) );
  DFFX1_RVT \change_out_reg[4]  ( .D(n14), .CLK(clk), .Q(change_out[4]) );
  DFFX1_RVT \change_out_reg[3]  ( .D(n13), .CLK(clk), .Q(change_out[3]) );
  DFFX1_RVT \change_out_reg[2]  ( .D(n12), .CLK(clk), .Q(change_out[2]) );
  DFFX1_RVT \change_out_reg[1]  ( .D(n11), .CLK(clk), .Q(change_out[1]) );
  DFFX1_RVT \change_out_reg[0]  ( .D(n10), .CLK(clk), .Q(change_out[0]) );
  NOR3X0_RVT U25 ( .A1(rst), .A2(cancel), .A3(change_load), .Y(n29) );
  AND2X1_RVT U26 ( .A1(coin_in[0]), .A2(n22), .Y(n19) );
  INVX0_RVT U27 ( .A(rst), .Y(n28) );
  INVX0_RVT U28 ( .A(cancel), .Y(n27) );
  NBUFFX2_RVT U29 ( .A(coin_in[1]), .Y(n20) );
  OR2X1_RVT U30 ( .A1(n19), .A2(coin_value[1]), .Y(n21) );
  INVX0_RVT U31 ( .A(coin_in[1]), .Y(n22) );
  AND2X1_RVT U32 ( .A1(coin_in[0]), .A2(n22), .Y(coin_value[3]) );
  INVX0_RVT U33 ( .A(coin_in[0]), .Y(n23) );
  AND2X1_RVT U34 ( .A1(coin_in[1]), .A2(n23), .Y(coin_value[1]) );
  AND2X1_RVT U35 ( .A1(coin_in[0]), .A2(coin_in[1]), .Y(coin_value[6]) );
  INVX0_RVT U37 ( .A(state_out[1]), .Y(n24) );
  NAND3X0_RVT U38 ( .A1(state_out[0]), .A2(state_out[2]), .A3(n24), .Y(n26) );
  INVX0_RVT U39 ( .A(n26), .Y(n25) );
  OA221X1_RVT U40 ( .A1(cancel), .A2(change_load), .A3(cancel), .A4(n25), .A5(
        n28), .Y(n31) );
  AND4X1_RVT U41 ( .A1(change_load), .A2(n28), .A3(n27), .A4(n26), .Y(n30) );
  AO222X1_RVT U42 ( .A1(n31), .A2(display[7]), .A3(n29), .A4(change_out[7]), 
        .A5(n30), .A6(change[7]), .Y(n17) );
  AO222X1_RVT U43 ( .A1(n31), .A2(display[6]), .A3(n30), .A4(change[6]), .A5(
        change_out[6]), .A6(n29), .Y(n16) );
  AO222X1_RVT U44 ( .A1(n31), .A2(display[5]), .A3(n30), .A4(change[5]), .A5(
        change_out[5]), .A6(n29), .Y(n15) );
  AO222X1_RVT U45 ( .A1(n31), .A2(display[4]), .A3(n30), .A4(change[4]), .A5(
        change_out[4]), .A6(n29), .Y(n14) );
  AO222X1_RVT U46 ( .A1(n31), .A2(display[3]), .A3(n30), .A4(change[3]), .A5(
        change_out[3]), .A6(n29), .Y(n13) );
  AO222X1_RVT U47 ( .A1(n31), .A2(display[2]), .A3(n30), .A4(change[2]), .A5(
        change_out[2]), .A6(n29), .Y(n12) );
  AO222X1_RVT U48 ( .A1(n31), .A2(display[1]), .A3(n30), .A4(change[1]), .A5(
        change_out[1]), .A6(n29), .Y(n11) );
  AO222X1_RVT U49 ( .A1(n31), .A2(display[0]), .A3(n30), .A4(change[0]), .A5(
        change_out[0]), .A6(n29), .Y(n10) );
endmodule

