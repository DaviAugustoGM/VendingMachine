/////////////////////////////////////////////////////////////
// Created by: Synopsys DC Ultra(TM) in wire load mode
// Version   : X-2025.06-SP2
// Date      : Thu Jul  9 13:25:06 2026
/////////////////////////////////////////////////////////////


module vending_top ( clk, rst, coin_in, sel_item, confirm, cancel, dispense, 
        change_out, error, display, state_out );
  input [1:0] coin_in;
  input [1:0] sel_item;
  output [7:0] change_out;
  output [7:0] display;
  output [2:0] state_out;
  input clk, rst, confirm, cancel;
  output dispense, error;
  wire   \u_memory/mem[0][5] , \u_memory/mem[0][4] , \u_memory/mem[0][3] ,
         \u_memory/mem[0][2] , \u_memory/mem[0][1] , \u_memory/mem[0][0] ,
         \u_memory/mem[1][5] , \u_memory/mem[1][4] , \u_memory/mem[1][3] ,
         \u_memory/mem[1][2] , \u_memory/mem[1][1] , \u_memory/mem[1][0] ,
         \u_memory/mem[2][5] , \u_memory/mem[2][4] , \u_memory/mem[2][3] ,
         \u_memory/mem[2][2] , \u_memory/mem[2][1] , \u_memory/mem[2][0] ,
         \u_memory/mem[3][5] , \u_memory/mem[3][4] , \u_memory/mem[3][3] ,
         \u_memory/mem[3][2] , \u_memory/mem[3][1] , \u_memory/mem[3][0] ,
         \u_control_unit/N22 , \u_control_unit/N21 , \u_control_unit/N20 ,
         \u_control_unit/check_wait , n73, n74, n75, n76, n77, n78, n79, n80,
         n81, n82, n83, n84, n85, n86, n87, n88, n91, n92, n93, n94, n95, n96,
         n97, n98, n99, n100, n101, n102, n103, n106, n107, n108, n109, n110,
         n111, n114, n115, n116, n117, n119, n122, n123, n124, n126, n127,
         n130, n131, n132, n133, n134, n135, n136, \intadd_19/CI ,
         \intadd_19/SUM[4] , \intadd_19/SUM[3] , \intadd_19/SUM[2] ,
         \intadd_19/SUM[1] , \intadd_19/SUM[0] , \intadd_19/n5 ,
         \intadd_19/n4 , \intadd_19/n3 , \intadd_19/n2 , \intadd_19/n1 , n146,
         n147, n148, n149, n150, n151, n152, n153, n154, n155, n156, n157,
         n158, n159, n160, n161, n162, n163, n164, n165, n166, n167, n168,
         n169, n170, n171, n172, n173, n174, n175, n176, n177, n178, n179,
         n180, n181, n182, n183, n184, n185, n186, n187, n188, n189, n190,
         n191, n192, n193, n194, n195, n196, n197, n198, n199, n200, n201,
         n202, n203, n204, n205, n206, n207, n208, n209, n210, n211, n212,
         n213, n214, n215, n216, n217, n218, n219, n220, n221, n222, n223,
         n224, n225, n226, n227, n228, n229, n230, n231, n232, n233, n234,
         n235, n236, n237, n238, n239, n240, n241, n242, n243, n244, n245,
         n246, n247, n248, n249, n250, n251, n252, n253, n254, n255, n256,
         n257, n258, n259, n260, n261, n262, n263, n264, n265, n266, n267,
         n268, n269, n270, n271, n272, n273, n274, n275, n276, n277, n278,
         n279, n280, n281, n282, n283, n284, n285, n286, n287, n288, n289,
         n290, n291, n292, n293, n294, n295, n296, n297, n298, n299, n300,
         n301, n302, n303, n304, n305, n306, n307, n308, n309, n310, n311,
         n312, n313, n314, n315, n316, n317, n318, n319, n320, n321, n322,
         n323, n324, n325, n326, n327, n328, n329, n330, n331, n332, n333,
         n334, n335, n336, n337, n338, n339, n340, n341, n342, n343, n344,
         n345, n346, n347, n348, n349, n350, n351, n352, n353, n354, n355,
         n356, n357, n358, n359, n360, n361, n362, n363, n364, n365, n367,
         n368, n369, n370, n371, n372, n373, n374, n375, n376, n377, n378,
         n379, n380, n381, n382, n383, n384, n385, n386, n387, n388, n389,
         n390, n391, n392, n393, n394, n395;
  wire   [7:0] price;
  wire   [7:0] stock;

  DFFX1_RVT \u_control_unit/check_wait_reg  ( .D(n136), .CLK(clk), .Q(
        \u_control_unit/check_wait ), .QN(n391) );
  DFFX1_RVT \u_control_unit/current_state_reg[2]  ( .D(\u_control_unit/N22 ), 
        .CLK(clk), .Q(state_out[2]), .QN(n388) );
  DFFX1_RVT \u_control_unit/current_state_reg[0]  ( .D(\u_control_unit/N20 ), 
        .CLK(clk), .Q(state_out[0]), .QN(n390) );
  DFFX1_RVT \u_memory/mem_reg[3][1]  ( .D(n134), .CLK(clk), .Q(
        \u_memory/mem[3][1] ), .QN(n373) );
  DFFX1_RVT \u_memory/mem_reg[3][0]  ( .D(n135), .CLK(clk), .Q(
        \u_memory/mem[3][0] ), .QN(n372) );
  DFFX1_RVT \u_memory/mem_reg[3][2]  ( .D(n133), .CLK(clk), .Q(
        \u_memory/mem[3][2] ), .QN(n374) );
  DFFX1_RVT \u_memory/mem_reg[3][3]  ( .D(n132), .CLK(clk), .Q(
        \u_memory/mem[3][3] ), .QN(n378) );
  DFFX1_RVT \u_memory/mem_reg[3][4]  ( .D(n131), .CLK(clk), .Q(
        \u_memory/mem[3][4] ), .QN(n381) );
  DFFX1_RVT \u_memory/mem_reg[3][5]  ( .D(n130), .CLK(clk), .Q(
        \u_memory/mem[3][5] ), .QN(n384) );
  DFFX1_RVT \u_memory/mem_reg[2][0]  ( .D(n127), .CLK(clk), .Q(
        \u_memory/mem[2][0] ) );
  DFFX1_RVT \u_memory/mem_reg[2][1]  ( .D(n126), .CLK(clk), .Q(
        \u_memory/mem[2][1] ) );
  DFFX1_RVT \u_memory/mem_reg[2][2]  ( .D(n185), .CLK(clk), .Q(
        \u_memory/mem[2][2] ), .QN(n395) );
  DFFX1_RVT \u_memory/mem_reg[2][3]  ( .D(n124), .CLK(clk), .Q(
        \u_memory/mem[2][3] ) );
  DFFX1_RVT \u_memory/mem_reg[2][4]  ( .D(n123), .CLK(clk), .Q(
        \u_memory/mem[2][4] ) );
  DFFX1_RVT \u_memory/mem_reg[2][5]  ( .D(n122), .CLK(clk), .Q(
        \u_memory/mem[2][5] ) );
  DFFX1_RVT \u_memory/mem_reg[1][2]  ( .D(n117), .CLK(clk), .Q(
        \u_memory/mem[1][2] ) );
  DFFX1_RVT \u_memory/mem_reg[1][1]  ( .D(n187), .CLK(clk), .Q(
        \u_memory/mem[1][1] ), .QN(n394) );
  DFFX1_RVT \u_memory/mem_reg[1][3]  ( .D(n116), .CLK(clk), .Q(
        \u_memory/mem[1][3] ) );
  DFFX1_RVT \u_memory/mem_reg[1][4]  ( .D(n115), .CLK(clk), .Q(
        \u_memory/mem[1][4] ) );
  DFFX1_RVT \u_memory/mem_reg[1][5]  ( .D(n114), .CLK(clk), .Q(
        \u_memory/mem[1][5] ) );
  DFFX1_RVT \u_memory/mem_reg[0][0]  ( .D(n111), .CLK(clk), .Q(
        \u_memory/mem[0][0] ), .QN(n369) );
  DFFX1_RVT \u_memory/mem_reg[0][2]  ( .D(n109), .CLK(clk), .Q(
        \u_memory/mem[0][2] ), .QN(n375) );
  DFFX1_RVT \u_memory/mem_reg[0][1]  ( .D(n110), .CLK(clk), .Q(
        \u_memory/mem[0][1] ), .QN(n370) );
  DFFX1_RVT \u_memory/mem_reg[0][3]  ( .D(n108), .CLK(clk), .Q(
        \u_memory/mem[0][3] ), .QN(n377) );
  DFFX1_RVT \u_memory/mem_reg[0][4]  ( .D(n107), .CLK(clk), .Q(
        \u_memory/mem[0][4] ), .QN(n379) );
  DFFX1_RVT \u_memory/mem_reg[0][5]  ( .D(n106), .CLK(clk), .Q(
        \u_memory/mem[0][5] ), .QN(n382) );
  DFFX1_RVT \u_credit_reg/credit_reg[1]  ( .D(n88), .CLK(clk), .Q(display[1]), 
        .QN(n393) );
  DFFX1_RVT \change_out_reg[0]  ( .D(n80), .CLK(clk), .Q(change_out[0]) );
  DFFX1_RVT \change_out_reg[1]  ( .D(n79), .CLK(clk), .Q(change_out[1]) );
  DFFX1_RVT \change_out_reg[2]  ( .D(n78), .CLK(clk), .Q(change_out[2]) );
  DFFX1_RVT \change_out_reg[3]  ( .D(n77), .CLK(clk), .Q(change_out[3]) );
  DFFX1_RVT \change_out_reg[4]  ( .D(n76), .CLK(clk), .Q(change_out[4]) );
  DFFX1_RVT \change_out_reg[5]  ( .D(n75), .CLK(clk), .Q(change_out[5]) );
  DFFX1_RVT \change_out_reg[6]  ( .D(n74), .CLK(clk), .Q(change_out[6]) );
  DFFX1_RVT \change_out_reg[7]  ( .D(n73), .CLK(clk), .Q(change_out[7]) );
  DFFX1_RVT \u_memory/price_reg[0]  ( .D(n103), .CLK(clk), .Q(price[0]), .QN(
        n368) );
  DFFX1_RVT \u_memory/price_reg[1]  ( .D(n102), .CLK(clk), .Q(price[1]), .QN(
        n371) );
  DFFX1_RVT \u_memory/price_reg[2]  ( .D(n101), .CLK(clk), .Q(price[2]), .QN(
        n376) );
  DFFX1_RVT \u_memory/price_reg[3]  ( .D(n100), .CLK(clk), .QN(n380) );
  DFFX1_RVT \u_memory/price_reg[4]  ( .D(n99), .CLK(clk), .Q(price[4]), .QN(
        n383) );
  DFFX1_RVT \u_memory/price_reg[5]  ( .D(n98), .CLK(clk), .Q(price[5]), .QN(
        n385) );
  DFFX1_RVT \u_memory/price_reg[6]  ( .D(n97), .CLK(clk), .Q(price[6]), .QN(
        n387) );
  DFFX1_RVT \u_memory/stock_reg[0]  ( .D(n96), .CLK(clk), .Q(stock[0]), .QN(
        n389) );
  DFFX1_RVT \u_memory/stock_reg[1]  ( .D(n95), .CLK(clk), .Q(stock[1]), .QN(
        n367) );
  DFFX1_RVT \u_memory/stock_reg[2]  ( .D(n94), .CLK(clk), .Q(stock[2]) );
  DFFX1_RVT \u_memory/stock_reg[3]  ( .D(n93), .CLK(clk), .Q(stock[3]) );
  DFFX1_RVT \u_memory/stock_reg[4]  ( .D(n92), .CLK(clk), .Q(stock[4]) );
  DFFX1_RVT \u_memory/stock_reg[5]  ( .D(n91), .CLK(clk), .Q(stock[5]) );
  FADDX1_RVT \intadd_19/U6  ( .A(display[2]), .B(n376), .CI(\intadd_19/CI ), 
        .CO(\intadd_19/n5 ), .S(\intadd_19/SUM[0] ) );
  FADDX1_RVT \intadd_19/U5  ( .A(display[3]), .B(n380), .CI(\intadd_19/n5 ), 
        .CO(\intadd_19/n4 ), .S(\intadd_19/SUM[1] ) );
  FADDX1_RVT \intadd_19/U4  ( .A(display[4]), .B(n383), .CI(\intadd_19/n4 ), 
        .CO(\intadd_19/n3 ), .S(\intadd_19/SUM[2] ) );
  FADDX1_RVT \intadd_19/U3  ( .A(display[5]), .B(n385), .CI(\intadd_19/n3 ), 
        .CO(\intadd_19/n2 ), .S(\intadd_19/SUM[3] ) );
  FADDX1_RVT \intadd_19/U2  ( .A(display[6]), .B(n387), .CI(\intadd_19/n2 ), 
        .CO(\intadd_19/n1 ), .S(\intadd_19/SUM[4] ) );
  DFFX2_RVT \u_credit_reg/credit_reg[7]  ( .D(n81), .CLK(clk), .Q(display[7]), 
        .QN(n392) );
  DFFARX1_RVT \u_control_unit/current_state_reg[1]  ( .D(\u_control_unit/N21 ), 
        .CLK(clk), .RSTB(1'b1), .Q(state_out[1]), .QN(n386) );
  DFFX2_RVT \u_memory/mem_reg[1][0]  ( .D(n119), .CLK(clk), .Q(
        \u_memory/mem[1][0] ) );
  DFFX2_RVT \u_credit_reg/credit_reg[0]  ( .D(n87), .CLK(clk), .Q(display[0])
         );
  DFFX2_RVT \u_credit_reg/credit_reg[2]  ( .D(n86), .CLK(clk), .Q(display[2])
         );
  DFFX2_RVT \u_credit_reg/credit_reg[4]  ( .D(n84), .CLK(clk), .Q(display[4]), 
        .QN(n180) );
  DFFX1_RVT \u_credit_reg/credit_reg[5]  ( .D(n83), .CLK(clk), .Q(display[5])
         );
  DFFX1_RVT \u_credit_reg/credit_reg[6]  ( .D(n82), .CLK(clk), .Q(display[6])
         );
  DFFX1_RVT \u_credit_reg/credit_reg[3]  ( .D(n85), .CLK(clk), .Q(display[3]), 
        .QN(n179) );
  NOR2X0_RVT U157 ( .A1(n183), .A2(n358), .Y(n363) );
  INVX1_RVT U158 ( .A(n170), .Y(n169) );
  NOR2X2_RVT U159 ( .A1(n183), .A2(n282), .Y(n281) );
  OR2X2_RVT U160 ( .A1(n183), .A2(n278), .Y(n266) );
  OR2X2_RVT U161 ( .A1(n183), .A2(n276), .Y(n265) );
  NBUFFX2_RVT U162 ( .A(rst), .Y(n183) );
  IBUFFX16_RVT U163 ( .A(n312), .Y(n354) );
  NOR2X0_RVT U164 ( .A1(coin_in[0]), .A2(coin_in[1]), .Y(n155) );
  INVX1_RVT U165 ( .A(n321), .Y(n329) );
  NAND2X0_RVT U166 ( .A1(n354), .A2(n163), .Y(n146) );
  INVX0_RVT U167 ( .A(n202), .Y(n168) );
  NAND2X0_RVT U168 ( .A1(n318), .A2(display[7]), .Y(n160) );
  NAND2X1_RVT U169 ( .A1(n179), .A2(n154), .Y(n182) );
  NAND2X0_RVT U170 ( .A1(n154), .A2(n179), .Y(n149) );
  AND2X2_RVT U171 ( .A1(coin_in[1]), .A2(coin_in[0]), .Y(n196) );
  NBUFFX2_RVT U172 ( .A(n192), .Y(n147) );
  INVX0_RVT U173 ( .A(n289), .Y(n158) );
  OR2X1_RVT U174 ( .A1(n196), .A2(n180), .Y(n289) );
  INVX0_RVT U175 ( .A(n308), .Y(n148) );
  NOR3X0_RVT U176 ( .A1(n170), .A2(n202), .A3(n159), .Y(n165) );
  AOI21X1_RVT U177 ( .A1(n298), .A2(n194), .A3(n193), .Y(n159) );
  AO21X1_RVT U178 ( .A1(n149), .A2(n151), .A3(n150), .Y(n193) );
  INVX0_RVT U179 ( .A(n150), .Y(n299) );
  AND2X1_RVT U180 ( .A1(n192), .A2(display[3]), .Y(n150) );
  INVX0_RVT U181 ( .A(n151), .Y(n303) );
  AND2X1_RVT U182 ( .A1(n196), .A2(display[2]), .Y(n151) );
  AND2X1_RVT U183 ( .A1(n182), .A2(n304), .Y(n194) );
  OR2X2_RVT U184 ( .A1(display[2]), .A2(n196), .Y(n304) );
  OR2X2_RVT U185 ( .A1(n153), .A2(n152), .Y(n298) );
  INVX0_RVT U186 ( .A(n309), .Y(n152) );
  AND3X1_RVT U187 ( .A1(n148), .A2(display[0]), .A3(n192), .Y(n153) );
  NAND2X0_RVT U188 ( .A1(n201), .A2(n173), .Y(n202) );
  NOR2X0_RVT U189 ( .A1(n290), .A2(n295), .Y(n173) );
  NOR2X0_RVT U190 ( .A1(n190), .A2(n192), .Y(n295) );
  NOR2X0_RVT U191 ( .A1(display[5]), .A2(n154), .Y(n290) );
  NBUFFX2_RVT U192 ( .A(coin_in[1]), .Y(n154) );
  OR3X1_RVT U193 ( .A1(n188), .A2(n155), .A3(n357), .Y(n312) );
  AO21X1_RVT U194 ( .A1(n158), .A2(n157), .A3(n156), .Y(n172) );
  INVX0_RVT U195 ( .A(n291), .Y(n156) );
  INVX0_RVT U196 ( .A(n290), .Y(n157) );
  INVX0_RVT U197 ( .A(n159), .Y(n167) );
  XOR2X1_RVT U198 ( .A1(n159), .A2(n296), .Y(n297) );
  NAND3X0_RVT U199 ( .A1(n162), .A2(n160), .A3(n161), .Y(n81) );
  NAND2X0_RVT U200 ( .A1(n354), .A2(n164), .Y(n161) );
  OR3X1_RVT U201 ( .A1(n171), .A2(n166), .A3(n146), .Y(n162) );
  INVX0_RVT U202 ( .A(n169), .Y(n163) );
  AO21X1_RVT U203 ( .A1(n171), .A2(n169), .A3(n165), .Y(n164) );
  AND2X1_RVT U204 ( .A1(n168), .A2(n167), .Y(n166) );
  INVX0_RVT U205 ( .A(n392), .Y(n170) );
  AO21X1_RVT U206 ( .A1(n172), .A2(n201), .A3(n200), .Y(n171) );
  AO21X1_RVT U207 ( .A1(n175), .A2(n173), .A3(n172), .Y(n197) );
  AO21X1_RVT U208 ( .A1(n175), .A2(n174), .A3(n158), .Y(n293) );
  INVX0_RVT U209 ( .A(n295), .Y(n174) );
  AO21X1_RVT U210 ( .A1(n298), .A2(n194), .A3(n193), .Y(n175) );
  NAND2X0_RVT U211 ( .A1(n147), .A2(display[0]), .Y(n176) );
  OR2X1_RVT U212 ( .A1(display[0]), .A2(n147), .Y(n178) );
  INVX2_RVT U213 ( .A(n313), .Y(n318) );
  NOR3X0_RVT U214 ( .A1(state_out[2]), .A2(n349), .A3(n338), .Y(n340) );
  INVX0_RVT U215 ( .A(n355), .Y(n356) );
  NOR2X0_RVT U216 ( .A1(error), .A2(cancel), .Y(n358) );
  NOR2X0_RVT U217 ( .A1(n312), .A2(n311), .Y(n315) );
  NOR2X0_RVT U218 ( .A1(n183), .A2(n275), .Y(n274) );
  INVX2_RVT U219 ( .A(n276), .Y(n256) );
  INVX2_RVT U220 ( .A(n278), .Y(n259) );
  AND2X1_RVT U221 ( .A1(n201), .A2(n199), .Y(n177) );
  OR2X1_RVT U222 ( .A1(n184), .A2(n181), .Y(n301) );
  NOR2X0_RVT U223 ( .A1(n380), .A2(n320), .Y(n322) );
  OR3X1_RVT U224 ( .A1(error), .A2(n351), .A3(n350), .Y(n352) );
  NOR2X0_RVT U225 ( .A1(n349), .A2(confirm), .Y(n350) );
  AND2X1_RVT U226 ( .A1(display[2]), .A2(n196), .Y(n181) );
  XOR2X1_RVT U227 ( .A1(n197), .A2(n177), .Y(n198) );
  AO22X1_RVT U228 ( .A1(n318), .A2(display[3]), .A3(n302), .A4(n354), .Y(n85)
         );
  AND2X1_RVT U229 ( .A1(n298), .A2(n304), .Y(n184) );
  NOR3X2_RVT U230 ( .A1(state_out[0]), .A2(n357), .A3(n356), .Y(n364) );
  AO21X1_RVT U231 ( .A1(n327), .A2(price[0]), .A3(n324), .Y(n103) );
  NOR2X0_RVT U232 ( .A1(sel_item[0]), .A2(n321), .Y(n324) );
  NOR2X0_RVT U233 ( .A1(n393), .A2(n313), .Y(n314) );
  AOI21X1_RVT U234 ( .A1(n353), .A2(state_out[0]), .A3(n362), .Y(n189) );
  OAI22X1_RVT U235 ( .A1(n395), .A2(n259), .A3(n258), .A4(n266), .Y(n185) );
  AND2X1_RVT U236 ( .A1(n292), .A2(n291), .Y(n186) );
  OAI22X1_RVT U237 ( .A1(n394), .A2(n256), .A3(n249), .A4(n265), .Y(n187) );
  NOR2X0_RVT U238 ( .A1(n196), .A2(display[6]), .Y(n195) );
  OR2X1_RVT U239 ( .A1(n340), .A2(n339), .Y(n341) );
  OA21X1_RVT U240 ( .A1(n342), .A2(n341), .A3(n353), .Y(\u_control_unit/N21 )
         );
  OR2X1_RVT U241 ( .A1(n322), .A2(n324), .Y(n100) );
  OR2X1_RVT U242 ( .A1(n315), .A2(n314), .Y(n88) );
  NOR2X0_RVT U243 ( .A1(n233), .A2(state_out[2]), .Y(dispense) );
  OR2X2_RVT U245 ( .A1(rst), .A2(cancel), .Y(n357) );
  INVX1_RVT U246 ( .A(n357), .Y(n353) );
  NOR2X2_RVT U247 ( .A1(state_out[1]), .A2(n388), .Y(n355) );
  NOR2X2_RVT U248 ( .A1(n357), .A2(n355), .Y(n362) );
  OR2X1_RVT U249 ( .A1(state_out[2]), .A2(state_out[1]), .Y(n188) );
  OR2X2_RVT U250 ( .A1(n189), .A2(n354), .Y(n313) );
  INVX0_RVT U251 ( .A(coin_in[1]), .Y(n192) );
  INVX0_RVT U252 ( .A(coin_in[0]), .Y(n191) );
  OR2X1_RVT U253 ( .A1(n191), .A2(display[4]), .Y(n190) );
  NOR2X0_RVT U254 ( .A1(display[1]), .A2(n191), .Y(n308) );
  NAND2X0_RVT U255 ( .A1(n191), .A2(display[1]), .Y(n309) );
  NAND2X0_RVT U256 ( .A1(n154), .A2(display[5]), .Y(n291) );
  INVX0_RVT U257 ( .A(n195), .Y(n201) );
  NAND2X0_RVT U258 ( .A1(display[6]), .A2(n196), .Y(n199) );
  AO22X1_RVT U259 ( .A1(n318), .A2(display[6]), .A3(n198), .A4(n354), .Y(n82)
         );
  INVX0_RVT U260 ( .A(n199), .Y(n200) );
  NAND2X0_RVT U261 ( .A1(state_out[1]), .A2(state_out[0]), .Y(n233) );
  OR2X1_RVT U262 ( .A1(n386), .A2(state_out[0]), .Y(n203) );
  OR2X1_RVT U263 ( .A1(state_out[2]), .A2(n203), .Y(n348) );
  NOR2X0_RVT U264 ( .A1(\u_control_unit/check_wait ), .A2(n348), .Y(n339) );
  INVX0_RVT U265 ( .A(n339), .Y(n206) );
  NOR2X0_RVT U266 ( .A1(dispense), .A2(n355), .Y(n204) );
  OR2X1_RVT U267 ( .A1(n204), .A2(n391), .Y(n205) );
  AOI21X1_RVT U268 ( .A1(n206), .A2(n205), .A3(n357), .Y(n136) );
  AND2X1_RVT U269 ( .A1(sel_item[0]), .A2(sel_item[1]), .Y(n323) );
  INVX0_RVT U270 ( .A(n323), .Y(n227) );
  NOR2X0_RVT U271 ( .A1(n227), .A2(n372), .Y(n210) );
  INVX0_RVT U272 ( .A(sel_item[0]), .Y(n245) );
  NOR2X0_RVT U273 ( .A1(sel_item[1]), .A2(n245), .Y(n325) );
  OR2X1_RVT U274 ( .A1(sel_item[1]), .A2(sel_item[0]), .Y(n228) );
  NOR2X0_RVT U275 ( .A1(n228), .A2(n369), .Y(n207) );
  AO21X1_RVT U276 ( .A1(\u_memory/mem[1][0] ), .A2(n325), .A3(n207), .Y(n209)
         );
  INVX0_RVT U277 ( .A(sel_item[1]), .Y(n319) );
  NOR2X0_RVT U278 ( .A1(sel_item[0]), .A2(n319), .Y(n326) );
  AND2X1_RVT U279 ( .A1(\u_memory/mem[2][0] ), .A2(n326), .Y(n208) );
  OR3X1_RVT U280 ( .A1(n210), .A2(n209), .A3(n208), .Y(n288) );
  INVX0_RVT U281 ( .A(n288), .Y(n247) );
  OR2X1_RVT U282 ( .A1(n247), .A2(n183), .Y(n243) );
  NOR2X0_RVT U283 ( .A1(n227), .A2(n378), .Y(n214) );
  NOR2X0_RVT U284 ( .A1(n228), .A2(n377), .Y(n211) );
  AO21X1_RVT U285 ( .A1(\u_memory/mem[1][3] ), .A2(n325), .A3(n211), .Y(n213)
         );
  AND2X1_RVT U286 ( .A1(\u_memory/mem[2][3] ), .A2(n326), .Y(n212) );
  OR3X1_RVT U287 ( .A1(n214), .A2(n213), .A3(n212), .Y(n285) );
  NOR2X0_RVT U288 ( .A1(n228), .A2(n375), .Y(n218) );
  NOR2X0_RVT U289 ( .A1(n227), .A2(n374), .Y(n215) );
  AO21X1_RVT U290 ( .A1(\u_memory/mem[2][2] ), .A2(n326), .A3(n215), .Y(n217)
         );
  AND2X1_RVT U291 ( .A1(\u_memory/mem[1][2] ), .A2(n325), .Y(n216) );
  OR3X1_RVT U292 ( .A1(n218), .A2(n217), .A3(n216), .Y(n286) );
  NOR2X0_RVT U293 ( .A1(n227), .A2(n373), .Y(n222) );
  NOR2X0_RVT U294 ( .A1(n228), .A2(n370), .Y(n219) );
  AO21X1_RVT U295 ( .A1(\u_memory/mem[1][1] ), .A2(n325), .A3(n219), .Y(n221)
         );
  AND2X1_RVT U296 ( .A1(\u_memory/mem[2][1] ), .A2(n326), .Y(n220) );
  OR3X1_RVT U297 ( .A1(n222), .A2(n221), .A3(n220), .Y(n287) );
  OR2X1_RVT U298 ( .A1(n287), .A2(n288), .Y(n254) );
  OR2X1_RVT U299 ( .A1(n286), .A2(n254), .Y(n253) );
  OR2X1_RVT U300 ( .A1(n285), .A2(n253), .Y(n263) );
  NOR2X0_RVT U301 ( .A1(n227), .A2(n381), .Y(n226) );
  NOR2X0_RVT U302 ( .A1(n228), .A2(n379), .Y(n223) );
  AO21X1_RVT U303 ( .A1(\u_memory/mem[1][4] ), .A2(n325), .A3(n223), .Y(n225)
         );
  AND2X1_RVT U304 ( .A1(\u_memory/mem[2][4] ), .A2(n326), .Y(n224) );
  OR3X1_RVT U305 ( .A1(n226), .A2(n225), .A3(n224), .Y(n284) );
  NOR2X0_RVT U306 ( .A1(n263), .A2(n284), .Y(n273) );
  NOR2X0_RVT U307 ( .A1(n227), .A2(n384), .Y(n232) );
  NOR2X0_RVT U308 ( .A1(n228), .A2(n382), .Y(n229) );
  AO21X1_RVT U309 ( .A1(\u_memory/mem[1][5] ), .A2(n325), .A3(n229), .Y(n231)
         );
  AND2X1_RVT U310 ( .A1(\u_memory/mem[2][5] ), .A2(n326), .Y(n230) );
  OR3X1_RVT U311 ( .A1(n232), .A2(n231), .A3(n230), .Y(n283) );
  INVX0_RVT U312 ( .A(n283), .Y(n272) );
  AND2X1_RVT U313 ( .A1(n273), .A2(n272), .Y(n235) );
  OR2X1_RVT U314 ( .A1(state_out[2]), .A2(n233), .Y(n234) );
  OR2X1_RVT U315 ( .A1(n235), .A2(n234), .Y(n240) );
  OR2X1_RVT U316 ( .A1(sel_item[1]), .A2(n240), .Y(n237) );
  NOR2X0_RVT U317 ( .A1(sel_item[0]), .A2(n237), .Y(n236) );
  NOR2X2_RVT U318 ( .A1(rst), .A2(n236), .Y(n275) );
  INVX1_RVT U319 ( .A(n275), .Y(n255) );
  MUX21X1_RVT U320 ( .A1(\u_memory/mem[0][0] ), .A2(n243), .S0(n255), .Y(n111)
         );
  INVX0_RVT U321 ( .A(n237), .Y(n238) );
  AND2X1_RVT U322 ( .A1(n238), .A2(sel_item[0]), .Y(n239) );
  NOR2X2_RVT U323 ( .A1(rst), .A2(n239), .Y(n276) );
  MUX21X1_RVT U324 ( .A1(\u_memory/mem[1][0] ), .A2(n243), .S0(n256), .Y(n119)
         );
  OR2X1_RVT U325 ( .A1(n319), .A2(n240), .Y(n244) );
  INVX0_RVT U326 ( .A(n244), .Y(n241) );
  AND2X1_RVT U327 ( .A1(n241), .A2(n245), .Y(n242) );
  NOR2X2_RVT U328 ( .A1(rst), .A2(n242), .Y(n278) );
  MUX21X1_RVT U329 ( .A1(\u_memory/mem[2][0] ), .A2(n243), .S0(n259), .Y(n127)
         );
  NOR2X0_RVT U330 ( .A1(n245), .A2(n244), .Y(n246) );
  NOR2X2_RVT U331 ( .A1(rst), .A2(n246), .Y(n282) );
  AO22X1_RVT U332 ( .A1(n282), .A2(\u_memory/mem[3][0] ), .A3(n247), .A4(n281), 
        .Y(n135) );
  INVX0_RVT U333 ( .A(n254), .Y(n248) );
  AO21X1_RVT U334 ( .A1(n288), .A2(n287), .A3(n248), .Y(n250) );
  AO22X1_RVT U335 ( .A1(n275), .A2(\u_memory/mem[0][1] ), .A3(n274), .A4(n250), 
        .Y(n110) );
  INVX0_RVT U336 ( .A(n250), .Y(n249) );
  OR2X1_RVT U337 ( .A1(n250), .A2(n183), .Y(n252) );
  MUX21X1_RVT U338 ( .A1(\u_memory/mem[2][1] ), .A2(n252), .S0(n259), .Y(n126)
         );
  INVX1_RVT U339 ( .A(n282), .Y(n251) );
  MUX21X1_RVT U340 ( .A1(\u_memory/mem[3][1] ), .A2(n252), .S0(n251), .Y(n134)
         );
  INVX0_RVT U341 ( .A(n253), .Y(n261) );
  AOI21X1_RVT U342 ( .A1(n254), .A2(n286), .A3(n261), .Y(n258) );
  INVX0_RVT U343 ( .A(n258), .Y(n260) );
  OR2X1_RVT U344 ( .A1(n260), .A2(n183), .Y(n257) );
  MUX21X1_RVT U345 ( .A1(\u_memory/mem[0][2] ), .A2(n257), .S0(n255), .Y(n109)
         );
  MUX21X1_RVT U346 ( .A1(\u_memory/mem[1][2] ), .A2(n257), .S0(n256), .Y(n117)
         );
  AO22X1_RVT U347 ( .A1(n282), .A2(\u_memory/mem[3][2] ), .A3(n281), .A4(n260), 
        .Y(n133) );
  INVX0_RVT U348 ( .A(n285), .Y(n262) );
  NOR2X0_RVT U349 ( .A1(n262), .A2(n261), .Y(n264) );
  INVX0_RVT U350 ( .A(n263), .Y(n268) );
  OR2X1_RVT U351 ( .A1(n264), .A2(n268), .Y(n267) );
  AO22X1_RVT U352 ( .A1(n275), .A2(\u_memory/mem[0][3] ), .A3(n274), .A4(n267), 
        .Y(n108) );
  INVX1_RVT U353 ( .A(n265), .Y(n277) );
  AO22X1_RVT U354 ( .A1(n267), .A2(n277), .A3(n276), .A4(\u_memory/mem[1][3] ), 
        .Y(n116) );
  INVX1_RVT U355 ( .A(n266), .Y(n279) );
  AO22X1_RVT U356 ( .A1(n267), .A2(n279), .A3(n278), .A4(\u_memory/mem[2][3] ), 
        .Y(n124) );
  AO22X1_RVT U357 ( .A1(n282), .A2(\u_memory/mem[3][3] ), .A3(n281), .A4(n267), 
        .Y(n132) );
  INVX0_RVT U358 ( .A(n284), .Y(n269) );
  NOR2X0_RVT U359 ( .A1(n269), .A2(n268), .Y(n270) );
  OR2X1_RVT U360 ( .A1(n270), .A2(n273), .Y(n271) );
  AO22X1_RVT U361 ( .A1(n275), .A2(\u_memory/mem[0][4] ), .A3(n274), .A4(n271), 
        .Y(n107) );
  AO22X1_RVT U362 ( .A1(n271), .A2(n277), .A3(n276), .A4(\u_memory/mem[1][4] ), 
        .Y(n115) );
  AO22X1_RVT U363 ( .A1(n271), .A2(n279), .A3(n278), .A4(\u_memory/mem[2][4] ), 
        .Y(n123) );
  AO22X1_RVT U364 ( .A1(n282), .A2(\u_memory/mem[3][4] ), .A3(n281), .A4(n271), 
        .Y(n131) );
  XNOR2X1_RVT U365 ( .A1(n273), .A2(n272), .Y(n280) );
  AO22X1_RVT U366 ( .A1(n275), .A2(\u_memory/mem[0][5] ), .A3(n274), .A4(n280), 
        .Y(n106) );
  AO22X1_RVT U367 ( .A1(n280), .A2(n277), .A3(n276), .A4(\u_memory/mem[1][5] ), 
        .Y(n114) );
  AO22X1_RVT U368 ( .A1(n280), .A2(n279), .A3(n278), .A4(\u_memory/mem[2][5] ), 
        .Y(n122) );
  AO22X1_RVT U369 ( .A1(n282), .A2(\u_memory/mem[3][5] ), .A3(n281), .A4(n280), 
        .Y(n130) );
  NOR2X2_RVT U370 ( .A1(rst), .A2(n339), .Y(n327) );
  OR2X2_RVT U371 ( .A1(n183), .A2(n327), .Y(n321) );
  AO22X1_RVT U372 ( .A1(n329), .A2(n283), .A3(stock[5]), .A4(n327), .Y(n91) );
  AO22X1_RVT U373 ( .A1(n329), .A2(n284), .A3(stock[4]), .A4(n327), .Y(n92) );
  AO22X1_RVT U374 ( .A1(n329), .A2(n285), .A3(stock[3]), .A4(n327), .Y(n93) );
  AO22X1_RVT U375 ( .A1(n329), .A2(n286), .A3(stock[2]), .A4(n327), .Y(n94) );
  AO22X1_RVT U376 ( .A1(n329), .A2(n287), .A3(stock[1]), .A4(n327), .Y(n95) );
  AO22X1_RVT U377 ( .A1(n329), .A2(n288), .A3(stock[0]), .A4(n327), .Y(n96) );
  INVX0_RVT U378 ( .A(n290), .Y(n292) );
  XOR2X1_RVT U379 ( .A1(n293), .A2(n186), .Y(n294) );
  AO22X1_RVT U380 ( .A1(n318), .A2(display[5]), .A3(n294), .A4(n354), .Y(n83)
         );
  NAND2X0_RVT U381 ( .A1(n174), .A2(n289), .Y(n296) );
  AO22X1_RVT U382 ( .A1(n318), .A2(display[4]), .A3(n354), .A4(n297), .Y(n84)
         );
  INVX1_RVT U383 ( .A(n298), .Y(n306) );
  NAND2X0_RVT U384 ( .A1(n182), .A2(n299), .Y(n300) );
  XNOR2X1_RVT U385 ( .A1(n301), .A2(n300), .Y(n302) );
  NAND2X0_RVT U386 ( .A1(n303), .A2(n304), .Y(n305) );
  XOR2X1_RVT U387 ( .A1(n306), .A2(n305), .Y(n307) );
  AO22X1_RVT U388 ( .A1(n318), .A2(display[2]), .A3(n354), .A4(n307), .Y(n86)
         );
  NAND2X0_RVT U389 ( .A1(n148), .A2(n309), .Y(n310) );
  XNOR2X1_RVT U390 ( .A1(n310), .A2(n176), .Y(n311) );
  NAND2X0_RVT U391 ( .A1(n178), .A2(n176), .Y(n316) );
  INVX0_RVT U392 ( .A(n316), .Y(n317) );
  AO22X1_RVT U393 ( .A1(n318), .A2(display[0]), .A3(n354), .A4(n317), .Y(n87)
         );
  AO22X1_RVT U394 ( .A1(n329), .A2(sel_item[1]), .A3(n327), .A4(price[6]), .Y(
        n97) );
  AO22X1_RVT U395 ( .A1(n329), .A2(sel_item[0]), .A3(n327), .A4(price[5]), .Y(
        n98) );
  AO22X1_RVT U396 ( .A1(n329), .A2(n319), .A3(price[4]), .A4(n327), .Y(n99) );
  INVX1_RVT U397 ( .A(n327), .Y(n320) );
  AO22X1_RVT U398 ( .A1(n329), .A2(n323), .A3(n327), .A4(price[2]), .Y(n101)
         );
  OR2X1_RVT U399 ( .A1(n326), .A2(n325), .Y(n328) );
  AO22X1_RVT U400 ( .A1(n329), .A2(n328), .A3(n327), .A4(price[1]), .Y(n102)
         );
  NOR2X0_RVT U401 ( .A1(display[0]), .A2(n368), .Y(n360) );
  INVX0_RVT U402 ( .A(n360), .Y(n330) );
  OA21X1_RVT U403 ( .A1(n371), .A2(display[1]), .A3(n330), .Y(n331) );
  AO21X1_RVT U404 ( .A1(display[1]), .A2(n371), .A3(n331), .Y(\intadd_19/CI )
         );
  OR2X1_RVT U405 ( .A1(stock[3]), .A2(stock[2]), .Y(n334) );
  OR2X1_RVT U406 ( .A1(stock[5]), .A2(stock[4]), .Y(n333) );
  NAND2X0_RVT U407 ( .A1(n367), .A2(n389), .Y(n332) );
  NOR3X0_RVT U408 ( .A1(n334), .A2(n333), .A3(n332), .Y(n336) );
  NOR2X0_RVT U409 ( .A1(display[7]), .A2(\intadd_19/n1 ), .Y(n335) );
  NOR2X0_RVT U410 ( .A1(n336), .A2(n335), .Y(n345) );
  INVX0_RVT U411 ( .A(n345), .Y(n337) );
  NOR2X0_RVT U412 ( .A1(n348), .A2(n337), .Y(n342) );
  OR2X1_RVT U413 ( .A1(n390), .A2(state_out[1]), .Y(n349) );
  INVX0_RVT U414 ( .A(confirm), .Y(n338) );
  AND2X1_RVT U415 ( .A1(state_out[0]), .A2(n355), .Y(error) );
  NOR2X0_RVT U416 ( .A1(error), .A2(dispense), .Y(n347) );
  OR2X1_RVT U417 ( .A1(n386), .A2(state_out[2]), .Y(n343) );
  OR2X1_RVT U418 ( .A1(n391), .A2(n343), .Y(n344) );
  OR2X1_RVT U419 ( .A1(n345), .A2(n344), .Y(n346) );
  AOI21X1_RVT U420 ( .A1(n347), .A2(n346), .A3(n357), .Y(\u_control_unit/N22 )
         );
  NOR2X0_RVT U421 ( .A1(n348), .A2(n391), .Y(n351) );
  AO22X1_RVT U422 ( .A1(n354), .A2(n390), .A3(n353), .A4(n352), .Y(
        \u_control_unit/N20 ) );
  AO21X1_RVT U423 ( .A1(display[0]), .A2(n368), .A3(n360), .Y(n359) );
  AO222X1_RVT U424 ( .A1(n359), .A2(n364), .A3(display[0]), .A4(n363), .A5(
        n362), .A6(change_out[0]), .Y(n80) );
  XOR3X2_RVT U425 ( .A1(display[1]), .A2(price[1]), .A3(n360), .Y(n361) );
  AO222X1_RVT U426 ( .A1(n362), .A2(change_out[1]), .A3(n363), .A4(display[1]), 
        .A5(n364), .A6(n361), .Y(n79) );
  AO222X1_RVT U427 ( .A1(n362), .A2(change_out[2]), .A3(n363), .A4(display[2]), 
        .A5(n364), .A6(\intadd_19/SUM[0] ), .Y(n78) );
  AO222X1_RVT U428 ( .A1(n362), .A2(change_out[3]), .A3(n363), .A4(display[3]), 
        .A5(n364), .A6(\intadd_19/SUM[1] ), .Y(n77) );
  AO222X1_RVT U429 ( .A1(n362), .A2(change_out[4]), .A3(n363), .A4(display[4]), 
        .A5(n364), .A6(\intadd_19/SUM[2] ), .Y(n76) );
  AO222X1_RVT U430 ( .A1(n362), .A2(change_out[5]), .A3(n363), .A4(display[5]), 
        .A5(n364), .A6(\intadd_19/SUM[3] ), .Y(n75) );
  AO222X1_RVT U431 ( .A1(n362), .A2(change_out[6]), .A3(n363), .A4(display[6]), 
        .A5(n364), .A6(\intadd_19/SUM[4] ), .Y(n74) );
  XNOR2X1_RVT U432 ( .A1(\intadd_19/n1 ), .A2(display[7]), .Y(n365) );
  AO222X1_RVT U433 ( .A1(n365), .A2(n364), .A3(display[7]), .A4(n363), .A5(
        n362), .A6(change_out[7]), .Y(n73) );
endmodule

